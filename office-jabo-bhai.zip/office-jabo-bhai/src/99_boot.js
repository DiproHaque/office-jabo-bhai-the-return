/* boot last, after every module is defined */
if(window.THREE&&THREE.BufferGeometryUtils)boot();
else{const t=document.getElementById('ldTip');if(t)t.textContent='3D ইঞ্জিন লোড হয়নি। পেজটা আবার খোলো।';}
