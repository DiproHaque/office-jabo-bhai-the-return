/* ============================================================
   11 MAIN: renderer, camera, run lifecycle, loop, input, boot
   ============================================================ */
const CAM={x:0,y:4,z:9,yaw:0,shot:0,shotT:0};let LAST=0;
const PERF={acc:0,n:0,t:0,warned:false};
function setupRenderer(){const cv=$('cv');applyTierKey();
  renderer=new THREE.WebGLRenderer({canvas:cv,antialias:TIER.aa,powerPreference:'high-performance'});
  PERF.pr=Math.min(window.devicePixelRatio||1,TIER.pr);renderer.setPixelRatio(PERF.pr);renderer.setSize(innerWidth,innerHeight,false);
  scene=new THREE.Scene();scene.background=new THREE.Color('#d8d6c4');scene.fog=new THREE.Fog(0xd8d6c4,50,TIER.fogFar);
  camera=new THREE.PerspectiveCamera(62,innerWidth/innerHeight,.3,TIER.fogFar+40);
  LOOK.hemi=new THREE.HemisphereLight(0xdfeaff,0x8a7a5a,.9);scene.add(LOOK.hemi);LOOK.sun=new THREE.DirectionalLight(0xffe0b0,.8);LOOK.sun.position.set(-30,50,20);scene.add(LOOK.sun);
  WORLD.group=new THREE.Group();scene.add(WORLD.group);
  addEventListener('resize',onResize);}
function onResize(){renderer.setSize(innerWidth,innerHeight,false);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();if(FX.mat)FX.mat.uniforms.scale.value=innerHeight*.5;}
function baseFov(){return camera.aspect<1?78:camera.aspect<1.4?68:62;}
function camCfg(){const k=P.kind,c=CAMCFG[k]||CAMCFG.car;if(GAME.camMode===1)return{back:c.back*1.55,up:c.up*1.6,look:c.look*1.3};if(GAME.camMode===2&&P.mode==='drive')return{back:-.4,up:1.5,look:22,fp:1};return c;}
function updateCamera(dt,snap){const c=camCfg(),portraitMul=camera.aspect<1?1.18:1;
  const yaw=PW.a;const dy=wrapA(yaw-CAM.yaw);CAM.yaw=snap?yaw:CAM.yaw+dy*Math.min(1,dt*(c.fp?20:P.mode==='walk'?6:4));
  const fx=-Math.sin(CAM.yaw),fz=-Math.cos(CAM.yaw),back=c.back*portraitMul,up=c.up*portraitMul;
  let tx=PW.x-fx*back,ty=PW.y+up,tz=PW.z-fz*back,k=snap||c.fp?1:1-Math.exp(-dt*7);
  let mLook=null;if(P.mode==='metro'){const rx=Math.cos(CAM.yaw),rz=-Math.sin(CAM.yaw);tx+=rx*-7;tz+=rz*-7;
    const n=ROUTE.root,inSt=(n.stations||[]).some(s=>Math.abs(s.d-(P.d-14))<30);CAM.stB=lerp(CAM.stB||0,inSt?1:0,Math.min(1,dt*2));
    if(CAM.stB>.01){const mid=n.path.pos(P.d-16,-1.8,_f2),sx=mid.x+rx*-12.5-fx*5,sz=mid.z+rz*-12.5-fz*5,sy=9.8+3.4,b=smooth(CAM.stB);tx=lerp(tx,sx,b);ty=lerp(ty,sy,b);tz=lerp(tz,sz,b);mLook={x:mid.x,y:11.2,z:mid.z,b};}}
  if(GAME.state==='arrive'){const t=GAME.arriveT,ang=CAM.yaw+.9+t*.35,R=P.mode==='walk'?5.5:9;tx=PW.x+Math.sin(ang)*R;tz=PW.z+Math.cos(ang)*R;ty=PW.y+(P.mode==='walk'?2.2:3.4);k=1-Math.exp(-dt*2.5);}
  CAM.x+=(tx-CAM.x)*k;CAM.y+=(ty-CAM.y)*k;CAM.z+=(tz-CAM.z)*k;
  camera.position.set(CAM.x,CAM.y,CAM.z);
  if(GAME.shake>0){camera.position.x+=(CR()-.5)*GAME.shake*.6;camera.position.y+=(CR()-.5)*GAME.shake*.4;GAME.shake=Math.max(0,GAME.shake-dt*2.2);}
  if(GAME.state==='arrive')camera.lookAt(PW.x,PW.y+1.3,PW.z);
  else if(mLook&&mLook.b>.01){const lx=PW.x+fx*c.look,lz=PW.z+fz*c.look,ly=PW.y+1.2,b=smooth(mLook.b);camera.lookAt(lerp(lx,mLook.x,b),lerp(ly,mLook.y,b),lerp(lz,mLook.z,b));}
  else camera.lookAt(PW.x+fx*c.look,PW.y+(c.fp?1.3:P.mode==='walk'?1.1:1.2),PW.z+fz*c.look);
  const fov=baseFov()+(P.mode==='drive'||P.mode==='ride'?Math.max(0,Math.abs(P.v)-8)*.45:0)+(P.boosting?6:0);if(Math.abs(camera.fov-fov)>.05){camera.fov+=(fov-camera.fov)*Math.min(1,dt*3);camera.updateProjectionMatrix();}
  if(P.model)P.model.group.visible=!c.fp;}

/* ---------- run lifecycle ---------- */
function clearEntities(){clearPickups();clearTrains();clearWalkObs();clearTimers();for(const v of GAME.veh)scene.remove(v.mesh);for(const f of GAME.free||[])scene.remove(f.mesh);
  for(const w of GAME.walk)scene.remove(w.m);for(const c of GAME.cross)scene.remove(c.m);for(const o of GAME.obst)o.meshes.forEach(m=>{scene.remove(m);m.traverse(x=>{if(x.isMesh&&x.userData.own)x.geometry.dispose();});});for(const b of GAME.debris)scene.remove(b.m);
  for(const a of EV.active)if(a.cleanup)a.cleanup();GAME.veh=[];GAME.free=[];GAME.walk=[];GAME.cross=[];GAME.obst=[];GAME.debris=[];EV.active=[];}
function startRun(o){$('loading')&&($('loading').hidden=false);
  setTimeout(()=>{try{beginRun(o);}catch(e){console.error(e);toastMsg('কিছু একটা ভুল হয়েছে। পেজটা আবার খোলো।','bad',5000);}},30);}
function beginRun(o){
  applyTierKey();PERF.pr=Math.min(window.devicePixelRatio||1,TIER.pr);renderer.setPixelRatio(PERF.pr);renderer.setSize(innerWidth,innerHeight,false);
  clearEntities();clearSub();closeQte();
  const track=o.track||SETTINGS.track,tr=TRACKS[track],seed=o.seed>>>0;RUNRNG=mulberry32(seed^0x9e3779b9);
  const wr=mulberry32(seed^0x1234567)();GAME.weather=o.weather||(wr<.22?'rain':wr<.45?'cloudy':'clear');
  buildTrip(seed,o.home,o.dest);
  const plan=o.plan||'bus';
  ROUTE.homeD=(plan==='bus'||plan==='dd')?ROUTE.mainStart-62:8;
  Object.assign(GAME,{state:'play',seed,daily:!!o.daily,track,t:0,clock:tr.start,startClock:tr.start,deadline:tr.deadline,veh:[],free:[],cross:[],walk:[],obst:[],debris:[],solids:[],
    hits:0,near:0,combo:0,style:0,cleanSince:0,cleanBest:0,clearUntil:0,log:[],shake:0,wrongWayT:0,penalty:0,redRuns:0,honkReplyT:0,camMode:GAME.camMode||0,wallet:CFG.wallet,
    keepLeftT:0,picks:0,shield:0,teaT:0,vipT:0,lastHorn:0,warp:1,warpT:0,lastZone:'',arriveT:0,fusses:0,found:0,frame:0});
  Object.assign(EV,{next:110,active:[],recent:[],ambT:4,calls:{}});
  startJourney(plan);
  // the clock runs so that a steady run (a bit slower than par) still arrives ~2 minutes early
  GAME.par=planPar(plan);GAME.ts=(tr.deadline-tr.start-120)/(GAME.par*1.08);
  PICK.next=80;TRAINS.next=5;
  resetWorld();FX.init();FX.clear();
  P.node=ROUTE.root;P.d=8;P.x=-2;
  buildPlayer('car');applyWeather();
  nextLeg();
  updateChunks(P.node,P.d,0,true);for(const ch of WORLD.chunks.values())wetify(ch.group);
  initialTraffic();updateGround();CAM.yaw=PW.a;updateCamera(0,true);
  miniInit();
  $('loading')&&($('loading').hidden=true);$('title').hidden=true;$('result').hidden=true;$('pause').hidden=true;$('rotate').hidden=true;$('hud').hidden=false;document.body.classList.add('playing');
  showMorning(()=>{if(GAME.weather==='rain')later(2.5,()=>{if(GAME.state==='play')say('আজকে বৃষ্টি! রাস্তা পিচ্ছিল, সাবধানে।','তুমি',{obj:P.model.group,y:2.6},PRIO.event,'me');});});
  LAST=performance.now();}
function arrive(){if(GAME.state!=='play')return;GAME.state='arrive';GAME.arriveT=0;setAction(null);closeQte();const onTime=GAME.clock<=GAME.deadline;
  AU.beep(2);setTimeout(()=>AU.beep(2),180);if(onTime){FX.confetti(PW.x,PW.y+2,PW.z,70);AU.jingle(true);}
  toastMsg((GAME.track==='varsity'?'রোল কল: উপস্থিত! ':'হাজিরা: ')+fmtClock(GAME.clock),onTime?'good':'bad',2600);
  const n=ROUTE.root,f=n.path.pos(n.officeD,-(halfAt(n,n.officeD)+2.2),{});say(pickLine('boss'),TRACKS[GAME.track].who,{x:f.x,z:f.z,y:2.6},PRIO.urgent,'phone');}

/* ---------- one simulation step (shared by the loop and the tests) ---------- */
function gameStep(rdt){
  if(GAME.warpT>0){GAME.warpT-=rdt;if(GAME.warpT<=0)GAME.warp=1;}else GAME.warp=Math.min(1,GAME.warp+rdt*3);
  const dt=rdt*GAME.warp;GAME.t+=dt;GAME.frame=(GAME.frame||0)+1;
  if(GAME.state==='play'){if(JR.clockHold>0)JR.clockHold-=rdt;else GAME.clock+=dt*GAME.ts*(GAME.teaT>0?.4:1);}
  if(JR.xferT>0){JR.xferT-=rdt;if(JR.xferT<=0)$('xfer').hidden=true;}
  updateTimers(dt);updateQte(rdt);
  if(P.mode==='stand'&&KEYS.boost&&!GAME._ub){GAME._ub=1;urgeBus();}if(!KEYS.boost)GAME._ub=0;
  updateJourney(dt);
  trafficSpawner(dt);updateVehicles(dt);updateCrossers(dt);updateWalkers(dt);updateObstacles();updateDebris(dt);updateEvents(dt);updatePickups(dt);updateTrains(dt);
  updateChunks(P.node,P.d,4,false);
  if(GAME.state==='play'&&GAME.clock>=GAME.deadline+22*60)finish(true);
  else if(GAME.state==='arrive'){GAME.arriveT+=rdt;if(GAME.arriveT>3.2)finish(false);}
  updateCamera(rdt);updateGround();FX.update(dt);RAIN.update(rdt);updateSub();updateHUD(rdt);
  // music follows the pressure
  const left=(GAME.deadline-GAME.clock)/(GAME.deadline-GAME.startClock);MUS.int=clamp(.35+(1-left)*.75,.35,1.1);MUS.bpm=104+clamp(1-left,0,1.2)*30;
  if(GAME.state==='play'&&GAME.deadline-GAME.clock<180&&GAME.deadline-GAME.clock>0){GAME.hbT=(GAME.hbT||0)-rdt;if(GAME.hbT<=0){GAME.hbT=.85;AU.heart(.8);}}}

/* ---------- the title screen: a live, self-driving city ---------- */
const DEMO={on:false,t:0};
function enterTitle(){GAME.state='title';DEMO.on=true;DEMO.t=0;$('hud').hidden=true;document.body.classList.remove('playing');
  clearEntities();const tr=SETTINGS.track,dt=dailyTrip(tr);RUNRNG=mulberry32(dt.seed^0x55);GAME.weather='clear';GAME.track=tr;
  buildTrip(dt.seed,dt.home,dt.dest);ROUTE.homeD=8;resetJR();JR.leg=null;resetWorld();FX.init();applyWeather();
  P.node=ROUTE.root;buildPlayer('car');P.mode='drive';P.inp=AIK;P.d=ROUTE.mainStart+20;const lay=laneLayout(P.node,P.d,_lay);P.x=lay.our[1]||lay.our[0];P.v=12;P.h=0;P.boost=1;
  GAME.veh=[];GAME.t=0;GAME.clock=0;GAME.deadline=1e9;GAME.style=0;
  playerWorld(PW);updateChunks(P.node,P.d,0,true);initialTraffic();CAM.yaw=PW.a;CAM.shot=0;CAM.shotT=0;updateCamera(0,true);
  $('title').hidden=false;refreshTitle();setTimeout(()=>$('goDaily').focus(),60);}
function demoStep(rdt){const dt=Math.min(rdt,.05);GAME.t+=dt;
  const lay=laneLayout(P.node,P.d,_lay);const tx=aiFreeX(lay.our[lay.our.length-1]-.2,lay.our[0]+.2,null,0);aiSteer(tx,AIK);let vDes=14;const free=freeAhead(P.x);vDes=Math.min(vDes,Math.max(0,(free-3)*.7));
  const sg=aiSignalStop();if(sg!=null)vDes=Math.min(vDes,Math.max(0,sg*.5-.5));aiSpeed(vDes,AIK);AIK.boost=0;
  updatePlayer(dt);trafficSpawner(dt);updateVehicles(dt);updateCrossers(dt);updateWalkers(dt);updateSignals(dt);updateTrains(dt);
  if(P.d>ROUTE.mainEnd-60||P.stuckT>6){P.d=ROUTE.mainStart+20;P.v=10;P.h=0;for(const v of GAME.veh)scene.remove(v.mesh);GAME.veh=[];initialTraffic();}
  updateChunks(P.node,P.d,3,false);
  // cinematic shots
  CAM.shotT-=rdt;if(CAM.shotT<=0){CAM.shot=(CAM.shot+1)%3;CAM.shotT=7;}
  const fx=-Math.sin(PW.a),fz=-Math.cos(PW.a),rx=Math.cos(PW.a),rz=-Math.sin(PW.a);let tx2,ty,tz,lx,ly,lz;
  if(CAM.shot===0){tx2=PW.x-fx*9+rx*3;ty=PW.y+3.2;tz=PW.z-fz*9+rz*3;lx=PW.x+fx*14;ly=PW.y+1.5;lz=PW.z+fz*14;}
  else if(CAM.shot===1){tx2=PW.x-fx*13;ty=PW.y+7.5;tz=PW.z-fz*13;lx=PW.x+fx*22;ly=PW.y;lz=PW.z+fz*22;}
  else{tx2=PW.x-fx*22+rx*8;ty=PW.y+15;tz=PW.z-fz*22+rz*8;lx=PW.x+fx*30;ly=PW.y+6;lz=PW.z+fz*30;}
  const k=1-Math.exp(-rdt*1.6);CAM.x+=(tx2-CAM.x)*k;CAM.y+=(ty-CAM.y)*k;CAM.z+=(tz-CAM.z)*k;camera.position.set(CAM.x,CAM.y,CAM.z);
  CAM.lx=CAM.lx==null?lx:CAM.lx+(lx-CAM.lx)*k;CAM.ly=CAM.ly==null?ly:CAM.ly+(ly-CAM.ly)*k;CAM.lz=CAM.lz==null?lz:CAM.lz+(lz-CAM.lz)*k;camera.lookAt(CAM.lx,CAM.ly,CAM.lz);
  if(Math.abs(camera.fov-baseFov())>.05){camera.fov=baseFov();camera.updateProjectionMatrix();}
  updateGround();FX.update(dt);MUS.int=.2;MUS.bpm=96;}

/* ---------- loop ---------- */
function loop(now){requestAnimationFrame(loop);let rdt=Math.min(.05,(now-LAST)/1000||0);LAST=now;
  if(GAME.state==='play'||GAME.state==='arrive'){gameStep(rdt);perfCheck(rdt);}
  else if(GAME.state==='title'&&DEMO.on){demoStep(rdt);perfCheck(rdt);}
  AU.update(rdt);renderer.render(scene,camera);}
function perfCheck(rdt){PERF.acc+=rdt;PERF.n++;PERF.t+=rdt;if(PERF.t>3){const fps=PERF.n/PERF.acc;PERF.acc=0;PERF.n=0;PERF.t=0;
  if(fps<30){if(PERF.pr>.6){PERF.pr=Math.max(.6,PERF.pr-.2);renderer.setPixelRatio(PERF.pr);renderer.setSize(innerWidth,innerHeight,false);}
    else if(TIER.fogFar>140){TIER.fogFar*=.85;TIER.traffic*=.85;TIER.walkers=Math.max(3,TIER.walkers-3);applyWeather();}
    if(!PERF.warned&&GAME.state==='play'){PERF.warned=true;toastMsg('ফোন বুঝে গ্রাফিক্স একটু কমানো হলো','info');}}}}

/* ---------- keyboard ---------- */
function keyMap(e){const k=e.key.toLowerCase();
  return k==='w'||k==='arrowup'?'up':k==='s'||k==='arrowdown'?'down':k==='a'||k==='arrowleft'?'left':k==='d'||k==='arrowright'?'right':k==='shift'?'boost':null;}
addEventListener('keydown',e=>{const m=keyMap(e);const k=e.key.toLowerCase();
  if(e.target&&e.target.tagName==='INPUT')return;
  if(m&&(GAME.state==='play'||GAME.state==='arrive')){KEYS[m]=1;e.preventDefault();}
  if(GAME.state==='play'){
    if(JR.qte&&JR.qte.kind==='choice'&&!e.repeat&&(k==='1'||k==='2'||k==='3')){pickChoice(+k-1);return;}
    if((k===' '||k==='e'||k==='enter')&&!e.repeat){if(JR.qte){qteAction();e.preventDefault();return;}if(k==='e'||k==='enter'){doAction();e.preventDefault();return;}}
    if(k===' '){KEYS.hand=1;e.preventDefault();}
    if(k==='h'&&!e.repeat)playerHorn();if(k==='r'&&!e.repeat&&P.mode==='drive')resetCar();if(k==='c'&&!e.repeat)GAME.camMode=(GAME.camMode+1)%3;
    if(k==='m'&&!e.repeat){SETTINGS.mute=!SETTINGS.mute;saveSettings();AU.setOn(!SETTINGS.mute);toastMsg(SETTINGS.mute?'শব্দ বন্ধ':'শব্দ চালু','info',1200);}
    if((k==='p'||k==='escape')&&!e.repeat)pauseGame();}
  else if(GAME.state==='pause'&&(k==='p'||k==='escape'))resumeGame();});
addEventListener('keyup',e=>{const m=keyMap(e);if(m)KEYS[m]=0;if(e.key===' ')KEYS.hand=0;});
addEventListener('blur',()=>{for(const k in KEYS)KEYS[k]=0;if(GAME.state==='play')pauseGame();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&GAME.state==='play')pauseGame();});

/* ---------- boot ---------- */
const tick=()=>new Promise(r=>requestAnimationFrame(()=>setTimeout(r,0)));
async function boot(){const lp=window.LP||function(){};
  lp(60,'রাস্তা আঁকা হচ্ছে…');subInit();
  try{await Promise.race([Promise.all([document.fonts.load('800 40px "Baloo Da 2"'),document.fonts.load('700 30px "Hind Siliguri"'),document.fonts.load('400 30px "Hind Siliguri"')]),new Promise(r=>setTimeout(r,2500))]);}catch(e){}
  await tick();setupRenderer();lp(66);await tick();buildTextures();lp(74,'দোকানের সাইনবোর্ড লেখা হচ্ছে…');await tick();buildMaterials();buildTemplates();lp(84,'রিকশা আর বাস নামানো হচ্ছে…');await tick();
  makeGround();setupTouch();setupMenus();FX.init();
  enterTitle();$('title').hidden=true;lp(97,'মেট্রো চালু হচ্ছে…');await tick();
  for(let i=0;i<4;i++){updateChunks(P.node,P.d,0,true);}renderer.render(scene,camera);
  requestAnimationFrame(t=>{LAST=t;loop(t);});
  lp(100);clearInterval(window.LTIP);const tip=$('ldTip');if(tip)tip.textContent='সব তৈরি! ঢাকা অপেক্ষা করছে।';
  const go=$('ldGo');go.hidden=false;go.focus();
  const start=()=>{unlockAudio();const L=$('loader');L.classList.add('out');setTimeout(()=>L.remove(),700);$('title').hidden=false;refreshTitle();setTimeout(()=>$('goDaily').focus(),80);
    if(!store('ojb4-howSeen')){setTimeout(()=>{renderHow();$('how').hidden=false;},500);}removeEventListener('keydown',kd);};
  const kd=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();start();}};go.addEventListener('click',start,{once:true});addEventListener('keydown',kd);}
