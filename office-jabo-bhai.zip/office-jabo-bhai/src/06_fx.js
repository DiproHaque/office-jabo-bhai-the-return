/* ============================================================
   06 FX: pooled particles, rain, weather look, ground
   ============================================================ */
const FX={n:0,i:0};
FX.init=function(){const N=TIER.particles;FX.n=N;FX.i=0;
  const g=new THREE.BufferGeometry();FX.pos=new Float32Array(N*3);FX.col=new Float32Array(N*3);FX.alp=new Float32Array(N);FX.siz=new Float32Array(N);
  FX.vel=new Float32Array(N*3);FX.life=new Float32Array(N);FX.max=new Float32Array(N);FX.grow=new Float32Array(N);FX.grav=new Float32Array(N);FX.a0=new Float32Array(N);
  g.setAttribute('position',new THREE.BufferAttribute(FX.pos,3));g.setAttribute('pcolor',new THREE.BufferAttribute(FX.col,3));
  g.setAttribute('alpha',new THREE.BufferAttribute(FX.alp,1));g.setAttribute('size',new THREE.BufferAttribute(FX.siz,1));
  const m=new THREE.ShaderMaterial({uniforms:{map:{value:TEX.dot},scale:{value:innerHeight*.5}},transparent:true,depthWrite:false,
    vertexShader:'attribute vec3 pcolor;attribute float alpha;attribute float size;varying vec3 vC;varying float vA;uniform float scale;void main(){vC=pcolor;vA=alpha;vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=max(1.,size*scale/-mv.z);gl_Position=projectionMatrix*mv;}',
    fragmentShader:'uniform sampler2D map;varying vec3 vC;varying float vA;void main(){vec4 t=texture2D(map,gl_PointCoord);if(vA<=0.01)discard;gl_FragColor=vec4(vC,t.a*vA);}'});
  FX.mat=m;if(FX.points){scene.remove(FX.points);FX.points.geometry.dispose();}FX.points=new THREE.Points(g,m);FX.points.frustumCulled=false;FX.points.renderOrder=5;scene.add(FX.points);};
const _cc=new THREE.Color();
FX.emit=function(x,y,z,vx,vy,vz,life,size,grow,grav,color,alpha){const i=FX.i;FX.i=(FX.i+1)%FX.n;_cc.set(color);
  FX.pos[i*3]=x;FX.pos[i*3+1]=y;FX.pos[i*3+2]=z;FX.vel[i*3]=vx;FX.vel[i*3+1]=vy;FX.vel[i*3+2]=vz;FX.col[i*3]=_cc.r;FX.col[i*3+1]=_cc.g;FX.col[i*3+2]=_cc.b;
  FX.life[i]=life;FX.max[i]=life;FX.siz[i]=size;FX.grow[i]=grow;FX.grav[i]=grav;FX.a0[i]=alpha==null?1:alpha;FX.alp[i]=FX.a0[i];};
FX.sparks=function(x,y,z,n){for(let k=0;k<n;k++)FX.emit(x,y,z,rr(-5,5,CR),rr(1,5,CR),rr(-5,5,CR),rr(.25,.5,CR),rr(.12,.22,CR),-.1,-14,CR()<.5?'#ffe070':'#fff6d0',1);};
FX.dust=function(x,y,z,n,c){for(let k=0;k<n;k++)FX.emit(x+rr(-.5,.5,CR),y,z+rr(-.5,.5,CR),rr(-1.5,1.5,CR),rr(.4,1.6,CR),rr(-1.5,1.5,CR),rr(.8,1.4,CR),rr(.5,.9,CR),1.2,0,c||'#b8a888',.55);};
FX.smoke=function(x,y,z,c){FX.emit(x+rr(-.2,.2,CR),y,z+rr(-.2,.2,CR),rr(-.3,.3,CR),rr(.8,1.5,CR),rr(-.3,.3,CR),rr(1.2,2,CR),rr(.4,.7,CR),1.1,0,c,.5);};
FX.splash=function(x,y,z,n,v){for(let k=0;k<n;k++){const s=CR()<.5?-1:1;FX.emit(x+rr(-.8,.8,CR),y,z+rr(-.8,.8,CR),s*rr(1,3,CR)+rr(-.5,.5,CR),rr(2,4.5,CR)*Math.min(1.4,v/12),rr(-1,1,CR),rr(.5,.8,CR),rr(.18,.3,CR),.3,-12,'#dfe8ee',.8);}};
FX.cloud=function(x,y,z){FX.emit(x,y,z,rr(-1,1,CR),rr(.2,1,CR),rr(-1,1,CR),rr(.6,1.1,CR),rr(1.2,2,CR),1.6,0,CR()<.5?'#d8d0c0':'#b8ae9c',.85);};
FX.confetti=function(x,y,z,n){const c=['#ffc928','#e0412f','#2e9b57','#1f6fd0','#ff7ab0'];for(let k=0;k<n;k++)FX.emit(x,y,z,rr(-4,4,CR),rr(4,9,CR),rr(-4,4,CR),rr(1.4,2.2,CR),rr(.18,.28,CR),0,-7,pick(c,CR),1);};
FX.update=function(dt){if(TEX.flood)TEX.flood.offset.x=(TEX.flood.offset.x+dt*.05)%1;if(!FX.points)return;const N=FX.n;let any=false;
  for(let i=0;i<N;i++){if(FX.life[i]<=0){if(FX.alp[i]!==0){FX.alp[i]=0;any=true;}continue;}any=true;FX.life[i]-=dt;
    FX.vel[i*3+1]+=FX.grav[i]*dt;const dr=Math.exp(-dt*1.2);FX.vel[i*3]*=dr;FX.vel[i*3+2]*=dr;
    FX.pos[i*3]+=FX.vel[i*3]*dt;FX.pos[i*3+1]+=FX.vel[i*3+1]*dt;FX.pos[i*3+2]+=FX.vel[i*3+2]*dt;
    FX.siz[i]=Math.max(.02,FX.siz[i]+FX.grow[i]*dt);const t=FX.life[i]/FX.max[i];FX.alp[i]=FX.a0[i]*Math.min(1,t*2);}
  if(any){const g=FX.points.geometry;g.attributes.position.needsUpdate=true;g.attributes.alpha.needsUpdate=true;g.attributes.size.needsUpdate=true;g.attributes.pcolor.needsUpdate=true;}};
FX.clear=function(){if(!FX.points)return;FX.life.fill(0);FX.alp.fill(0);FX.points.geometry.attributes.alpha.needsUpdate=true;};

/* ---------- rain ---------- */
const RAIN={mesh:null,n:0};
RAIN.init=function(on){if(RAIN.mesh){scene.remove(RAIN.mesh);RAIN.mesh.geometry.dispose();RAIN.mesh=null;}if(!on)return;
  const N=TIER.rain;RAIN.n=N;const pos=new Float32Array(N*6);RAIN.pos=pos;RAIN.sp=new Float32Array(N);
  for(let i=0;i<N;i++){RAIN.sp[i]=rr(22,30,CR);RAIN.reset(i,true);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));
  RAIN.mesh=new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:0xeef4ff,transparent:true,opacity:.7,depthWrite:false}));RAIN.mesh.frustumCulled=false;scene.add(RAIN.mesh);};
RAIN.reset=function(i,any){const c=camera.position,p=RAIN.pos;const x=c.x+rr(-30,30,CR),z=c.z+rr(-30,30,CR),y=any?c.y+rr(-6,18,CR):c.y+rr(12,20,CR);
  p[i*6]=x;p[i*6+1]=y;p[i*6+2]=z;p[i*6+3]=x+.22;p[i*6+4]=y+1.3;p[i*6+5]=z+.05;};
RAIN.update=function(dt){if(!RAIN.mesh)return;const p=RAIN.pos,c=camera.position;
  for(let i=0;i<RAIN.n;i++){const dy=RAIN.sp[i]*dt,dx=dy*.16;p[i*6]-=dx;p[i*6+3]-=dx;p[i*6+1]-=dy;p[i*6+4]-=dy;
    if(p[i*6+1]<c.y-8||Math.abs(p[i*6]-c.x)>34||Math.abs(p[i*6+2]-c.z)>34)RAIN.reset(i,false);}
  RAIN.mesh.geometry.attributes.position.needsUpdate=true;};

/* ---------- weather look + ground ---------- */
const LOOK={hemi:null,sun:null};
const WEATHER={clear:{name:'রোদ',bg:'#d8d6c4',hemi:.9,sun:.8,fog:1},cloudy:{name:'মেঘলা',bg:'#b8bcb6',hemi:.8,sun:.45,fog:.85},rain:{name:'বৃষ্টি',bg:'#7a8488',hemi:.66,sun:.2,fog:.6}};
function applyWeather(){const w=WEATHER[GAME.weather];const c=new THREE.Color(w.bg);scene.background=c;scene.fog.color.copy(c);
  scene.fog.near=TIER.fogFar*.2*w.fog;scene.fog.far=TIER.fogFar*w.fog;camera.far=TIER.fogFar+40;camera.updateProjectionMatrix();
  LOOK.hemi.intensity=w.hemi;LOOK.sun.intensity=w.sun;
  const wet=GAME.weather==='rain';MATS.road.color.set(wet?'#9a9ea4':'#ffffff');
  if(wet&&TIER.wet){for(const ch of WORLD.chunks.values())ch.group.traverse(o=>{if(o.isMesh&&o.material===MATS.road)o.material=MATS.roadWet;});}
  RAIN.init(wet);}
function wetify(group){if(GAME.weather==='rain'&&TIER.wet)group.traverse(o=>{if(o.isMesh&&o.material===MATS.road)o.material=MATS.roadWet;});}
function makeGround(){const g=new THREE.PlaneGeometry(1400,1400);g.rotateX(-Math.PI/2);const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*120,uv.getY(i)*120);
  TEX.ground.wrapS=TEX.ground.wrapT=THREE.RepeatWrapping;const m=new THREE.Mesh(g,MATS.ground);m.position.y=-.14;scene.add(m);WORLD.ground=m;}
function updateGround(){const c=camera.position;WORLD.ground.position.x=Math.round(c.x/11.6666)*11.6666;WORLD.ground.position.z=Math.round(c.z/11.6666)*11.6666;}
