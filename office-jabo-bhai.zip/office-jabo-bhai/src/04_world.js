/* ============================================================
   04 WORLD: chunked, seeded city along the route tree
   Each chunk = (node, ci). Geometry is authored in a straight local
   frame (x lateral, z=-d) and bent onto the path. Junction boxes,
   side streets and end caps use a rigid frame.
   ============================================================ */
const WORLD={chunks:new Map(),group:null,ground:null,queue:[],signals:new Map(),puddles:[],speakers:[],sigId:0};
const TINTS={res:['#f4e6c8','#f2d0c8','#f6eaa8','#cfe8d6','#cfe0f0','#ffffff','#f8d8b0','#e8d8f0'],
  alley:['#e8d0b0','#d8c0a8','#f0d8c8','#c8d8d0','#e0c8c0','#f2e4c8'],
  market:['#e8d8b8','#d8c8a8','#f0e0c0','#c8d8c8','#e8c8b8','#f2dcc0'],
  main:['#e8e4dc','#d8dce0','#f0e8d8','#c8ccd0','#e8dcc8','#d0c4b4'],office:['#e0e8f0','#d8e0e8','#ece6dc'],
  glass:['#ffffff','#e0f0ff','#d0e8f0','#f0f8ff']};
const STYLE={res:{0:3,1:4,3:2},alley:{0:2,1:3,3:4},market:{3:3,0:2,1:1},main:{0:3,1:2,2:2,3:2},office:{2:6,1:1,0:1}};
const FRUIT=['#f2a23a','#f4d03f','#7cb342','#e74c3c','#8bc34a','#9c27b0','#ff7043'];
const AWN=['#c8332b','#1f6fd0','#2e9b57','#e8702a','#ffc928','#7d3c98'];
const CLOTH=['#e74c3c','#3498db','#f1c40f','#ecf0f1','#9b59b6','#2ecc71','#e67e22','#ff7ab0'];
const chunkRng=(n,ci)=>mulberry32(((ROUTE.seed*7919)^(n.id*1000003+7)^(ci*104729+13))>>>0);
function zoneKind(t){return t==='rampUp'||t==='flyover'||t==='rampDown'?'main':t==='jn'||t==='cross'?'res':t;}

/* ---------- buildings (canonical frame: road along -z, side s) ---------- */
function building(B,r,kind,s,cd,w,front,o){o=o||{};
  if(kind==='res'&&r()<.07&&!o.noMosque){mosque(B,r,s,cd,w,front);return;}
  const floors=kind==='alley'?ri(3,6,r):kind==='res'?ri(4,7,r):kind==='market'?ri(3,5,r):kind==='main'?ri(6,13,r):ri(9,20,r);
  const style=+wpick(STYLE[kind]||STYLE.res,r),D=o.depth||(kind==='alley'?rr(8,11,r):rr(9,13,r)),cx=s*(front+D/2);
  const tint=pick(style===2?TINTS.glass:(TINTS[kind]||TINTS.res),r);
  const hasShop=kind!=='office'||r()<.3;const gf=hasShop?3.4:0;const H=floors*3.1;
  if(hasShop){B.shopfront(D,gf,w-.2,cx,gf/2+.2,-cd);
    if(r()<.88){B.sign(pick(SHOP_POOL,r),Math.min(w-1.2,7),1.2,s*(front-.08),gf+.75,-cd,-s*Math.PI/2);}
    if(TIER.detail>0&&r()<.5){B.box(1.4,.08,w-.6,s*(front-.6),gf+.15,-cd,pick(AWN,r),0,0,s*.2);}}
  B.facade(style,D,H,w-.2,cx,gf+.2+H/2,-cd,tint);
  const top=gf+.2+H,bays=Math.max(1,Math.floor(w/4));
  if(style!==2&&TIER.detail>0&&(kind==='res'||kind==='alley'||r()<.4)){
    for(let f=1;f<floors;f++)for(let b=0;b<bays;b++){if((b+f)%2)continue;const bz=-(cd-w/2+2+b*4),by=gf+.2+f*3.1-.05;
      B.box(.9,.12,2.6,s*(front-.45),by,bz,'#d8d2c4');B.box(.06,.75,2.6,s*(front-.88),by+.4,bz,'#3a3a3a');
      if(r()<.4)for(let k=0;k<3;k++)B.box(.03,rr(.4,.7,r),.45,s*(front-.84),by+.55,bz-.9+k*.6,pick(CLOTH,r));
      if(r()<.25)B.box(.6,.25,.4,s*(front-.6),by+.2,bz+.8,'#3e7a3a');}}
  if(TIER.detail>0)for(let k=0;k<ri(1,3,r);k++)B.box(.45,.4,.75,s*(front-.22),gf+.2+ri(1,floors,r)*3.1-1.4,-cd+rr(-w/2+1,w/2-1,r),'#e8e8e4');
  B.box(D,.5,w-.2,cx,top+.25,-cd,tint==='#ffffff'?'#d8d8d0':tint);
  if(style!==2){B.cyl(.6,.6,1.1,cx+rr(-2,2,r),top+1.05,-cd+rr(-w/3,w/3,r),'#1a1a1a',10);
    if(r()<.6)B.box(2.4,2.4,2.6,cx+s*rr(1,3,r),top+1.4,-cd+rr(-1,1,r),tint);
    if(r()<.4)B.sph(.6,cx-s*1.5,top+.9,-cd+rr(-2,2,r),'#3f8a3a');}
  else if(r()<.4)B.box(D*.5,3,w*.4,cx,top+1.7,-cd,'#c8d0d8');
}
function mosque(B,r,s,cd,w,front){const D=11,cx=s*(front+D/2),wh='#f1efe8';
  B.box(D,7,w-.4,cx,3.7,-cd,wh);B.box(.1,3.2,2.2,s*(front-.04),2.2,-cd,'#2a5a3a');
  B.sph(Math.min(3.4,w/2-.4),cx,7.2,-cd,'#2e8b57',1,1.1,1,true);B.cyl(.12,.12,1.4,cx,11.2,-cd,'#c8a030');
  const mz=-cd+w/2-1.5;B.cyl(.75,.85,19,s*(front+1.2),9.7,mz,wh,10);B.cyl(1.1,1.1,.4,s*(front+1.2),14.5,mz,'#d8d4c8',10);
  B.sph(.8,s*(front+1.2),19.2,mz,'#2e8b57',1,1.4,1,true);}
function tree(B,r,x,dd,red){B.cyl(.18,.26,3.2,x,1.8,-dd,'#6a4a2a',6);
  const c=red?['#e0502a','#d9461f','#f07030']:['#3f8a3a','#2f7a33','#4f9a42'];
  for(let k=0;k<3;k++)B.sph(rr(1.2,1.8,r),x+rr(-.8,.8,r),3.8+rr(0,1,r),-dd+rr(-.8,.8,r),pick(c,r),1,.75,1);
  if(red)B.sph(1,x,4.4,-dd,'#4f9a42',1,.6,1);}
function teaStall(B,r,s,x,dd,sp,mapPos){B.box(1.4,1.5,1.8,x,.97,-dd,'#8a5a2a');B.box(1.6,.08,2.2,x,1.95,-dd,'#9aa3a8',0,0,s*.12);B.cyl(.14,.12,.3,x-s*.5,1.87,-dd+.4,'#c0c0c0',8);
  for(let k=0;k<4;k++)B.cyl(.13,.13,.35,x-s*.5,1.9,-dd-.6+k*.3,'#f0e0a0',6);B.sign(r()<.5?SIGN_TEA:SIGN_TEA2,1.8,.3,x-s*.72,2.35,-dd,-s*Math.PI/2);
  B.box(.4,.45,1.9,x-s*1.5,.45,-dd,'#6a4a2a');
  for(let k=0;k<ri(1,3,r);k++)B.tmpl(pick(T.seated,r),x-s*1.5,.45,-dd-.6+k*.6,s*Math.PI/2);
  for(let k=0;k<ri(1,2,r);k++)B.tmpl(pick(T.people,r),x-s*2.4,.22,-dd+rr(-1,1,r),-s*Math.PI/2);
  if(sp)sp.push(mapPos('tea',dd,x-s*1.6,2.5));}

/* ---------- suppression near junctions ---------- */
function bSkip(n,s,d,back){const L=legAt(n,d);if(L.type==='jn'||L.type==='cross')return true;
  for(const j of n.juncs){
    if(j.kind==='cross'){if(Math.abs(d-j.c)<j.hc+j.sw+14)return true;continue;}
    const inner=(s===-j.sg);
    if(d<=j.d0){if(d>j.d0-16)return true;if(back&&(inner||j.kind==='fork')&&d>j.d0-60)return true;}
    else if(d>=j.d1){if(back&&inner&&d<j.d1+60)return true;if(d<j.d1+2)return true;}else return true;}
  if(n.office&&s===-1&&!back){const camp=ROUTE.trip&&ROUTE.trip.D.track==='varsity';if(d>n.officeD-(camp?23:18)&&d<n.officeD+(camp?15:10))return true;}
  if(n.office&&d>n.dEnd-4)return true;
  return false;}
function pSkip(n,d){const L=legAt(n,d);if(L.type==='jn'||L.type==='cross')return true;
  for(const j of n.juncs){if(j.kind==='cross'){if(Math.abs(d-j.c)<j.hc+j.sw+3)return true;}else if(d>j.d0-12&&d<j.d1+8)return true;}
  if(n.office&&d>n.officeD-10&&d<n.officeD+14)return true;return false;}

/* ---------- chunk building ---------- */
function chunkRange(n,ci){const L=CFG.chunkLen;let a=Math.max(ci*L,n.dStart),b=Math.min((ci+1)*L,n.dEnd);
  if(!n.children.length&&b>=n.dEnd-.001)b=n.dEnd;return[a,b];}
function* chunkGen(n,ci,ch){
  const r=chunkRng(n,ci),[a,b]=chunkRange(n,ci),path=n.path;
  const B=new Builder(),BG=new Builder();const grp=ch.group;
  const mapPos=(role,d,x,y,abs)=>{const f=path.pos(d,x,{});return{role,x:f.x,z:f.z,y:(abs?0:f.y)+y,d,node:n};};
  const hf=d=>halfAt(n,d);
  // iterate legs overlapping [a,b]
  for(const L of n.legs){if(L.marker)continue;const la=Math.max(a,L.d0),lb=Math.min(b,L.d1);if(lb-la<.01)continue;
    const kind=L.kind||zoneKind(L.type),elev=!!L.elevated,step=path.piece((la+lb)/2).kind==='arc'?2:5;
    // road surface
    B.raw('road',stripGeo(la,lb,d=>-hf(d),hf,0,step,8));
    if(!elev){
      const sw=L.sw||3;
      for(const s of[-1,1]){
        let ok=true;if(L.type==='cross')ok=false;
        if(L.type==='jn'){const j=n.juncs.find(j=>j.d0===L.d0);ok=j?(s===-j.sg):false;}
        if(!ok)continue;
        const x0=d=>s<0?-(hf(d)+sw):hf(d),x1=d=>s<0?-hf(d):hf(d)+sw;
        B.raw('walk',stripGeo(la,lb,x0,x1,.22,step,3));
        const cg=wallGeo(la,lb,d=>s*hf(d),0,.22,step,-s);colorize(cg,'#b0ad9f');B.raw('col2',cg);}
      // markings
      const lay={};
      for(let dd=Math.ceil(la/9)*9+2;dd<lb-1;dd+=9){laneLayout(n,dd,lay);if(L.type==='jn')break;
        if(L.type==='cross'&&Math.abs(dd-(L.d0+L.d1)/2)<L.hc+1)continue;
        if(!lay.div){if(kind!=='alley')B.box(.15,.02,3,0,.012,-(dd+1.5),'#efece2');else if(dd%18<9)B.box(.12,.02,2,0,.012,-(dd+1),'#d8d4c8');}
        else for(let i=0;i<lay.our.length-1;i++){const m=(lay.our[i]+lay.our[i+1])/2;B.box(.15,.02,3,m,.012,-(dd+1.5),'#efece2');B.box(.15,.02,3,-m,.012,-(dd+1.5),'#efece2');}}
      // divider
      if(L.div&&L.type!=='jn'){let s0=null;const dw=L.metro?1.25:.5;for(let dd=la;dd<=lb+.01;dd+=1){const dv=isDivided(n,Math.min(dd,lb-.01));
          if(dv&&s0===null)s0=dd;if((!dv||dd>=lb)&&s0!==null){const e=Math.min(dd,lb);if(e-s0>1){B.raw('col',colorize(stripGeo(s0,e,-dw,dw,.45,4,4),'#3a3a3a'));
              const wl=wallGeo(s0,e,-dw,0,.45,4,1);colorize(wl,'#f2c230');B.raw('col2',wl);const wr=wallGeo(s0,e,dw,0,.45,4,-1);colorize(wr,'#f2c230');B.raw('col2',wr);
              for(let q=s0+3;q<e-1;q+=6)B.sph(.45,L.metro?(q%12<6?-.6:.6):0,.75,-q,'#3d8a3a',1,.8,1);
              if(kind!=='office'&&!L.metro)for(let q=Math.ceil(s0/25)*25;q<e;q+=25){B.cyl(.09,.12,7.5,0,4,-q,'#8a8c90',6);B.box(3.6,.1,.1,0,7.7,-q,'#8a8c90');B.box(.5,.15,.3,-1.8,7.6,-q,'#f4f4e8');B.box(.5,.15,.3,1.8,7.6,-q,'#f4f4e8');}}
            s0=null;}}}
      yield;
      // buildings + back row
      if(L.type!=='jn'&&L.type!=='cross')for(const s of[-1,1]){let dd=la;
        while(dd<lb-1){let w=kind==='alley'?rr(6,10,r):rr(7,13,r);if(dd+w>lb)w=lb-dd;if(w<3){dd+=w;continue;}const cd=dd+w/2;
          if(!bSkip(n,s,cd-w/2+.5,false)&&!bSkip(n,s,cd+w/2-.5,false))building(BG,r,kind,s,cd,w,hf(cd)+sw+.3);
          dd+=w+(r()<.18?rr(1.5,3,r):.15);}
        if(TIER.detail>0||s<0)for(let k=0;k<2;k++){const cd=la+(k+.5)*(lb-la)/2;if(bSkip(n,s,cd,true))continue;const bw=rr(10,18,r),bd=rr(10,16,r),tall=kind==='main'||kind==='office';
          const H=tall?rr(28,60,r):rr(14,26,r),st=kind==='office'?2:pick([0,3,3,1],r);
          BG.facade(st,bd,H,bw,s*(hf(cd)+sw+18+rr(0,12,r)),H/2+.2,-cd,st===2?pick(TINTS.glass,r):pick(['#c8c0b0','#b8b4ac','#d0c8b8','#a8a49c'],r));}}
      yield;
      dressStreet(B,BG,n,L,la,lb,r,kind,sw,ch,mapPos);
    } else dressElevated(B,BG,n,L,la,lb,r,ch,mapPos);
    if(L.metro)dressMetro(BG,n,L,la,lb,r,ch);
    yield;
  }
  // junction structures
  for(const j of n.juncs){if(j.d0>=a&&j.d0<b&&j.kind==='turn'&&j.d0>=n.dStart){junctionBox(n,j,r,ch);yield;}
    if(j.kind==='cross'&&j.d0>=a&&j.d0<b){crossBox(n,j,r,ch);yield;}
    if(j.deckIn&&j.d0>=a&&j.d0<b){deckStub(ch,n.path.frame(j.d0,{}),0,120);yield;}
    if(j.deckOut&&j.d1>=a&&j.d1<b){deckStub(ch,n.path.frame(j.d1,{}),-120,0);yield;}}
  if(!n.children.length&&b>=n.dEnd-.01){endCap(n,r,ch);yield;}
  B.build(pathMapper(path,false),grp);BG.build(pathMapper(path,true),grp);
}
/* street furniture for normal legs */
function dressStreet(B,BG,n,L,la,lb,r,kind,sw,ch,mapPos){
  const hf=d=>halfAt(n,d),sp=ch.speakers,side=(s,dd,off)=>s*(hf(dd)+off),dress=L.dress||[kind],has=k=>dress.includes(k);
  // poles & wires
  if(kind!=='office')for(let pd=Math.ceil(la/25)*25;pd<lb;pd+=25){if(pSkip(n,pd))continue;const hh=hf(pd);
    for(const s of[-1,1]){const x=s*(hh+.5);B.box(.25,9,.25,x,4.5,-pd,'#9a968c');B.box(1.3,.12,.12,x,8.4,-pd,'#6e6a60');B.box(.6,.5,.5,x,7.6,-pd,'#222');
      for(let k=0;k<(kind==='alley'?5:3);k++)B.box(.04,.04,25,x+rr(-.4,.4,r),7.9+k*.3-rr(0,.3,r),-(pd+12.5),'#1c1c1c');
      if(r()<.15)B.box(.8,1,.8,x-s*.6,6.4,-pd,'#7a7c80');}
    if(!L.metro&&r()<(kind==='alley'?.9:.45))B.box(2*hh+1,.04,.04,0,8.6+rr(-.2,.3,r),-pd,'#1c1c1c');}
  // puddles (more when raining)
  const pc=(GAME.weather==='rain'?.75:.3)*(kind==='main'?.6:1);
  if(r()<pc)for(let k=0;k<ri(1,GAME.weather==='rain'?3:1,r);k++){const dd=rr(la,lb,r),hh=hf(dd),x=rr(-hh+1,hh-1,r),w=rr(1.4,3,r),l=rr(1.6,3.4,r);if(pSkip(n,dd))continue;
    const g=T.plane.clone();g.scale(w,1,l);B.put('puddle',g,x,.016,-dd,0,0,0,true);ch.puddles.push({node:n,d:dd,x,w:w/2,l:l/2});}
  if(kind==='alley'){
    // laundry lines across the alley
    for(let dd=la+rr(4,10,r);dd<lb-2;dd+=rr(10,18,r)){if(pSkip(n,dd))continue;const hh=hf(dd)+sw,y=rr(4.2,5.2,r);B.box(2*hh,.03,.03,0,y,-dd,'#333');
      for(let x=-hh+.8;x<hh-.6;x+=rr(.6,1.1,r))if(r()<.75)B.box(rr(.35,.6,r),rr(.5,.9,r),.04,x,y-.4,-dd,pick(CLOTH,r));}
    for(const s of[-1,1]){if(r()<.45){const dd=rr(la+3,lb-3,r);if(!pSkip(n,dd))B.tmpl(pick(T.rickshaw,r),side(s,dd,-.2),.0,-dd,r()<.5?0:Math.PI);}
      if(r()<.35){const dd=rr(la+3,lb-3,r);if(!pSkip(n,dd)){const x=side(s,dd,sw*.5);B.tmpl(pick(T.people,r),x,.22,-dd,s*Math.PI/2);}}
      if(r()<.3){const dd=rr(la+4,lb-4,r);if(!pSkip(n,dd)){const x=side(s,dd,sw*.5);B.cyl(.3,.3,.5,x,.47,-dd,'#b8603a',8);B.sph(.45,x,1.0,-dd,'#3f8a3a');}}}
    if(r()<.3){const dd=rr(la+5,lb-5,r);if(!pSkip(n,dd))sp.push(mapPos('alley',dd,side(-1,dd,.5),2.4));}
  }
  if(has('res')||has('market')){
    for(const s of[-1,1]){
      if(r()<(kind==='res'?.4:.3)){const dd=rr(la+6,lb-6,r);if(!pSkip(n,dd))teaStall(B,r,s,side(s,dd,sw-1.1),dd,sp,mapPos);}
      if(r()<.5){const dd=rr(la+3,lb-3,r);if(!pSkip(n,dd))B.tmpl(pick(T.rickshaw,r),side(s,dd,1.0),.0,-dd,r()<.5?0:Math.PI);}
      if(kind==='res'&&r()<.3){const dd=rr(la+5,lb-5,r);if(!pSkip(n,dd))tree(B,r,side(s,dd,sw-.6),dd,true);}
      for(let k=0;k<ri(0,2,r);k++){const dd=rr(la,lb,r);if(!pSkip(n,dd))B.tmpl(pick(T.people,r),side(s,dd,rr(1.5,3.5,r)),.22,-dd,r()<.5?0:Math.PI);}}
  }
  if(has('market')){
    for(const s of[-1,1])for(let sd=la+1.8;sd<lb-1;sd+=3.6){if(r()<.2||pSkip(n,sd))continue;const x=side(s,sd,1.7);
      B.box(1.3,.75,3.0,x,.6,-sd,'#7a5a3a');for(let k=0;k<(TIER.detail?6:3);k++)B.box(.35,.25,.4,x+rr(-.4,.4,r),1.1,-sd+rr(-1.2,1.2,r),pick(FRUIT,r));
      B.box(2.1,.06,3.3,x+s*.25,2.35,-sd,pick(AWN,r),0,0,s*.25);B.box(.05,2,.05,x-s*.6,1.3,-sd-1.5,'#555');B.box(.05,2,.05,x-s*.6,1.3,-sd+1.5,'#555');
      B.tmpl(pick(T.people,r),x+s*1.1,.22,-sd,s*Math.PI/2);
      if(r()<.4)B.tmpl(pick(T.people,r),x-s*1.25,.22,-sd+rr(-1,1,r),-s*Math.PI/2);
      if(r()<.4)B.box(.6,.35,.45,x+s*.2,.4,-sd+1.7,'#2a6ad0');if(r()<.35)B.cyl(.28,.32,.7,x-s*.9,.57,-sd-1.6,'#d8c8a0',8);
      if(r()<.3)sp.push(mapPos('vendor',sd,x,2.6));}
  }
  if(has('main')||has('office')){
    for(const s of[-1,1]){
      for(let k=0;k<ri(1,4,r);k++){const dd=rr(la,lb,r);if(!pSkip(n,dd))B.tmpl(pick(T.people,r),side(s,dd,rr(1.2,3.6,r)),.22,-dd,r()<.5?0:Math.PI);}
      if(kind==='office'){for(let dd=Math.ceil(la/16)*16+8;dd<lb;dd+=16)if(!pSkip(n,dd))tree(B,r,side(s,dd,sw-.6),dd,false);}
    }
    if(r()<.5){const s=r()<.5?-1:1,dd=rr(la+10,lb-10,r);if(!pSkip(n,dd)&&lb-la>24){const x=side(s,dd,sw-1.6),ry=-s*.35;
      B.cyl(.15,.15,9,x-1.8,4.6,-dd,'#555',6);B.cyl(.15,.15,9,x+1.8,4.6,-dd,'#555',6);
      B.box(8.4,4.4,.2,x-Math.sin(ry)*.15,9.6,-dd-Math.cos(ry)*.15,'#222',ry);B.bill(ri(0,7,r),8,4,x,9.6,-dd,ry);}}
    if(kind==='main'&&r()<.12&&lb-la>30){const dd=(la+lb)/2;if(!pSkip(n,dd-6)&&!pSkip(n,dd+6)){const hh=hf(dd),span=2*(hh+sw);
      B.box(span,.45,2.4,0,6.2,-dd,'#2e6e5a');for(const k of[-1.15,1.15])B.box(span,1.0,.08,0,6.9,-dd+k,'#9ab0a8');
      for(const s of[-1,1]){const x=s*(hh+sw-1.2);B.box(2,6.4,3.6,x,3.4,-dd,'#3a7a66');}
      B.sign(pick(SHOP_POOL,r),6,.9,0,5.7,-dd+1.23,0);}}
  }
  // bus stops (fixed, from the route)
  for(const st of n.stops||[]){if(st.d<la||st.d>=lb)continue;const dd=st.d,x=side(-1,dd,sw-1.4),s=-1;
    B.box(1.6,.1,5,x,2.7,-dd,'#2e6e5a');B.box(.1,2.2,5,x+s*.75,1.6,-dd,'#9ac8c0');B.box(.08,2.5,.08,x-s*.7,1.45,-dd-2.3,'#555');B.box(.08,2.5,.08,x-s*.7,1.45,-dd+2.3,'#555');
    B.box(.45,.4,4,x+s*.3,.45,-dd,'#6a6a6a');for(let k=0;k<ri(3,6,r);k++)B.tmpl(pick(T.people,r),x-s*rr(.3,1.6,r),.22,-dd+rr(-2.4,2.4,r),-s*Math.PI/2);
    B.box(.1,3.2,.1,side(-1,dd,.45),1.6,-(dd+3.2),'#444');labelPlane(ch,n,dd+3.2,side(-1,dd,.45),3.2,1.8,.62,stopTex(st.name),0);
    sp.push(mapPos('stop',dd,x,2.6));}
  // home gate
  if(ROUTE.homeD>=la&&ROUTE.homeD<lb){const dd=ROUTE.homeD,x=side(-1,dd,sw+.3);
    B.box(.5,2.6,.5,x,1.5,-(dd-2),'#d8d0c0');B.box(.5,2.6,.5,x,1.5,-(dd+2),'#d8d0c0');B.box(.12,2.2,3.5,x+.05,1.3,-dd,'#2e7d4f');
    B.sph(.5,x+.1,2.9,-(dd-2),'#3f8a3a');B.sph(.5,x+.1,2.9,-(dd+2),'#3f8a3a');
    B.tmpl(T.mom,side(-1,dd,sw+.9),.22,-(dd-1.1),-Math.PI/2+.5);labelPlane(ch,n,dd,x+.32,2.85,1.6,.5,homeTex(),-Math.PI/2);}
  // destination: office tower or campus + gate + parking bay
  if(n.office&&n.officeD>=la&&n.officeD<lb){const od=n.officeD,hh=hf(od),front=hh+sw+.3,camp=ROUTE.trip&&ROUTE.trip.D.track==='varsity';
    if(!camp){const cx=-(front+7);BG.facade(2,14,46,24,cx,23.4,-od-4,'#ffffff');BG.box(14.4,3.6,24.4,cx,2,-od-4,'#e8e4dc');BG.sign(SIGN_OFFICE,12,1.6,-(front-.1),4.6,-od-4,Math.PI/2);
      BG.box(.12,2.8,7,-(front-.02),1.6,-od,'#5f8aa6');BG.box(.14,.12,7.2,-(front-.04),3.05,-od,'#c8c4b8');BG.box(2.6,.25,8,-(front+.9),3.4,-od,'#2a3a48');      for(const k of[-4.6,4.6]){BG.cyl(.45,.38,.7,-(front-.6),.57,-(od+k),'#8a5a3a',8);BG.sph(.6,-(front-.6),1.25,-(od+k),'#3f8a3a');}B.tmpl(T.police,side(-1,od,sw-1.2),.22,-(od+2.6),Math.PI/2);
      B.box(.5,1.3,.4,side(-1,od,sw-.6),.87,-(od+1.2),'#2a2a2a');B.box(.3,.22,.05,side(-1,od,sw-.6),1.42,-(od+1),'#3ad0ff');}
    else{const cx=-(front+9);BG.box(18,11,34,cx,5.7,-od-4,'#b5523a');for(let k=0;k<7;k++)BG.box(.6,9,.6,-(front+.4),4.7,-(od-12+k*4.2),'#f1ece0');
      BG.box(1.5,1,36,-(front+.6),10.4,-od-4,'#f1ece0');BG.box(16,2.6,30,cx,12.4,-od-4,'#9a3e2a');
      for(let k=0;k<3;k++)tree(BG,r,-(front+2),od-14+k*9,k===1);
      for(let k=0;k<5;k++)B.tmpl(pick(T.people,r),side(-1,od,rr(.8,3.6,r)),.22,-(od+rr(-8,8,r)),r()*TAU);
      labelPlane(ch,n,od-4,-(front-.15),7.6,10,1.4,campusTex(),Math.PI/2);}
    // gate posts + boss / teacher
    B.box(.6,3,.6,-(hh+.6),1.7,-(od-5),'#c8c0b0');B.box(.6,3,.6,-(hh+.6),1.7,-(od+5),'#c8c0b0');B.tmpl(camp?T.teacher:T.boss,-(hh+2.2),.22,-(od-1),Math.PI/2);
    for(const s of[-1,1])B.cyl(.18,.18,7,s*(hh+.4),3.7,-od,'#c8332b',6);
    const pg=new THREE.PlaneGeometry(2*hh+.8,1.4);B.put(camp?'finishV':'finish',pg,0,6.4,-od,0,0,0,true);
    // parking bay (car plan parks here)
    const b0=od-9.5,b1=od-1.5,x0=-hh+.25,x1=-hh+2.85;B.box(.12,.02,b1-b0,x0+.06,.013,-(b0+b1)/2,'#f4f2ea');B.box(.12,.02,b1-b0,x1,.013,-(b0+b1)/2,'#f4f2ea');
    B.box(x1-x0,.02,.12,(x0+x1)/2,.013,-b0,'#f4f2ea');B.box(x1-x0,.02,.12,(x0+x1)/2,.013,-b1,'#f4f2ea');B.put('pBay',T.plane.clone().scale(x1-x0-.3,1,b1-b0-.3),(x0+x1)/2,.014,-(b0+b1)/2,0,0,0,true);
    ROUTE.bay={d0:b0,d1:b1,x0,x1};
    sp.push(mapPos('boss',od,-(hh+2.2),2.6));}
}
/* labels painted on canvas, placed in world space on the route frame */
const LABEL_TEX={};
function labelTex(key,w,h,draw){if(LABEL_TEX[key])return LABEL_TEX[key];return LABEL_TEX[key]=canvasTex(w,h,draw);}
function stopTex(name){return labelTex('stop-'+name,256,96,(g,w,h)=>{g.fillStyle='#0d6b45';g.fillRect(0,0,w,h);g.fillStyle='#ffc928';g.fillRect(0,0,w,10);
  g.fillStyle='#fff';g.textAlign='center';g.textBaseline='middle';fitText(g,'বাস স্টপ',w-20,26,'800',FONT_D);g.fillText('বাস স্টপ',w/2,30);fitText(g,name,w-20,30,'700',FONT_B);g.fillText(name,w/2,68);});}
function homeTex(){return labelTex('home',256,80,(g,w,h)=>{g.fillStyle='#fff3d6';g.fillRect(0,0,w,h);g.strokeStyle='#2e7d4f';g.lineWidth=6;g.strokeRect(3,3,w-6,h-6);
  g.fillStyle='#2e7d4f';g.textAlign='center';g.textBaseline='middle';fitText(g,'আমার বাসা',w-30,44,'800',FONT_D);g.fillText('আমার বাসা',w/2,h/2+3);});}
function campusTex(){return labelTex('campus',512,72,(g,w,h)=>{g.fillStyle='#f1ece0';g.fillRect(0,0,w,h);g.fillStyle='#7a2a1a';g.textAlign='center';g.textBaseline='middle';
  fitText(g,'কলা ভবন · ঢাকা বিশ্ববিদ্যালয়',w-30,46,'800',FONT_D);g.fillText('কলা ভবন · ঢাকা বিশ্ববিদ্যালয়',w/2,h/2+3);});}
function labelPlane(ch,n,d,x,y,w,h,tex,ry){const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide}));
  const p=n.path.pos(d,x,{});m.position.set(p.x,y+p.y,p.z);m.rotation.y=p.a+(ry||0);m.userData.ownMat=true;m.material.userData.keepMap=true;ch.group.add(m);return m;}
/* elevated legs: deck on top, a ground street underneath */
function dressElevated(B,BG,n,L,la,lb,r,ch,mapPos){const hf=d=>halfAt(n,d),gh=L.groundHalf,sw=4.2,path=n.path,f={};
  const yAt=d=>path.frame(d,f).y;
  // ground street
  if(L.type==='flyover')BG.raw('road',stripGeo(la,lb,-gh,gh,0,5,8));
  else{BG.raw('road',stripGeo(la,lb,-gh,d=>-(hf(d)+.4),0,5,8));BG.raw('road',stripGeo(la,lb,d=>hf(d)+.4,gh,0,5,8));}
  for(const s of[-1,1]){BG.raw('walk',stripGeo(la,lb,s<0?-(gh+sw):gh,s<0?-gh:gh+sw,.22,5,3));const cg=wallGeo(la,lb,s*gh,0,.22,5,-s);colorize(cg,'#b0ad9f');BG.raw('col2',cg);}
  for(let dd=Math.ceil(la/9)*9;dd<lb-1;dd+=9)for(const x of[-gh*.55,gh*.55])BG.box(.15,.02,3,x,.012,-(dd+1.5),'#efece2');
  // deck: parapets, slab, divider, lamps
  for(let dd=la;dd<lb-.01;dd+=4){const e=Math.min(lb,dd+4),m=(dd+e)/2,len=e-dd+.02,hh=hf(m),y=yAt(m);
    if(y>.6){for(const s of[-1,1])B.box(.35,1.0,len,s*(hh+.18),.5,-m,'#cfc8b8');
      B.box(2*hh+.7,.9,len,0,-.5,-m,'#a8a296');}
    B.box(.6,.55,len,0,.27,-m,'#d8d0bc');}
  {const lay={};for(let dd=Math.ceil(la/9)*9+2;dd<lb-1;dd+=9){laneLayout(n,dd,lay);if(!lay.div)continue;
    for(let i=0;i<lay.our.length-1;i++){const m=(lay.our[i]+lay.our[i+1])/2;B.box(.15,.02,3,m,.012,-(dd+1.5),'#efece2');B.box(.15,.02,3,-m,.012,-(dd+1.5),'#efece2');}}}
  // embankment walls on ramps, pillars on the flyover
  for(const s of[-1,1]){const wl=new THREE.BufferGeometry(),pos=[],idx=[];const n2=Math.max(1,Math.ceil((lb-la)/4));
    for(let i=0;i<=n2;i++){const d=la+(lb-la)*i/n2,x=s*(hf(d)+.35),y=yAt(d)-.9;pos.push(x,0,-d,x,Math.max(0,y),-d);if(i<n2){const k=i*2;if(s>0)idx.push(k,k+2,k+1,k+1,k+2,k+3);else idx.push(k,k+1,k+2,k+1,k+3,k+2);}}
    if(L.type!=='flyover'){wl.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));wl.setAttribute('uv',new THREE.Float32BufferAttribute(new Float32Array(pos.length/3*2),2));wl.setIndex(idx);wl.computeVertexNormals();colorize(wl,'#b8b0a0');BG.raw('col2',wl);}}
  if(L.type==='flyover')for(let pd=Math.ceil(la/30)*30;pd<lb;pd+=30){const y=yAt(pd);BG.box(1.6,y-.9,1.6,0,(y-.9)/2,-pd,'#b8b0a0');BG.box(2*hf(pd)-1,.6,1.8,0,y-1.2,-pd,'#a8a296');}
  for(let q=Math.ceil(la/30)*30+15;q<lb;q+=30){B.cyl(.08,.1,6,0,3.4,-q,'#8a8c90',6);B.box(3,.1,.1,0,6.3,-q,'#8a8c90');}
  if(L.type==='rampUp'&&la<=L.d0+1){B.put('flyBoard',new THREE.PlaneGeometry(8,2),0,7.5,-(L.d0+2),0,0,0,true);
    for(const s of[-1,1])B.box(.25,8.4,.25,s*(hf(L.d0+2)+.6),4.2,-(L.d0+2.1),'#666');B.box(2*hf(L.d0+2)+1.4,.3,.3,0,8.45,-(L.d0+2.1),'#666');}
  // ground life + buildings
  for(const s of[-1,1]){let dd=la;while(dd<lb-1){let w=rr(7,13,r);if(dd+w>lb)w=lb-dd;if(w<3){dd+=w;continue;}const cd=dd+w/2;
      if(!bSkip(n,s,cd,false))building(BG,r,'main',s,cd,w,gh+sw+.3,{noMosque:1});dd+=w+.15;}
    if(r()<.6){const dd=rr(la+3,lb-3,r);BG.tmpl(pick(T.rickshaw,r),s*(gh-1),0,-dd,r()<.5?0:Math.PI);}
    if(r()<.5){const dd=rr(la+3,lb-3,r);BG.tmpl(pick(T.car),s*(gh-1.4),0,-dd,r()<.5?0:Math.PI);}
    if(r()<.35){const dd=rr(la+5,lb-5,r);teaStall(BG,r,s,s*(gh+sw-1.1),dd,ch.speakers,(role,d,x,y)=>mapPos(role,d,x,y,true));}
    for(let k=0;k<ri(1,3,r);k++){const dd=rr(la,lb,r);BG.tmpl(pick(T.people,r),s*(gh+rr(1,3.5,r)),.22,-dd,r()<.5?0:Math.PI);}}
}
/* ---------- metro rail viaduct, stations ---------- */
const STATION_TEX={};
function stationTex(st){if(STATION_TEX[st.en])return STATION_TEX[st.en];const t=canvasTex(512,128,(g,w,h)=>{g.fillStyle='#ffffff';g.fillRect(0,0,w,h);g.fillStyle='#d8262c';g.fillRect(0,0,w,12);g.fillStyle='#0e7a3c';g.fillRect(0,h-12,w,12);
  g.fillStyle='#14304f';g.textAlign='center';g.textBaseline='middle';fitText(g,st.name,w-40,64,'800',FONT_D);g.fillText(st.name,w/2,h/2-8);
  g.fillStyle='#4a5a6a';fitText(g,(st.en||'').toUpperCase()+' · MRT LINE-6',w-60,22,'700',FONT_B);g.fillText((st.en||'').toUpperCase()+' · MRT LINE-6',w/2,h/2+34);});STATION_TEX[st.en]=t;return t;}
function dressMetro(BG,n,L,la,lb,r,ch){const hf=d=>halfAt(n,d),Y=9.2;
  const isJ=L.type==='jn'||L.type==='cross';
  // deck, parapets, rails
  for(let dd=la;dd<lb-.01;dd+=4){const e=Math.min(lb,dd+4),m=(dd+e)/2,len=e-dd+.03;
    BG.box(8.2,1.1,len,0,Y,-m,'#c9c4b8');BG.box(.3,.9,len,-4.0,Y+1,-m,'#d8d2c6');BG.box(.3,.9,len,4.0,Y+1,-m,'#d8d2c6');
    for(const x of[-2.55,-1.05,1.05,2.55])BG.box(.12,.12,len,x,Y+.62,-m,'#3a3a3a');}
  if(!isJ){for(let q=Math.ceil(la/28)*28+6;q<lb;q+=28){BG.box(1.4,Y-.5,1.6,0,(Y-.5)/2,-q,'#bdb6a8');BG.box(6.4,1,2.2,0,Y-.9,-q,'#b2ab9d');
      BG.box(.25,4.2,.25,0,Y+2.6,-q,'#7a7c80');BG.box(7.4,.18,.18,0,Y+4.5,-q,'#7a7c80');}
    for(let q=Math.ceil(la/28)*28+20;q<lb;q+=28)BG.box(8,.04,.04,0,Y+4.2,-q,'#222');}
  // stations
  for(const st of n.stations||[]){if(!st.metro||st.d<la||st.d>=lb||st.built)continue;const d=st.d,hh=hf(d),W=2*(hh+4.6)+2,len=30;
    BG.box(W,4.2,len,0,Y-1.9,-d,'#f2efe8');BG.box(W-.3,1.2,len-.8,0,Y-1.6,-d,'#5d7f99');BG.box(17,.6,len+3,0,Y+5.7,-d,'#9aa4ac');for(const sd of[-1,1]){BG.box(3.7,.4,len,sd*5.95,Y+.45,-d,'#d9d4c8');BG.box(.08,1.05,len,sd*7.8,Y+1.15,-d,'#7a8a96');BG.box(3.7,.06,len,sd*5.95,Y+.66,-d,'#f2c230');for(let k=-len/2+1.5;k<len/2-1;k+=5.5)BG.box(.42,5,.42,sd*7.6,Y+3.1,-(d+k),'#e8e4dc');for(let k=0;k<4;k++)BG.tmpl(pick(T.people,r),sd*rr(5,7.2,r),Y+.65,-(d+rr(-len/2+3,len/2-3,r)),sd>0?-Math.PI/2:Math.PI/2);}
    for(let k=-1;k<=1;k+=2)BG.box(1.2,Y-3.9,1.2,k*(hh-1.2),(Y-3.9)/2,-(d-len/2+2),'#bdb6a8'),BG.box(1.2,Y-3.9,1.2,k*(hh-1.2),(Y-3.9)/2,-(d+len/2-2),'#bdb6a8');
    for(const s of[-1,1]){BG.box(3,Y+2,6,s*(hh+3.2),(Y+2)/2,-(d-len/2+3),'#e6e1d6');BG.box(2.6,.25,9,s*(hh+3.2),Y*.5,-(d-len/2-3),'#bdb6a8',0,s*0,0);
      for(let k=0;k<6;k++)BG.box(2.4,.18,.6,s*(hh+3.2),.4+k*1.35,-(d-len/2-1-k*1.2),'#9a948a');}
    for(const s of[-1,1])for(const off of[-hh*.55,hh*.55]){const g=new THREE.PlaneGeometry(9,2.25);const f=n.path.frame(d,{}),ca=Math.cos(f.a),sa=Math.sin(f.a);
      const m=new THREE.Mesh(g,new THREE.MeshBasicMaterial({map:stationTex(st)}));const u=d+s*(len/2+.06);
      m.position.set(f.x-sa*u+0*ca,Y+4.4,f.z-ca*u);
      const p=n.path.pos(u,off,{});m.position.set(p.x,Y-1.7,p.z);m.rotation.y=p.a+(s<0?0:Math.PI);m.userData.ownMat=true;m.material.userData.keepMap=true;ch.group.add(m);}
    ch.speakers.push({role:'metroAnn',x:n.path.pos(d,0,{}).x,z:n.path.pos(d,0,{}).z,y:Y+3,d,node:n,station:st});}
}
/* ---------- canonical mini street (for side streets / T-tops) ---------- */
function miniStreet(B,r,kind,h,sw,ranges,o){o=o||{};
  // ranges:{road:[a,b], left:[a,b], right:[a,b], bLeft:[a,b], bRight:[a,b]}
  if(ranges.road){const[a,b]=ranges.road;B.raw('plate',stripGeo(a,b,-h,h,-.02,8,8));for(let dd=a+2;dd<b-2;dd+=9)B.box(.15,.02,3,0,.0,-(dd+1.5),'#efece2');}
  for(const s of[-1,1]){const rg=s<0?ranges.left:ranges.right;if(rg){const[a,b]=rg;B.raw('walk',stripGeo(a,b,s<0?-(h+sw):h,s<0?-h:h+sw,.22,8,3));
      const cg=wallGeo(a,b,s*h,0,.22,8,-s);colorize(cg,'#b0ad9f');B.raw('col2',cg);}
    const br=s<0?ranges.bLeft:ranges.bRight;if(br){let dd=br[0];while(dd<br[1]-1){let w=rr(7,12,r);if(dd+w>br[1])w=br[1]-dd;if(w<3)break;
        building(B,r,kind,s,dd+w/2,w,h+sw+.3,{noMosque:1});dd+=w+.15;}
      for(let pd=Math.ceil(br[0]/25)*25+5;pd<br[1];pd+=25){B.box(.25,9,.25,s*(h+.5),4.5,-pd,'#9a968c');}}}
}
function absorb(dst,src,ry,tx,tz){const M=new THREE.Matrix4().makeRotationY(ry);M.setPosition(tx,0,tz);
  for(const k in src.parts){for(const g of src.parts[k]){g.applyMatrix4(M);(dst.parts[k]||(dst.parts[k]=[])).push(g);}}src.parts={};}
function signalLamps(grp,mapper,sig,x,u,ry){const B=new Builder();B.cyl(.12,.12,5,x,2.7,-u,'#3a3a3a',6);B.box(.55,1.5,.4,x,4.7,-u,'#1c1c1c');B.build(mapper,grp);
  const set={};const tmp=new THREE.Vector3();[['red',5.15],['amber',4.7],['green',4.25]].forEach(([c,y])=>{const g=T.lampGeo.clone();g.translate(x,y,-u+.22);mapper(g);
    const m=new THREE.Mesh(g,MATS.lampOff);m.matrixAutoUpdate=false;m.userData.own=true;grp.add(m);set[c]=m;});sig.lamps.push(set);}
function setLamps(sig){for(const set of sig.lamps){set.red.material=sig.state==='red'?MATS.red:MATS.lampOff;set.amber.material=sig.state==='amber'?MATS.amber:MATS.lampOff;
  set.green.material=sig.state==='green'?MATS.green:MATS.lampOff;}}
/* T-junction with a closed side street */
function junctionBox(n,j,r,ch){const F0=n.path.frame(j.d0,{}),M=rigidMapper(F0),B=new Builder(),R=j.R,hj=j.hj,ts=-j.sg,os=j.sg,sw=4.2,L=70;
  const kind=zoneKind(j.inType==='alley'||j.outType==='alley'?'alley':j.inType);
  // plates
  B.raw('plate',stripGeo(0,R+hj,-hj,hj,-.02,6,8));
  const xa=Math.min(ts*R,ts*hj),xb=Math.max(ts*R,ts*hj);B.raw('plate',stripGeo(R-hj,R+hj,xa,xb,-.02,6,8));
  // outer near corner sidewalk
  if(R-hj-sw>.5){const x0=os>0?hj:-(hj+sw),x1=os>0?hj+sw:-hj;B.raw('walk',stripGeo(0,R-hj-sw,x0,x1,.22,6,3));
    const cg=wallGeo(0,R-hj-sw,os*hj,0,.22,6,-os);colorize(cg,'#b0ad9f');B.raw('col2',cg);}
  // side street toward os, with T-top far side spanning to the turn side
  const S=new Builder();const far=-os;// canonical side that maps to +u
  const rg={road:[0,L],bLeft:null,bRight:null};
  if(far<0){rg.left=[-(R+hj),L];rg.right=[0,L];rg.bLeft=[-(R+hj)+.5,L];rg.bRight=[sw,L];}else{rg.right=[-(R+hj),L];rg.left=[0,L];rg.bRight=[-(R+hj)+.5,L];rg.bLeft=[sw,L];}
  miniStreet(S,r,kind,hj,sw,rg);
  // barricade + sign + police on the side street
  for(let x=-hj+1;x<hj;x+=2.1)S.tmpl(T.barricade,x,0,-4,0);S.sign(SIGN_CLOSED,4.2,.6,0,1.6,-3.9,0);S.tmpl(T.police,0,0,-6,Math.PI);
  for(let k=0;k<3;k++)S.tmpl(pick(T.car),rr(-hj+1.4,hj-1.4,r),0,-rr(12,40,r),r()<.5?0:Math.PI);
  absorb(B,S,-os*Math.PI/2,os*hj,-R);
  cornerFill(B,r,kind,ts,R,hj,sw);
  B.build(M,ch.group);
  // ambient speaker at the closure
  const wp={x:F0.x-Math.sin(F0.a)*R+Math.cos(F0.a)*os*(hj+6),z:F0.z-Math.cos(F0.a)*R-Math.sin(F0.a)*os*(hj+6),y:2.6};
  ch.speakers.push({role:'divert',x:wp.x,z:wp.z,y:2.6,d:j.d0+R*.5,node:n});}
/* the MRT viaduct runs on past a turn (we leave it, it does not end) */
function deckStub(ch,F,u0,u1){const M=rigidMapper(F),B=new Builder(),Y=9.2;
  for(let u=u0;u<u1-.01;u+=4){const e=Math.min(u1,u+4),m=(u+e)/2,len=e-u+.03;
    B.box(8.2,1.1,len,0,Y,-m,'#c9c4b8');B.box(.3,.9,len,-4.0,Y+1,-m,'#d8d2c6');B.box(.3,.9,len,4.0,Y+1,-m,'#d8d2c6');
    for(const x of[-2.55,-1.05,1.05,2.55])B.box(.12,.12,len,x,Y+.62,-m,'#3a3a3a');}
  for(let q=Math.ceil(u0/28)*28+14;q<u1;q+=28){B.box(1.4,Y-.5,1.6,0,(Y-.5)/2,-q,'#bdb6a8');B.box(6.4,1,2.2,0,Y-.9,-q,'#b2ab9d');}
  B.build(M,ch.group);}
/* fill the inner corner lot of a junction: shallow shops facing the incoming road + a kiosk in the corner */
function cornerFill(B,r,kind,ts,R,hj,sw){const dep=Math.max(2.6,R-(hj+sw)-.7);
  const T2=new Builder();building(T2,r,kind==='office'?'main':kind,ts,-8,15,hj+sw+.3,{depth:dep,noMosque:1});absorb(B,T2,0,0,0);
  const q=R-hj-sw;if(q>2.2){const c=ts*(hj+sw+q/2),u=q/2;B.facade(3,q-.8,3.2,q-.8,c,1.6,-u,pick(['#e8d0b0','#cfe0f0','#f2d0c8'],r));B.box(q-.6,.3,q-.6,c,3.35,-u,'#b0a890');
    B.sign(pick(SHOP_POOL,r),Math.min(q-1,4),.6,c,2.6,-(u-(q-.8)/2-.02),0);}}
/* 4-way crossing with traffic signal and open side streets */
function crossBox(n,j,r,ch){const F0=n.path.frame(j.d0,{}),M=rigidMapper(F0),B=new Builder(),h=j.h,hc=j.hc,sw=j.sw,cu=hc+sw,L=75;
  for(const os of[-1,1]){const S=new Builder();miniStreet(S,r,'main',hc,sw,{road:[0,L],left:[0,L],right:[0,L],bLeft:[sw,L],bRight:[sw,L]});
    for(let k=0;k<2;k++)S.tmpl(pick(T.rickshaw,r),os*0+rr(-hc+1,hc-1,r),0,-rr(20,60,r),r()<.5?0:Math.PI);
    absorb(B,S,-os*Math.PI/2,os*h,-cu);}
  // zebra + stop lines
  for(let x=-h+.6;x<h-.4;x+=1.3){B.box(.65,.02,2.4,x,.013,-(-1.4),'#f4f2ea');B.box(.65,.02,2.4,x,.013,-(2*cu+1.4),'#f4f2ea');}
  B.box(h-1,.02,.4,-h/2-.5,.013,3.2,'#f4f2ea');B.box(h-1,.02,.4,h/2+.5,.013,-(2*cu+3.2),'#f4f2ea');
  B.cyl(.05,.05,2.6,0,1.5,-cu,'#ddd',6);B.cone(1.5,.7,0,2.9,-cu,'#c8332b',8);B.tmpl(T.police,0,.45,-cu,0);
  B.build(M,ch.group);
  const sig={id:++WORLD.sigId,node:n,j,d:j.c,stop:j.d0-3,stopOnc:j.d1+3,state:'green',lamps:[],cross:{F0,cu,h,hc}};
  for(const s of[-1,1]){signalLamps(ch.group,M,sig,s*(h+.6),-1.2,0);signalLamps(ch.group,M,sig,s*(h+.6),2*cu+1.2,0);}
  setLamps(sig);ch.signals.push(sig);WORLD.signals.set(sig.id,sig);
  ch.speakers.push(Object.assign({role:'signalcop',d:j.c,node:n},(()=>{const p=n.path.pos(j.c,0,{});return{x:p.x,z:p.z,y:2.8};})()));}
/* end of the route: road closes into a row of buildings */
function endCap(n,r,ch){const F0=n.path.frame(n.dEnd,{}),M=rigidMapper(F0),B=new Builder(),h=halfAt(n,n.dEnd-1),sw=4.6;
  B.raw('road',stripGeo(0,10,-h,h,0,5,8));
  for(const s of[-1,1]){B.raw('walk',stripGeo(0,10,s<0?-(h+sw):h,s<0?-h:h+sw,.22,5,3));}
  B.raw('walk',stripGeo(10,14,-(h+sw),h+sw,.22,5,3));
  const S=new Builder();miniStreet(S,r,'office',0,0,{bLeft:[0,90]});absorb(B,S,-Math.PI/2,-45,-14);
  B.build(M,ch.group);}

/* ---------- chunk manager ---------- */
function chunkKey(n,ci){return n.id+':'+ci;}
function neededChunks(pn,pd,out){const L=CFG.chunkLen,ahead=TIER.ahead*L,behind=TIER.behind*L;out.length=0;
  const walk=(n,from,to)=>{const c0=Math.floor(Math.max(from,n.dStart)/L),c1=Math.floor((Math.min(to,n.dEnd)-.001)/L);
    for(let ci=c0;ci<=c1;ci++)out.push([n,ci,Math.abs((ci+.5)*L-pd)]);
    if(!n.children.length){const lc=Math.floor((n.dEnd-.001)/L);if(to>n.dEnd&&!out.some(o=>o[0]===n&&o[1]===lc))out.push([n,lc,0]);}
    if(to>n.dEnd)for(const c of n.children)walk(c,c.dStart,to);};
  walk(pn,pd-behind,pd+ahead);
  let n=pn;while(n.parent&&pd-behind<n.dStart){const p=n.parent;walk2(p,pd-behind,p.dEnd);
    for(const sib of p.children)if(sib!==n&&pd<sib.dStart+70)walk2(sib,sib.dStart,Math.min(sib.dEnd,sib.dStart+60));n=p;}
  function walk2(m,from,to){const c0=Math.floor(Math.max(from,m.dStart)/L),c1=Math.floor((Math.min(to,m.dEnd)-.001)/L);for(let ci=c0;ci<=c1;ci++)out.push([m,ci,Math.abs((ci+.5)*L-pd)]);}
  // siblings right after a fork stay visible for a bit
  if(pn.parent&&pd<pn.dStart+70)for(const sib of pn.parent.children)if(sib!==pn)walk2(sib,sib.dStart,sib.dStart+60);
  return out;}
const _need=[];
function newChunk(n,ci){const ch={key:chunkKey(n,ci),node:n,ci,group:new THREE.Group(),speakers:[],puddles:[],signals:[],gen:null,done:false};
  ch.gen=chunkGen(n,ci,ch);return ch;}
function finishChunk(ch){ch.done=true;wetify(ch.group);WORLD.group.add(ch.group);for(const s of ch.speakers)WORLD.speakers.push(s);for(const p of ch.puddles)WORLD.puddles.push(p);}
function disposeChunk(ch){if(ch.done)WORLD.group.remove(ch.group);ch.group.traverse(o=>{if(o.isMesh&&o.userData.own)o.geometry.dispose();if(o.userData.ownMat){if(o.material.map&&!o.material.userData.keepMap)o.material.map.dispose();o.material.dispose();o.geometry.dispose();}});
  for(const s of ch.signals)WORLD.signals.delete(s.id);
  if(ch.speakers.length)WORLD.speakers=WORLD.speakers.filter(s=>!ch.speakers.includes(s));if(ch.puddles.length)WORLD.puddles=WORLD.puddles.filter(p=>!ch.puddles.includes(p));}
function updateChunks(pn,pd,budgetMs,sync){
  const need=neededChunks(pn,pd,_need),keys=new Set();for(const [n,ci] of need)keys.add(chunkKey(n,ci));
  for(const [k,ch] of WORLD.chunks)if(!keys.has(k)){disposeChunk(ch);WORLD.chunks.delete(k);}
  need.sort((a,b)=>a[2]-b[2]);
  for(const [n,ci] of need){const k=chunkKey(n,ci);if(!WORLD.chunks.has(k))WORLD.chunks.set(k,newChunk(n,ci));}
  const t0=performance.now();
  for(const [n,ci] of need){const ch=WORLD.chunks.get(chunkKey(n,ci));if(ch.done)continue;
    while(true){const st=ch.gen.next();if(st.done){finishChunk(ch);break;}if(!sync&&performance.now()-t0>budgetMs)return false;}
    if(!sync&&performance.now()-t0>budgetMs)return false;}
  return true;}
function resetWorld(){for(const ch of WORLD.chunks.values())disposeChunk(ch);WORLD.chunks.clear();WORLD.signals.clear();WORLD.speakers=[];WORLD.puddles=[];}
function signalsOn(n){const out=[];for(const s of WORLD.signals.values())if(related(s.node,n))out.push(s);return out;}
