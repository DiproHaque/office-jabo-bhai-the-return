/* ============================================================
   12 EXTRA: power-ups, ambient metro trains, Dhaka overview map
   ============================================================ */
/* ---------- power-ups ---------- */
const PICK_INFO={charge:{name:'এনার্জি',msg:'এনার্জি ফুল! বুস্ট নাও'},tea:{name:'কড়া চা',msg:'কড়া চা! ঘড়ি একটু আস্তে চলবে'},doa:{name:'মায়ের দোয়া',msg:'মায়ের দোয়া সাথে আছে! একটা ধাক্কা মাফ'},
  vip:{name:'ভিআইপি হর্ন',msg:'ভিআইপি হর্ন! সবাই সরে যাবে'},clock:{name:'ঘড়ি',msg:'৩০ সেকেন্ড বাঁচলো!'},taka:{name:'টাকা',msg:'রাস্তায় ৳৫০ পাইলাম!'}};
const PICK={list:[],next:60,mats:{}};
function pickMat(k){return PICK.mats[k]||(PICK.mats[k]=new THREE.SpriteMaterial({map:TEX.pick[k],depthWrite:false}));}
function spawnPickup(type,node,d,x,walk){const s=new THREE.Sprite(pickMat(type));const sc=walk?1:1.5;s.scale.set(sc,sc,1);scene.add(s);
  const ring=new THREE.Mesh(T.pickRing,MATS.ring);if(walk)ring.scale.set(.6,1,.6);scene.add(ring);const p={type,node,d,x,s,ring,t:CR()*6,walk:!!walk};PICK.list.push(p);placePickup(p);return p;}
function placePickup(p){const f=p.node.path.pos(p.d,p.x,_f2);p.wx=f.x;p.wz=f.z;const y0=f.y+(p.walk?.22:0);p.s.position.set(f.x,y0+(p.walk?1.05:1.35)+Math.sin(p.t*3)*.15,f.z);p.ring.position.set(f.x,y0+.05,f.z);p.ring.rotation.y=p.t*2;}
function removePickup(p){scene.remove(p.s);scene.remove(p.ring);p.dead=true;}
function clearPickups(){for(const p of PICK.list){scene.remove(p.s);scene.remove(p.ring);}PICK.list=[];}
function pickWeights(){const w={charge:2,tea:1.3,doa:1.1,vip:P.mode==='drive'?1.2:.6,clock:1.4,taka:2};if(P.cfg.stamina)w.charge=4;return w;}
function updatePickups(dt){const roadPick=P.mode==='drive'||P.mode==='ride';
  if(roadPick&&P.d+150>PICK.next){const d=PICK.next,n=P.node,leg=legAt(n,d);PICK.next=d+rr(120,190);
    if(leg.type!=='jn'&&leg.type!=='cross'&&!pSkip(n,d)&&d<n.officeD-20){const lay=laneLayout(n,d,{}),arr=lay.our;let x=arr[ri(0,arr.length-1)];if(P.mode==='ride')x=arr[arr.length-1];spawnPickup(wpick(pickWeights()),n,d,x);}}
  if(!roadPick&&P.d+150>PICK.next)PICK.next=P.d+150;
  for(const p of PICK.list){p.t+=dt;placePickup(p);
    const reach=p.walk?.75:P.w/2+.9;
    if(Math.abs(p.d-P.d)<(p.walk?1.1:2.2)&&Math.abs(p.x-P.x)<reach&&P.mode!=='metro'&&P.mode!=='stand'){collect(p);removePickup(p);continue;}
    if(p.d<P.d-30||p.d>P.d+400)removePickup(p);}
  PICK.list=PICK.list.filter(p=>!p.dead);
  if(GAME.teaT>0)GAME.teaT-=dt;if(GAME.vipT>0){GAME.vipT-=dt;vipPush();}}
function collect(p){const k=p.type;GAME.picks=(GAME.picks||0)+1;AU.pickup(k);FX.confetti(p.wx,PW.y+1.2,p.wz,12);toastMsg(PICK_INFO[k].msg,'good',2000);GAME.style+=25;
  if(k==='charge'){P.boost=1;if(JR.walk)JR.walk.stam=1;}
  else if(k==='tea'){GAME.teaT=9;}
  else if(k==='doa'){GAME.shield=1;sayMe('meDoa');}
  else if(k==='vip'){GAME.vipT=6;AU.vip();}
  else if(k==='clock'){GAME.clock=Math.max(GAME.startClock,GAME.clock-30);}
  else if(k==='taka'){GAME.wallet+=50;GAME.found=(GAME.found||0)+50;AU.coin();}}
function vipPush(){for(const v of GAME.veh){if(v.dir<0)continue;const rel=v.d-P.d;if(rel<0||rel>90)continue;
    const lay=laneLayout(v.node,v.d,_lay);const edge=lay.div?-(lay.half-.6-v.w/2):-(lay.half-.5-v.w/2);if(Math.abs(v.x-P.x)<3){v.xOff=(P.x>edge+2.5?edge:-edge*.4)-laneX(v);v.weaveCd=2;v.vDes=Math.min(v.vDes,6);}}}

/* ---------- ambient metro trains on the viaduct ---------- */
const TRAINS={list:[],next:8};
function legMetro(n,d){return !!legAt(n,d).metro;}
function spawnTrain(){const n=P.node;let dir=CR()<.5?1:-1;if(P.mode==='metro')dir=-1;const d=dir>0?P.d-170:P.d+380;if(!legMetro(n,clamp(d,0,n.dEnd)))return;
  const cars=[];for(let i=0;i<4;i++){const g=new THREE.Group();g.add(new THREE.Mesh(T.trainCar,MATS.col));if(i===0||i===3){const nose=new THREE.Mesh(T.trainNose,MATS.col);nose.position.z=i===0?-7.5:7.5;if(i===3)nose.rotation.y=Math.PI;g.add(nose);}
    scene.add(g);cars.push(g);}
  TRAINS.list.push({dir,d,v:dir>0?22:20,n,cars,x:dir>0?-1.8:1.8,t:0});AU.trainHorn();}
function updateTrains(dt){TRAINS.next-=dt;if(TRAINS.next<=0){TRAINS.next=rr(14,26,CR);if(legMetro(P.node,P.d)&&TRAINS.list.length<2)spawnTrain();}
  for(const tr of TRAINS.list){tr.t+=dt;tr.d+=tr.dir*tr.v*dt;
    for(let i=0;i<tr.cars.length;i++){const d=tr.d-tr.dir*i*14.2,c=tr.cars[i];const ok=d>0&&d<tr.n.dEnd&&legMetro(tr.n,d);c.visible=ok;if(!ok)continue;
      const f=tr.n.path.pos(d,tr.x,_f2);c.position.set(f.x,9.8,f.z);c.rotation.y=f.a+(tr.dir<0?Math.PI:0);}
    const rel=Math.abs(tr.d-P.d);if(rel<60&&!tr.rumbled){tr.rumbled=true;AU.trainPass();}
    if(tr.t>40||(tr.dir>0&&tr.d>P.d+500)||(tr.dir<0&&tr.d<P.d-300)){tr.cars.forEach(c=>scene.remove(c));tr.dead=true;}}
  TRAINS.list=TRAINS.list.filter(t=>!t.dead);}
function clearTrains(){TRAINS.list.forEach(t=>t.cars.forEach(c=>scene.remove(c)));TRAINS.list=[];TRAINS.next=6;}

/* ---------- Dhaka overview map (pause → map) ---------- */
function drawDhakaMap(cv){const g=cv.getContext('2d'),W=cv.width,H=cv.height;g.fillStyle='#0b2a20';g.fillRect(0,0,W,H);
  const pts=DHAKA.realA.concat(DHAKA.realB);let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;for(const[x,y]of pts){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
  const pad=1300;x0-=pad;x1+=pad;y0-=pad*.5;y1+=pad*.9;const sc=Math.min(W/(x1-x0),H/(y1-y0)),ox=(W-(x1-x0)*sc)/2,oy=(H-(y1-y0)*sc)/2;
  const tx=x=>ox+(x-x0)*sc,ty=y=>H-oy-(y-y0)*sc;g.lineCap='round';g.lineJoin='round';
  const wid=[3,2.4,1.6,1];const col=['#5d7a6c','#4f6c5f','#3e5a4e','#33493f'];
  for(let cls=3;cls>=0;cls--)for(const r of DHAKA.roads){if(r[0]!==cls)continue;g.strokeStyle=col[cls];g.lineWidth=wid[cls];g.beginPath();for(let i=1;i<r.length;i+=2){const X=tx(r[i]),Y=ty(r[i+1]);i===1?g.moveTo(X,Y):g.lineTo(X,Y);}g.stroke();}
  for(const m of DHAKA.metro){g.strokeStyle='rgba(216,38,44,.75)';g.lineWidth=3;g.setLineDash([6,4]);g.beginPath();for(let i=0;i<m.length;i+=2)i?g.lineTo(tx(m[i]),ty(m[i+1])):g.moveTo(tx(m[i]),ty(m[i+1]));g.stroke();g.setLineDash([]);}
  // today's trip
  const n=ROUTE.root;if(n){g.strokeStyle='#ffc928';g.lineWidth=6;g.beginPath();let st=false;for(let d=0;d<n.officeD;d+=10){const rp=realPos(n,d);if(!rp)continue;const X=tx(rp[0]),Y=ty(rp[1]);if(!st){g.moveTo(X,Y);st=true;}else g.lineTo(X,Y);}g.stroke();}
  g.font='700 '+Math.round(H/48)+'px '+FONT_B;g.textBaseline='middle';
  for(const[bnm,en,x,y]of DHAKA.stations){g.fillStyle='#fff3d6';g.beginPath();g.arc(tx(x),ty(y),Math.max(3,H/150),0,TAU);g.fill();g.strokeStyle='#d8262c';g.lineWidth=2;g.stroke();
    g.fillStyle='#fff3d6';g.textAlign='left';g.fillText(bnm,tx(x)+8,ty(y));}
  if(n&&P.node){const rp=realPos(n,P.d);if(rp){const X=tx(rp[0]),Y=ty(rp[1]);g.fillStyle='#1f8fa0';g.strokeStyle='#fff';g.lineWidth=3;g.beginPath();g.arc(X,Y,Math.max(7,H/70),0,TAU);g.fill();g.stroke();
    g.fillStyle='#fff';g.font='800 '+Math.round(H/40)+'px '+FONT_D;g.textAlign='center';g.fillText('তুমি এখানে',X,Y-H/30);}}
  if(ROUTE.trip){g.fillStyle='#ffc928';g.font='800 '+Math.round(H/26)+'px '+FONT_D;g.textAlign='left';g.fillText(ROUTE.trip.H.name+' → '+ROUTE.trip.D.name,14,H/22);}
  g.fillStyle='#b9c7bd';g.font='600 '+Math.round(H/60)+'px '+FONT_B;g.fillText('মানচিত্র: © OpenStreetMap contributors',14,H-14);}
