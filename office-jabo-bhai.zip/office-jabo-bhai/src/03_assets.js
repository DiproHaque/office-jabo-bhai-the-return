/* ============================================================
   03 ASSETS: canvas textures, materials, geometry builder, templates
   ============================================================ */
const FONT_D='"Baloo Da 2","Hind Siliguri","Noto Sans Bengali",sans-serif';
const FONT_B='"Hind Siliguri","Noto Sans Bengali",sans-serif';
function canvasTex(w,h,draw,repeat){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');draw(g,w,h);
  const t=new THREE.CanvasTexture(c);if(repeat){t.wrapS=t.wrapT=THREE.RepeatWrapping;}t.anisotropy=4;return t;}
function fitText(g,text,maxW,size,weight,family){let s=size;g.font=weight+' '+s+'px '+family;while(g.measureText(text).width>maxW&&s>10){s-=2;g.font=weight+' '+s+'px '+family;}return s;}
function noise(g,w,h,n,alpha,dark){for(let i=0;i<n;i++){g.fillStyle=(dark?'rgba(0,0,0,':'rgba(255,255,255,')+(CR()*alpha)+')';g.fillRect(CR()*w,CR()*h,1+CR()*3,1+CR()*3);}}

const SIGNS=['নিউ মায়ের দোয়া ফার্মেসি','বিসমিল্লাহ টি স্টল','আল্লাহর দান জেনারেল স্টোর','ভাই ভাই হোটেল এন্ড রেস্টুরেন্ট','মামা হালিম','নিউ স্টার টেইলার্স',
 'সততা ফার্মেসি','জনতা মোবাইল সার্ভিসিং','লাকি সেলুন','ঢাকা কনফেকশনারি','মোল্লা হার্ডওয়্যার','রুপালি বিউটি পার্লার','ফ্রেশ ফল ভান্ডার','বিক্রমপুর মিষ্টান্ন ভান্ডার',
 'রহিম কম্পিউটার','সাথী ফটোকপি','আল-আমিন মুদি দোকান','একটু কাচ্চি হবে?','কাজ চলিতেছে — সাবধানে চলুন','সময়মতো গ্রুপ লিমিটেড','রাস্তা বন্ধ — ডাইভারশন','ধীরে চলুন — সামনে স্কুল',
 'মা-বাবার দোয়া ট্রেডার্স','গলির মোড় চা ঘর'];
const SIGN_TEA=1,SIGN_WORK=18,SIGN_OFFICE=19,SIGN_CLOSED=20,SIGN_SCHOOL=21,SIGN_TEA2=23;
const SHOP_POOL=[0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,22];
const BILLS=[['জ্যামে আটকা?','সুপার কড়া চা — এক চুমুকে জ্যাম ভুলে যান'],['অফিসে লেট?','দোষ ট্রাফিকের! লেট-লাইফ ইন্স্যুরেন্স'],
 ['হর্ন কম বাজান','কান বাঁচান, মেজাজ বাঁচান'],['ধৈর্য ধরুন','সিগন্যাল একদিন না একদিন ছাড়বেই'],['হেলপার নিয়োগ চলিতেছে','যোগ্যতা: জোরে চিৎকার করতে পারা'],
 ['অফিসের পাশেই ফ্ল্যাট!','জ্যাম ছাড়া জীবন — শুধু বিজ্ঞাপনে'],['ফুচকা খান','টেনশন ভুলেন, টক বেশি দিবো'],['সাবধানে চালান','বাসায় কেউ অপেক্ষা করছে']];
const SIGN_COLORS=[['#c8332b','#fff3d6'],['#0d6b45','#fff3d6'],['#1f4fa0','#ffe27a'],['#ffc928','#7a1a12'],['#f4efe2','#c8332b'],['#5a2a82','#fff3d6'],['#e8702a','#ffffff']];
const TEX={},MATS={},T={};
function buildTextures(){
  TEX.asphalt=canvasTex(256,256,(g,w,h)=>{g.fillStyle='#55575a';g.fillRect(0,0,w,h);noise(g,w,h,3500,.18,true);noise(g,w,h,1500,.10,false);
    for(let i=0;i<5;i++){g.fillStyle='rgba(30,30,32,.25)';g.beginPath();g.ellipse(CR()*w,CR()*h,20+CR()*40,10+CR()*20,CR()*3,0,7);g.fill();}
    g.strokeStyle='rgba(25,25,25,.5)';g.lineWidth=1.2;g.beginPath();g.moveTo(40,10);g.lineTo(70,60);g.lineTo(60,110);g.stroke();},true);
  TEX.walk=canvasTex(128,128,(g,w,h)=>{const s=32;for(let y=0;y<4;y++)for(let x=0;x<4;x++){g.fillStyle=((x+y)%2)?'#a8988a':'#9c6b5a';g.fillRect(x*s,y*s,s,s);}
    g.strokeStyle='rgba(60,50,40,.6)';g.lineWidth=2;for(let i=0;i<=4;i++){g.beginPath();g.moveTo(i*s,0);g.lineTo(i*s,h);g.stroke();g.beginPath();g.moveTo(0,i*s);g.lineTo(w,i*s);g.stroke();}
    noise(g,w,h,800,.2,true);},true);
  TEX.ground=canvasTex(256,256,(g,w,h)=>{g.fillStyle='#7d725c';g.fillRect(0,0,w,h);noise(g,w,h,5000,.18,true);
    for(let i=0;i<40;i++){g.fillStyle='rgba(70,110,50,'+(.15+CR()*.25)+')';g.beginPath();g.arc(CR()*w,CR()*h,4+CR()*14,0,7);g.fill();}},true);
  const wall=(g,w,h)=>{g.fillStyle='#f3efe6';g.fillRect(0,0,w,h);noise(g,w,h,400,.08,true);};
  TEX.f=[
    canvasTex(128,96,(g,w,h)=>{wall(g,w,h);g.fillStyle='#34444f';g.fillRect(26,22,76,48);g.fillStyle='#e9dfc9';for(let x=30;x<100;x+=9)g.fillRect(x,22,3,48);g.fillRect(26,44,76,3);
      g.fillStyle='#cfc6b2';g.fillRect(20,70,88,6);},true),
    canvasTex(128,96,(g,w,h)=>{wall(g,w,h);g.fillStyle='#2f3d48';g.fillRect(30,10,68,56);g.fillStyle='#6e8a96';g.fillRect(34,14,28,48);
      g.fillStyle='#b7ab92';g.fillRect(14,64,100,6);g.fillStyle='#3b3b3b';for(let x=16;x<112;x+=8)g.fillRect(x,70,3,20);g.fillRect(14,70,100,3);},true),
    canvasTex(128,96,(g,w,h)=>{g.fillStyle='#e9eef2';g.fillRect(0,0,w,h);const gr=g.createLinearGradient(0,0,w,h);gr.addColorStop(0,'#4a7a96');gr.addColorStop(1,'#203848');
      g.fillStyle=gr;g.fillRect(6,6,116,80);g.fillStyle='rgba(255,255,255,.18)';g.beginPath();g.moveTo(20,6);g.lineTo(60,6);g.lineTo(30,86);g.lineTo(6,86);g.fill();
      g.fillStyle='#c9d2d8';g.fillRect(62,6,4,80);},true),
    canvasTex(128,96,(g,w,h)=>{wall(g,w,h);const gr=g.createLinearGradient(0,40,0,96);gr.addColorStop(0,'rgba(80,70,50,0)');gr.addColorStop(1,'rgba(80,70,50,.35)');g.fillStyle=gr;g.fillRect(0,0,w,h);
      g.fillStyle='rgba(70,70,60,.35)';g.fillRect(70,60,6,36);g.fillStyle='#2b6e4f';g.fillRect(36,20,22,44);g.fillRect(70,20,22,44);g.fillStyle='#2c3238';g.fillRect(58,20,12,44);},true)];
  TEX.shop=canvasTex(256,96,(g,w,h)=>{g.fillStyle='#f3efe6';g.fillRect(0,0,w,h);
    const cols=['#e8b04a','#d8664a','#6aa86a','#5a8ad0'];for(let i=0;i<2;i++){const x=10+i*128;g.fillStyle='#2a2622';g.fillRect(x,8,108,88);
      g.fillStyle=cols[(i*2)%4];g.fillRect(x+6,46,96,50);g.fillStyle='rgba(255,240,200,.35)';g.fillRect(x+6,46,96,8);
      g.fillStyle='#8d8f92';g.fillRect(x+4,8,100,36);g.fillStyle='#6f7174';for(let y=12;y<44;y+=4)g.fillRect(x+4,y,100,1.5);
      g.fillStyle=cols[(i*2+1)%4];for(let k=0;k<6;k++)g.fillRect(x+12+k*15,60+((k%2)*8),10,26);}},true);
  TEX.signs=canvasTex(1024,1024,(g)=>{const cw=512,ch=1024/12;SIGNS.forEach((t,i)=>{const c=i%2,r=Math.floor(i/2),x=c*cw,y=r*ch;
    const col=i===SIGN_WORK||i===SIGN_CLOSED?['#ffc928','#1c1912']:i===SIGN_OFFICE?['#0b3d5c','#ffffff']:i===SIGN_SCHOOL?['#f4efe2','#1f4fa0']:SIGN_COLORS[i%SIGN_COLORS.length];
    g.fillStyle=col[0];g.fillRect(x+3,y+3,cw-6,ch-6);g.strokeStyle=col[1];g.lineWidth=4;g.strokeRect(x+9,y+9,cw-18,ch-18);
    if(i===SIGN_WORK||i===SIGN_CLOSED){g.fillStyle='#1c1912';for(let k=0;k<12;k++){g.beginPath();g.moveTo(x+k*44,y+ch-12);g.lineTo(x+k*44+22,y+ch-12);g.lineTo(x+k*44+10,y+ch-4);g.fill();}}
    g.fillStyle=col[1];g.textAlign='center';g.textBaseline='middle';fitText(g,t,cw-44,50,'800',FONT_D);g.fillText(t,x+cw/2,y+ch/2+3);});});
  TEX.bills=canvasTex(1024,1024,(g)=>{const cw=512,ch=256,bg=['#ffc928','#0d6b45','#c8332b','#1f4fa0','#f4efe2','#e8702a','#5a2a82','#0d4a35'];
    BILLS.forEach((b,i)=>{const c=i%2,r=Math.floor(i/2),x=c*cw,y=r*ch;g.fillStyle=bg[i];g.fillRect(x+2,y+2,cw-4,ch-4);
      const fg=(bg[i]==='#ffc928'||bg[i]==='#f4efe2')?'#1c1912':'#fff3d6';g.fillStyle=fg;g.globalAlpha=.15;
      for(let k=0;k<6;k++){g.beginPath();g.arc(x+cw-40-k*20,y+40+k*30,30+k*8,0,7);g.fill();}g.globalAlpha=1;
      g.textAlign='center';g.textBaseline='middle';fitText(g,b[0],cw-60,82,'800',FONT_D);g.fillText(b[0],x+cw/2,y+100);
      fitText(g,b[1],cw-60,34,'600',FONT_B);g.fillText(b[1],x+cw/2,y+178);g.fillRect(x+cw/2-60,y+214,120,5);});});
  TEX.rart=canvasTex(128,128,(g,w,h)=>{g.fillStyle='#d8352a';g.fillRect(0,0,w,h);const c=['#ffc928','#2e9b57','#1f6fd0','#ffffff','#ff7ab0'];
    for(let i=0;i<8;i++){g.fillStyle=c[i%5];g.fillRect(0,i*16,w,4);}for(let i=0;i<10;i++){g.fillStyle=c[i%5];g.beginPath();g.arc(CR()*w,CR()*h,6+CR()*8,0,7);g.fill();
      g.fillStyle='#fff';g.beginPath();g.arc(CR()*w,CR()*h,3,0,7);g.fill();}});
  TEX.truckArt=canvasTex(256,128,(g,w,h)=>{g.fillStyle='#e8702a';g.fillRect(0,0,w,h);const c=['#ffc928','#2e9b57','#1f6fd0','#c8332b','#ffffff'];
    for(let i=0;i<6;i++){g.fillStyle=c[i%5];g.fillRect(0,i*22,w,6);}g.fillStyle='#fff';g.textAlign='center';g.textBaseline='middle';fitText(g,'আল্লাহ ভরসা',w-20,44,'800',FONT_D);
    g.strokeStyle='#7a1a12';g.lineWidth=5;g.strokeText('আল্লাহ ভরসা',w/2,h/2+4);g.fillText('আল্লাহ ভরসা',w/2,h/2+4);});
  TEX.boards=['গুলিস্তান — মতিঝিল','মিরপুর ১০ — সায়েদাবাদ','উত্তরা — যাত্রাবাড়ী','আজিমপুর — গাজীপুর','মোহাম্মদপুর — রামপুরা'].map(t=>canvasTex(256,64,(g,w,h)=>{
    g.fillStyle='#101010';g.fillRect(0,0,w,h);g.fillStyle='#ffd23a';g.textAlign='center';g.textBaseline='middle';fitText(g,t,w-16,40,'800',FONT_D);g.fillText(t,w/2,h/2+3);}));
  TEX.sticker=canvasTex(256,64,(g,w,h)=>{g.clearRect(0,0,w,h);g.fillStyle='#fff';g.textAlign='center';g.textBaseline='middle';fitText(g,'মায়ের দোয়া',w-20,46,'800',FONT_D);
    g.strokeStyle='#c8332b';g.lineWidth=5;g.strokeText('মায়ের দোয়া',w/2,h/2+4);g.fillText('মায়ের দোয়া',w/2,h/2+4);});
  TEX.shadow=canvasTex(64,64,(g,w,h)=>{const gr=g.createRadialGradient(32,32,2,32,32,31);gr.addColorStop(0,'rgba(0,0,0,.55)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,w,h);});
  const fin=(t)=>canvasTex(512,96,(g,w,h)=>{g.fillStyle='#c8332b';g.fillRect(0,0,w,h);g.fillStyle='#ffc928';g.fillRect(0,0,w,8);g.fillRect(0,h-8,w,8);
    g.fillStyle='#fff3d6';g.textAlign='center';g.textBaseline='middle';fitText(g,t,w-30,60,'800',FONT_D);g.fillText(t,w/2,h/2+4);});
  TEX.finish=fin('অফিস এসে গেছে! থামো!');TEX.finishV=fin('ক্যাম্পাস এসে গেছে! থামো!');
  TEX.pbay=canvasTex(64,128,(g,w,h)=>{g.fillStyle='rgba(31,111,208,.55)';g.fillRect(0,0,w,h);g.fillStyle='#fff';g.font='800 56px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('P',w/2,h/2);});
  TEX.flyBoard=canvasTex(512,128,(g,w,h)=>{g.fillStyle='#0d6b45';g.fillRect(0,0,w,h);g.strokeStyle='#fff';g.lineWidth=5;g.strokeRect(8,8,w-16,h-16);
    g.fillStyle='#fff';g.textAlign='center';g.textBaseline='middle';fitText(g,'ফ্লাইওভার ↑   মেইন রোড ↖',w-40,54,'800',FONT_D);g.fillText('ফ্লাইওভার ↑   মেইন রোড ↖',w/2,h/2+3);});
  TEX.puddle=canvasTex(128,128,(g,w,h)=>{const gr=g.createRadialGradient(64,64,10,64,64,63);gr.addColorStop(0,'rgba(120,140,160,.85)');gr.addColorStop(.75,'rgba(80,96,110,.75)');
    gr.addColorStop(1,'rgba(60,62,60,0)');g.fillStyle=gr;g.fillRect(0,0,w,h);g.fillStyle='rgba(220,230,240,.35)';g.fillRect(30,40,50,4);g.fillRect(50,70,40,3);});
  TEX.mud=canvasTex(128,128,(g,w,h)=>{g.fillStyle='rgba(86,58,30,.96)';g.fillRect(0,0,w,h);noise(g,w,h,900,.3,true);
    for(let i=0;i<18;i++){g.fillStyle='rgba(60,40,20,.6)';g.beginPath();g.ellipse(CR()*w,CR()*h,6+CR()*10,3+CR()*5,CR()*3,0,7);g.fill();}
    for(let i=0;i<24;i++){g.fillStyle='rgba(200,180,140,.35)';g.fillRect(CR()*w,CR()*h,3,1.5);}},true);
  TEX.flood=canvasTex(128,128,(g,w,h)=>{g.fillStyle='rgba(122,98,62,.94)';g.fillRect(0,0,w,h);for(let i=0;i<90;i++){g.fillStyle='rgba(150,124,84,'+(.2+CR()*.3)+')';g.fillRect(CR()*w,CR()*h,6+CR()*14,2);}
    for(let i=0;i<46;i++){g.strokeStyle='rgba(230,236,240,'+(.25+CR()*.35)+')';g.lineWidth=1.6;g.beginPath();const y=CR()*h,x=CR()*w;g.moveTo(x,y);g.quadraticCurveTo(x+9,y-4,x+20,y);g.stroke();}},true);
  TEX.pick={};const PK={charge:['#ffc928','#1c1912','এনার্জি'],tea:['#c8702a','#fff3d6','চা'],doa:['#2e9b57','#fff3d6','দোয়া'],vip:['#c8332b','#fff3d6','ভিআইপি'],clock:['#1f6fd0','#fff3d6','+৩০'],taka:['#0e7a3c','#ffe27a','৳৫০']};
  for(const k in PK){const [bg,fg,label]=PK[k];TEX.pick[k]=canvasTex(128,128,(g,w,h)=>{g.clearRect(0,0,w,h);g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.arc(66,68,56,0,7);g.fill();
    g.fillStyle=bg;g.beginPath();g.arc(64,64,56,0,7);g.fill();g.lineWidth=7;g.strokeStyle='#fff';g.stroke();g.fillStyle=fg;g.strokeStyle=fg;g.lineWidth=5;
    if(k==='charge'){g.beginPath();g.moveTo(70,18);g.lineTo(40,70);g.lineTo(62,70);g.lineTo(54,108);g.lineTo(88,54);g.lineTo(66,54);g.closePath();g.fill();}
    else if(k==='tea'){g.fillRect(38,50,42,40);g.beginPath();g.arc(86,68,10,-1.5,1.5);g.stroke();g.beginPath();g.moveTo(50,42);g.quadraticCurveTo(44,30,52,22);g.moveTo(64,42);g.quadraticCurveTo(58,30,66,22);g.stroke();}
    else if(k==='doa'){g.beginPath();g.moveTo(64,20);g.lineTo(98,34);g.lineTo(92,76);g.quadraticCurveTo(80,98,64,108);g.quadraticCurveTo(48,98,36,76);g.lineTo(30,34);g.closePath();g.fill();}
    else if(k==='papers'){g.fillRect(40,24,48,64);g.fillStyle=bg;for(let i=0;i<5;i++)g.fillRect(46,34+i*10,36,4);}
    else if(k==='vip'){g.beginPath();g.moveTo(34,52);g.lineTo(54,52);g.lineTo(88,30);g.lineTo(88,94);g.lineTo(54,74);g.lineTo(34,74);g.closePath();g.fill();}
    else if(k==='clock'){g.beginPath();g.arc(64,56,28,0,7);g.stroke();g.beginPath();g.moveTo(64,56);g.lineTo(64,38);g.moveTo(64,56);g.lineTo(78,62);g.stroke();}
    if(k==='taka'){g.font='800 64px '+FONT_D;g.textAlign='center';g.textBaseline='middle';g.fillText('৳',64,66);}
    else{g.font='800 22px '+FONT_D;g.textAlign='center';g.textBaseline='middle';g.fillText(label,64,k==='papers'||k==='doa'||k==='vip'||k==='clock'?104:104);}});}
  TEX.dot=canvasTex(64,64,(g,w,h)=>{const gr=g.createRadialGradient(32,32,0,32,32,31);gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(.5,'rgba(255,255,255,.6)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,w,h);});
}
function buildMaterials(){
  const L=o=>new THREE.MeshLambertMaterial(o);
  MATS.col=L({vertexColors:true});
  MATS.col2=L({vertexColors:true,side:THREE.DoubleSide});
  TEX.f.forEach((t,i)=>MATS['f'+i]=L({map:t,vertexColors:true}));
  MATS.shop=L({map:TEX.shop,vertexColors:true});
  MATS.road=L({map:TEX.asphalt});
  MATS.roadWet=new THREE.MeshPhongMaterial({map:TEX.asphalt,color:0x8a8e94,specular:0x667788,shininess:60});
  MATS.plate=L({map:TEX.asphalt,polygonOffset:true,polygonOffsetFactor:3,polygonOffsetUnits:3});
  MATS.walk=L({map:TEX.walk});
  MATS.ground=L({map:TEX.ground});
  MATS.signs=new THREE.MeshBasicMaterial({map:TEX.signs});
  MATS.bills=new THREE.MeshBasicMaterial({map:TEX.bills});
  MATS.flyBoard=new THREE.MeshBasicMaterial({map:TEX.flyBoard});
  MATS.rart=L({map:TEX.rart,side:THREE.DoubleSide});
  MATS.truckArt=L({map:TEX.truckArt,side:THREE.DoubleSide});
  MATS.boards=TEX.boards.map(t=>new THREE.MeshBasicMaterial({map:t}));
  MATS.sticker=new THREE.MeshBasicMaterial({map:TEX.sticker,transparent:true});
  MATS.shadow=new THREE.MeshBasicMaterial({map:TEX.shadow,transparent:true,depthWrite:false});
  MATS.finish=new THREE.MeshBasicMaterial({map:TEX.finish,side:THREE.DoubleSide});MATS.finishV=new THREE.MeshBasicMaterial({map:TEX.finishV,side:THREE.DoubleSide});
  MATS.pBay=new THREE.MeshBasicMaterial({map:TEX.pbay,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
  MATS.puddle=new THREE.MeshBasicMaterial({map:TEX.puddle,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
  MATS.mud=new THREE.MeshBasicMaterial({map:TEX.mud,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
  MATS.flood=new THREE.MeshBasicMaterial({map:TEX.flood,transparent:true,opacity:.92,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3});
  MATS.lampOff=new THREE.MeshBasicMaterial({color:0x2a2a2a});
  MATS.red=new THREE.MeshBasicMaterial({color:0xff2a1a});
  MATS.green=new THREE.MeshBasicMaterial({color:0x28ff6a});
  MATS.amber=new THREE.MeshBasicMaterial({color:0xffb020});
  MATS.blue=new THREE.MeshBasicMaterial({color:0x2a6aff});
  MATS.light=new THREE.MeshBasicMaterial({color:0xfffbe0});
  MATS.tail=new THREE.MeshBasicMaterial({color:0xff2a1a});
  MATS.dead=new THREE.MeshBasicMaterial({color:0x222222});
  MATS.ball=new THREE.MeshLambertMaterial({color:0xc8201a});
  MATS.ring=new THREE.MeshBasicMaterial({color:0xffe27a,transparent:true,opacity:.75,side:THREE.DoubleSide,depthWrite:false});
}

/* ---------- geometry builder with path deformation ---------- */
const _m=new THREE.Matrix4(),_q=new THREE.Quaternion(),_e=new THREE.Euler(),_s=new THREE.Vector3(),_p=new THREE.Vector3(),_c=new THREE.Color();
function colorize(geo,color){_c.set(color);const n=geo.attributes.position.count,a=new Float32Array(n*3);
  for(let i=0;i<n;i++){a[i*3]=_c.r;a[i*3+1]=_c.g;a[i*3+2]=_c.b;}geo.setAttribute('color',new THREE.BufferAttribute(a,3));return geo;}
function boxUV(geo,w,h,d,bw,fh){const uv=geo.attributes.uv;
  for(let f=0;f<6;f++){for(let k=0;k<4;k++){const i=f*4+k;let u=uv.getX(i),v=uv.getY(i);
    if(f===2||f===3){u=0.04;v=0.04;}else{const horiz=(f<2)?d:w;u*=horiz/bw;v*=h/fh;}uv.setXY(i,u,v);}}}
function quadGeo(p0,p1,p2,p3,uvs){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array([...p0,...p1,...p2,...p3]),3));
  g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(uvs||[0,0,1,0,0,1,1,1]),2));g.setIndex([0,1,2,1,3,2]);g.computeVertexNormals();return g;}
/* strip along d from da..db at lateral x0..x1 (functions of d allowed), height y, subdivided */
function stripGeo(da,db,x0f,x1f,yf,step,uvScale,uvMode){const n=Math.max(1,Math.ceil((db-da)/step)),pos=[],uv=[],idx=[];
  for(let i=0;i<=n;i++){const d=da+(db-da)*i/n,a=typeof x0f==='function'?x0f(d):x0f,b=typeof x1f==='function'?x1f(d):x1f,y=typeof yf==='function'?yf(d):yf;
    pos.push(a,y,-d,b,y,-d);if(uvMode==='lat')uv.push(0,d/uvScale,1,d/uvScale);else uv.push(a/uvScale,d/uvScale,b/uvScale,d/uvScale);
    if(i<n){const k=i*2;idx.push(k,k+1,k+2,k+1,k+3,k+2);}}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  g.setIndex(idx);g.computeVertexNormals();return g;}
/* vertical wall strip (curb face) along d at lateral xf from y0 to y1 */
function wallGeo(da,db,xf,y0,y1,step,facing){const n=Math.max(1,Math.ceil((db-da)/step)),pos=[],idx=[],uv=[];
  for(let i=0;i<=n;i++){const d=da+(db-da)*i/n,x=typeof xf==='function'?xf(d):xf;pos.push(x,y0,-d,x,y1,-d);uv.push(d/4,0,d/4,1);
    if(i<n){const k=i*2;if(facing>0)idx.push(k,k+2,k+1,k+1,k+2,k+3);else idx.push(k,k+1,k+2,k+1,k+3,k+2);}}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();return g;}
const _F={};
function pathMapper(path,absY){return(geo)=>{const p=geo.attributes.position,nr=geo.attributes.normal,n=p.count;let lastD=1e9;let ca=1,sa=0,fx=0,fz=0,fy=0;
  for(let i=0;i<n;i++){const x=p.getX(i),y=p.getY(i),d=-p.getZ(i);
    if(Math.abs(d-lastD)>.05){path.frame(d,_F);ca=Math.cos(_F.a);sa=Math.sin(_F.a);fx=_F.x;fz=_F.z;fy=_F.y;lastD=d;}
    p.setXYZ(i,fx+ca*x,y+(absY?0:fy),fz-sa*x);
    if(nr){const nx=nr.getX(i),nz=nr.getZ(i);nr.setXYZ(i,nx*ca+nz*sa,nr.getY(i),-nx*sa+nz*ca);}}
  p.needsUpdate=true;};}
function rigidMapper(F0){const ca=Math.cos(F0.a),sa=Math.sin(F0.a);return(geo)=>{const p=geo.attributes.position,nr=geo.attributes.normal,n=p.count;
  for(let i=0;i<n;i++){const x=p.getX(i),y=p.getY(i),d=-p.getZ(i);p.setXYZ(i,F0.x-sa*d+ca*x,y+(F0.y||0),F0.z-ca*d-sa*x);
    if(nr){const nx=nr.getX(i),nz=nr.getZ(i);nr.setXYZ(i,nx*ca+nz*sa,nr.getY(i),-nx*sa+nz*ca);}}p.needsUpdate=true;};}
class Builder{
  constructor(){this.parts={};}
  put(key,geo,x,y,z,ry,rx,rz,fresh){_e.set(rx||0,ry||0,rz||0);_q.setFromEuler(_e);_m.compose(_p.set(x,y,z),_q,_s.set(1,1,1));
    const g=fresh?geo:geo.clone();g.applyMatrix4(_m);(this.parts[key]||(this.parts[key]=[])).push(g);}
  box(w,h,d,x,y,z,color,ry,rx,rz,key){this.put(key||'col',colorize(new THREE.BoxGeometry(w,h,d),color),x,y,z,ry,rx,rz,true);}
  cyl(rt,rb,h,x,y,z,color,seg,ry,rx,rz){this.put('col',colorize(new THREE.CylinderGeometry(rt,rb,h,seg||8),color),x,y,z,ry,rx,rz,true);}
  sph(r,x,y,z,color,sx,sy,sz,half){const g=new THREE.SphereGeometry(r,10,half?5:7,0,Math.PI*2,0,half?Math.PI/2:Math.PI);if(sx)g.scale(sx,sy,sz);
    this.put('col',colorize(g,color),x,y,z,0,0,0,true);}
  cone(r,h,x,y,z,color,seg){this.put('col',colorize(new THREE.ConeGeometry(r,h,seg||8),color),x,y,z,0,0,0,true);}
  tmpl(geo,x,y,z,ry){this.put('col',geo,x,y,z,ry,0,0,false);}
  facade(style,w,h,d,x,y,z,tint){const g=new THREE.BoxGeometry(w,h,d);boxUV(g,w,h,d,4,3.1);colorize(g,tint);this.put('f'+style,g,x,y,z,0,0,0,true);}
  shopfront(w,h,d,x,y,z){const g=new THREE.BoxGeometry(w,h,d);boxUV(g,w,h,d,4,h);colorize(g,'#ffffff');this.put('shop',g,x,y,z,0,0,0,true);}
  atlasPlane(key,w,h,cell,cols,rows,x,y,z,ry){const g=new THREE.PlaneGeometry(w,h);const c=cell%cols,r=Math.floor(cell/cols);
    const u0=c/cols,u1=(c+1)/cols,v1=1-r/rows,v0=1-(r+1)/rows;const uv=g.attributes.uv;
    uv.setXY(0,u0,v1);uv.setXY(1,u1,v1);uv.setXY(2,u0,v0);uv.setXY(3,u1,v0);this.put(key,g,x,y,z,ry,0,0,true);}
  sign(cell,w,h,x,y,z,ry){this.atlasPlane('signs',w,h,cell,2,12,x,y,z,ry);}
  bill(cell,w,h,x,y,z,ry){this.atlasPlane('bills',w,h,cell,2,4,x,y,z,ry);}
  raw(key,geo){(this.parts[key]||(this.parts[key]=[])).push(geo);}
  build(mapper,group){const grp=group||new THREE.Group();for(const k in this.parts){const l=this.parts[k];if(!l.length)continue;
      const geo=l.length===1?l[0]:THREE.BufferGeometryUtils.mergeBufferGeometries(l,false);if(l.length>1)l.forEach(g=>g.dispose());
      if(!geo)continue;if(mapper)mapper(geo);geo.computeBoundingSphere();const mesh=new THREE.Mesh(geo,MATS[k]);mesh.matrixAutoUpdate=false;mesh.userData.own=true;grp.add(mesh);}
    this.parts={};return grp;}
}
function merged(b){const l=b.parts.col;const g=l.length===1?l[0]:THREE.BufferGeometryUtils.mergeBufferGeometries(l,false);b.parts={};return g;}

/* ---------- templates ---------- */
const SKIN=['#8a5a3c','#a86f4c','#6e4630','#c08a62','#7d4f34'];
function personGeo(o){const b=new Builder();const skin=o.skin||pick(SKIN,CR);
  if(o.style==='lungi'){b.box(.46,.85,.32,0,.45,0,o.low||'#3a6aa0');}
  else if(o.style==='salwar'){b.box(.5,1.0,.34,0,.52,0,o.low||'#c03a7a');}
  else{b.box(.17,.85,.2,-.11,.43,0,o.low||'#2b2f3a');b.box(.17,.85,.2,.11,.43,0,o.low||'#2b2f3a');}
  b.box(.5,.66,.3,0,1.18,0,o.top||'#e8e2d0');b.box(.13,.6,.14,-.33,1.16,0,o.top||'#e8e2d0');b.box(.13,.6,.14,.33,1.16,0,o.top||'#e8e2d0');
  b.box(.12,.12,.12,-.33,.82,0,skin);b.box(.12,.12,.12,.33,.82,0,skin);
  b.box(.14,.1,.14,0,1.55,0,skin);b.sph(.17,0,1.74,0,skin);
  if(o.hat==='tupi')b.sph(.165,0,1.8,0,'#f4f1e8',1,.6,1,true);
  else if(o.hat==='cap')b.box(.36,.12,.36,0,1.9,0,o.hatC||'#1d3557');
  else if(o.hat==='scarf'){b.sph(.19,0,1.76,.01,o.hatC||'#b8336a',1,1.05,1.05,false);b.box(.52,.3,.32,0,1.42,0,o.hatC||'#b8336a');}
  else if(o.hat==='helmet')b.sph(.2,0,1.78,0,o.hatC||'#d02020',1,.9,1.05,true);
  else if(o.hat==='pagri')b.sph(.2,0,1.82,0,'#e8b030',1,.8,1,true);
  else b.sph(.172,0,1.79,.02,'#15110d',1,.6,1,true);
  if(o.vest)b.box(.53,.5,.33,0,1.22,0,'#d7ff3a');
  if(o.umbrella){b.box(.04,1.2,.04,.25,1.7,0,'#222');b.cone(.75,.35,.25,2.4,0,o.umbrella,10);}
  if(o.phone)b.box(.08,.14,.04,.2,1.62,-.12,'#111');
  const g=merged(b);if(o.scale)g.scale(o.scale,o.scale,o.scale);return g;}
function seatedGeo(top,skin){const b=new Builder();skin=skin||pick(SKIN,CR);b.box(.46,.3,.5,0,.15,0,'#2b2f3a');b.box(.5,.62,.3,0,.6,.1,top);
  b.box(.14,.1,.14,0,.96,.1,skin);b.sph(.17,0,1.14,.1,skin);b.sph(.172,0,1.19,.12,'#15110d',1,.6,1,true);return merged(b);}
function wheel(b,r,w,x,y,z){b.cyl(r,r,w,x,y,z,'#151515',10,0,0,Math.PI/2);}
function buildTemplates(){
  const tops=['#e8e2d0','#4a7fb0','#c0392b','#2e8b57','#f2c14e','#7d5ba6','#dfe6e9','#e67e22','#1abc9c','#8e5a3c'];
  const lows=['#2b2f3a','#3a6aa0','#5b4a3a','#1e1e1e','#6b6b70'];
  T.people=[];for(let i=0;i<14;i++){const st=i%5===0?'lungi':i%5===3?'salwar':'pants';
    T.people.push(personGeo({style:st,top:tops[i%tops.length],low:st==='lungi'?pick(['#3a6aa0','#2e7d4f','#7b3b8f','#a03a3a'],CR):st==='salwar'?pick(['#c03a7a','#e07b39','#2a7ab0'],CR):pick(lows,CR),
      hat:st==='salwar'?'scarf':i%7===2?'tupi':i%6===4?'cap':null,hatC:pick(['#b8336a','#e8a33a','#2f6d8f','#7a2a8a'],CR)}));}
  T.umbrella=['#1a1a1a','#1f4fa0','#c8332b','#2e8b57'].map((u,i)=>personGeo({top:tops[i+2],umbrella:u,style:i===1?'salwar':'pants',hat:i===1?'scarf':null}));
  T.phoneGuy=personGeo({top:'#4a7fb0',phone:true});
  T.kids=['#c0392b','#f2c14e','#2e8b57','#4a7fb0'].map(c=>personGeo({top:c,low:'#2b2f3a',scale:.68}));
  T.police=personGeo({top:'#2e3f63',low:'#2e3f63',hat:'cap',hatC:'#1a2440',vest:true,skin:'#8a5a3c'});
  T.boss=personGeo({top:'#f4f4f4',low:'#20242c',skin:'#a86f4c'});
  T.groom=personGeo({top:'#f3e6c4',low:'#f3e6c4',hat:'pagri'});
  T.wedding=['#d02040','#e8a020','#b02090','#f06a2a','#c01830'].map((c,i)=>personGeo({style:i%2?'salwar':'pants',top:c,low:i%2?'#e8c040':'#3a2a1a',hat:i%2?'scarf':null,hatC:'#e8b030'}));
  T.worker=personGeo({top:'#e8702a',low:'#3a3a3a',hat:'helmet',hatC:'#ffc928'});
  T.porter=(()=>{const b=new Builder();b.tmpl(personGeo({style:'lungi',top:'#d8d0b8',low:'#3a6aa0'}),0,0,0,0);b.box(.6,.45,.45,0,2.1,0,'#c8b890');return merged(b);})();
  T.seated=tops.slice(0,6).map(c=>seatedGeo(c));
  T.car=['#d8dde0','#c8332b','#1f3f6a','#2a2a2a','#e8e4d8','#7a8a90'].map(c=>{const b=new Builder();
    b.box(1.8,.62,4.3,0,.62,0,c);b.box(1.62,.56,2.1,0,1.2,.25,'#26343d');b.box(1.66,.08,1.9,0,1.5,.3,c);
    b.box(1.82,.2,.2,0,.42,-2.15,'#333');b.box(1.82,.2,.2,0,.42,2.15,'#333');
    b.box(.32,.14,.06,-.62,.75,-2.16,'#fff6c8');b.box(.32,.14,.06,.62,.75,-2.16,'#fff6c8');b.box(.34,.14,.06,-.62,.75,2.16,'#d01818');b.box(.34,.14,.06,.62,.75,2.16,'#d01818');
    [[-.86,-1.35],[.86,-1.35],[-.86,1.35],[.86,1.35]].forEach(p=>wheel(b,.33,.24,p[0],.33,p[1]));return merged(b);});
  T.bus=[['#c8332b','#ffc928'],['#1e7a4a','#f4efe2'],['#2753a8','#e8702a'],['#e8e4d8','#c8332b'],['#6a2a8a','#ffc928']].map(([c,s])=>{const b=new Builder();
    b.box(2.5,2.4,10,0,1.6,0,c);b.box(2.54,.85,8.4,0,2.15,.5,'#24303a');b.box(2.54,.22,10,0,1.25,0,s);b.box(2.54,.18,10,0,2.75,0,s);
    b.box(2.3,1.0,.06,0,2.2,-5.01,'#24303a');b.box(.7,1.9,.06,-1.27,1.35,-3.7,'#1a1a1a',Math.PI/2);b.box(2.3,.12,9.4,0,2.86,0,'#aaa');
    b.box(.3,.16,.06,-.9,.75,-5.02,'#fff6c8');b.box(.3,.16,.06,.9,.75,-5.02,'#fff6c8');b.box(.3,.2,.06,-.9,.75,5.02,'#d01818');b.box(.3,.2,.06,.9,.75,5.02,'#d01818');
    b.box(2.4,.4,.15,0,.45,-5.02,'#222');[[-1.12,-3.4],[1.12,-3.4],[-1.12,3.3],[1.12,3.3]].forEach(p=>wheel(b,.52,.32,p[0],.52,p[1]));
    b.tmpl(T.people[3],-1.45,.35,-3.75,Math.PI/2);return merged(b);});
  T.cng=(()=>{const b=new Builder();const g='#2f8a3f';b.box(1.4,.55,2.6,0,.55,0,g);b.box(1.2,.7,.4,0,1.05,-1.2,g);b.box(1.5,.1,2.3,0,1.85,.05,g);
    for(const x of[-.7,.7])for(const z of[-1.0,.1,1.1])b.box(.07,1.05,.07,x,1.3,z,'#1a1a1a');
    for(const x of[-.72,.72])for(let k=0;k<5;k++)b.box(.03,.9,.03,x,1.3,.2+k*.2,'#333');
    b.box(1.0,.5,.05,0,1.4,-1.0,'#26343d');b.box(.28,.16,.06,0,.8,-1.42,'#fff6c8');
    wheel(b,.28,.2,0,.28,-1.05);wheel(b,.28,.2,-.62,.28,.8);wheel(b,.28,.2,.62,.28,.8);
    b.tmpl(T.seated[3],0,.55,-.5,0);return merged(b);})();
  T.rickshaw=['#c8332b','#1f6fd0','#2e9b57','#e8702a'].map(c=>{const b=new Builder();
    b.cyl(.36,.36,.06,0,.36,-1.1,'#222',12,0,0,Math.PI/2);b.cyl(.5,.5,.06,-.6,.5,.7,'#222',14,0,0,Math.PI/2);b.cyl(.5,.5,.06,.6,.5,.7,'#222',14,0,0,Math.PI/2);
    b.box(.08,.08,1.6,0,.65,-.3,'#444');b.box(.7,.06,.06,0,1.15,-1.15,'#666');b.box(1.1,.3,.7,0,.85,.65,c);b.box(1.1,.6,.12,0,1.25,1.0,c);
    b.box(1.12,.4,.1,0,.75,1.02,'#ffc928');b.tmpl(T.seated[2],0,.8,-.75,0);
    const hood=new THREE.CylinderGeometry(.62,.62,1.0,10,1,true,0,Math.PI);colorize(hood,c);b.put('col',hood,0,1.35,.65,0,0,Math.PI/2,true);
    b.box(1.26,.08,.08,0,1.36,.12,'#ffc928');b.box(1.26,.06,.06,0,1.36,1.18,'#2e9b57');return merged(b);});
  T.bike=['#c8332b','#1a1a1a','#1f4fa0'].map(c=>{const b=new Builder();wheel(b,.32,.1,0,.32,-.7);wheel(b,.32,.1,0,.32,.7);
    b.box(.3,.4,1.2,0,.65,0,c);b.box(.26,.16,.7,0,.9,.15,'#222');b.box(.7,.05,.05,0,1.1,-.6,'#888');
    b.tmpl(personGeo({top:pick(['#e8e2d0','#4a7fb0','#2b2f3a'],CR),hat:'helmet',hatC:pick(['#d02020','#1a1a1a','#ffc928'],CR)}),0,.05,.05,0);return merged(b);});
  T.policeBike=(()=>{const b=new Builder();wheel(b,.34,.12,0,.34,-.75);wheel(b,.34,.12,0,.34,.75);b.box(.36,.45,1.3,0,.68,0,'#f4f4f4');b.box(.38,.2,.5,0,.95,-.55,'#2e3f63');
    b.box(.4,.3,.5,0,.85,.75,'#2e3f63');b.tmpl(T.police,0,.1,.05,0);return merged(b);})();
  T.van=['#f4efe2','#e8c040','#3a6aa0'].map(c=>{const b=new Builder();b.box(2,.5,5,0,.6,0,'#333');b.box(2,1.6,1.4,0,1.45,-1.75,c);b.box(1.9,.55,.06,0,1.7,-2.46,'#26343d');
    b.box(2.1,2.0,3.4,0,1.9,.7,pick(['#2b6e4f','#8a6a3a','#2a4a8a'],CR));[[-.95,-1.6],[.95,-1.6],[-.95,1.6],[.95,1.6]].forEach(p=>wheel(b,.4,.28,p[0],.4,p[1]));
    b.box(.3,.16,.06,-.7,.85,-2.47,'#fff6c8');b.box(.3,.16,.06,.7,.85,-2.47,'#fff6c8');return merged(b);});
  T.truck=['#e8702a','#2e8b57','#c8332b'].map(c=>{const b=new Builder();b.box(2.4,.5,7.2,0,.75,0,'#2a2a2a');
    b.box(2.4,1.9,1.8,0,1.95,-2.65,c);b.box(2.3,.7,.06,0,2.35,-3.56,'#26343d');b.box(2.42,.35,1.82,0,2.85,-2.65,'#ffc928');
    b.box(2.5,1.7,5,0,1.85,.95,'#8a5a2a');b.box(2.52,.25,5.02,0,2.65,.95,'#ffc928');b.box(2.3,.9,4.6,0,2.9,.95,'#3a6a3a');
    [[-1.1,-2.6],[1.1,-2.6],[-1.1,1.6],[1.1,1.6],[-1.1,2.8],[1.1,2.8]].forEach(p=>wheel(b,.5,.35,p[0],.5,p[1]));
    b.box(.3,.16,.06,-.85,1.2,-3.57,'#fff6c8');b.box(.3,.16,.06,.85,1.2,-3.57,'#fff6c8');return merged(b);});
  T.cow=['#f0ece2','#8a4a2a'].map(c=>{const b=new Builder();b.box(.9,.85,1.9,0,1.15,0,c);b.box(.5,.5,.6,0,1.35,-1.15,c);b.box(.36,.3,.3,0,1.25,-1.5,'#d8b8a8');
    for(const x of[-.3,.3])for(const z of[-.7,.7])b.box(.16,.8,.16,x,.4,z,c);b.box(.06,.25,.06,-.2,1.7,-1.1,'#e8e0c8');b.box(.06,.25,.06,.2,1.7,-1.1,'#e8e0c8');
    b.box(.05,.7,.05,0,1.0,.98,'#5a3a2a');b.box(.3,.2,.3,0,1.48,-.1,'#d8d0c0');return merged(b);});
  T.duck=(()=>{const b=new Builder();b.sph(.2,0,.28,0,'#f6f4ee',1,.85,1.4);b.sph(.11,0,.5,-.2,'#f6f4ee');b.box(.08,.04,.12,0,.48,-.33,'#f0a020');
    b.box(.04,.16,.04,-.07,.08,0,'#f0a020');b.box(.04,.16,.04,.07,.08,0,'#f0a020');return merged(b);})();
  T.cart=(()=>{const b=new Builder();b.box(1.3,.12,2.0,0,.75,0,'#8a5a2a');b.cyl(.4,.4,.08,-.7,.4,0,'#3a2a1a',10,0,0,Math.PI/2);b.cyl(.4,.4,.08,.7,.4,0,'#3a2a1a',10,0,0,Math.PI/2);
    for(let i=0;i<14;i++)b.box(.22,.2,.22,rr(-.5,.5,CR),.92+CR()*.2,rr(-.8,.8,CR),pick(['#f2a23a','#f4d03f','#7cb342','#e74c3c'],CR));b.box(.05,.05,1.0,-.4,.9,1.4,'#6a4a2a');b.box(.05,.05,1.0,.4,.9,1.4,'#6a4a2a');
    return merged(b);})();
  T.barricade=(()=>{const b=new Builder();for(let i=0;i<5;i++)b.box(.4,.35,.12,-.8+i*.4,.75,0,i%2?'#f4f4f4':'#e0412f');b.box(.08,.9,.08,-.9,.45,0,'#333');b.box(.08,.9,.08,.9,.45,0,'#333');return merged(b);})();
  T.drum=(()=>{const b=new Builder();b.cyl(.25,.25,.4,0,1.1,-.35,'#e8b030',10,0,Math.PI/2,0);return merged(b);})();
  T.cone=(()=>{const b=new Builder();b.box(.5,.06,.5,0,.03,0,'#222');b.cone(.2,.7,0,.4,0,'#ff6a1a',8);b.cyl(.13,.16,.1,0,.42,0,'#f4f4f4',8);return merged(b);})();
  T.crate=(()=>{const b=new Builder();b.box(.6,.42,.45,0,.21,0,'#2a6ad0');b.box(.62,.05,.47,0,.4,0,'#1a4aa0');return merged(b);})();
  T.sack=(()=>{const b=new Builder();b.box(.7,.35,.45,0,.18,0,'#c8b890');b.box(.66,.3,.42,.05,.5,.02,'#d0c098');return merged(b);})();
  T.stumps=(()=>{const b=new Builder();for(const x of[-.12,0,.12])b.box(.04,.7,.04,x,.35,0,'#e8d8a8');b.box(.3,.03,.04,0,.71,0,'#c8a868');return merged(b);})();
  T.bat=(()=>{const b=new Builder();b.box(.1,.55,.04,0,.28,0,'#d8b878');b.box(.04,.25,.04,0,.68,0,'#3a2a1a');return merged(b);})();
  T.tesla=['#2e8bd0','#2e9b57','#d0452e','#e8b030'].map(c=>{const b=new Builder();// battery auto-rickshaw ("easy bike")
    b.box(1.35,.35,2.7,0,.55,0,'#3a3a3a');b.box(1.3,.7,.9,0,.95,-.95,c);b.box(1.2,.6,.06,0,1.55,-1.38,'#26343d');b.box(1.45,.08,2.7,0,2.05,0,c);
    for(const x of[-.66,.66])for(const z of[-1.3,1.25])b.box(.06,1.3,.06,x,1.4,z,'#cfcfcf');b.box(1.3,.35,.6,0,.85,.65,'#7a4a2a');b.box(1.3,.35,.6,0,.85,-.15,'#7a4a2a');
    b.box(1.0,.3,.5,0,.4,.3,'#1a1a1a');b.box(.3,.16,.06,0,.85,-1.42,'#fff6c8');wheel(b,.3,.18,0,.3,-1.05);wheel(b,.3,.18,-.62,.3,.95);wheel(b,.3,.18,.62,.3,.95);
    b.tmpl(T.seated[1],0,.75,-.55,0);b.tmpl(T.seated[4],-.3,.75,.6,Math.PI);b.tmpl(T.seated[0],.3,.75,.6,Math.PI);return merged(b);});
  T.mom=personGeo({style:'salwar',top:'#c03a7a',low:'#e8c040',hat:'scarf',hatC:'#7a2a8a'});
  T.teacher=personGeo({top:'#f1ece0',low:'#5b4a3a',skin:'#a86f4c',hat:'tupi'});
  T.dd=(()=>{const b=new Builder();const red='#c8262a';b.box(2.6,4.1,10.5,0,2.3,0,red);b.box(2.64,.9,9.0,0,1.95,.45,'#24303a');b.box(2.64,.85,9.6,0,3.55,0,'#24303a');
    b.box(2.64,.2,10.5,0,2.75,0,'#f4efe2');b.box(2.64,.12,10.5,0,1.2,0,'#f4efe2');b.box(2.4,.9,.06,0,3.55,-5.26,'#24303a');b.box(2.3,.8,.06,0,1.95,-5.26,'#24303a');
    b.box(.3,.16,.06,-.9,.75,-5.27,'#fff6c8');b.box(.3,.16,.06,.9,.75,-5.27,'#fff6c8');b.box(.3,.2,.06,-.9,.75,5.27,'#d01818');b.box(.3,.2,.06,.9,.75,5.27,'#d01818');
    b.box(2.3,.8,.06,0,3.55,5.26,'#24303a');b.box(1.6,.5,.06,0,1.9,5.26,'#24303a');b.box(2.3,.35,.06,0,1.0,5.27,'#f4efe2');b.box(.7,1.9,.06,-1.31,1.35,-3.9,'#1a1a1a',Math.PI/2);[[-1.15,-3.6],[1.15,-3.6],[-1.15,3.4],[1.15,3.4]].forEach(p=>wheel(b,.54,.34,p[0],.54,p[1]));return merged(b);})();
  T.mat=(()=>{const b=new Builder();b.box(1.5,.03,1.3,0,.015,0,'#c8a868');for(let i=0;i<10;i++)b.box(.2,.14,.2,rr(-.6,.6,CR),.09,rr(-.5,.5,CR),pick(['#7cb342','#e74c3c','#f4d03f','#f2a23a','#8bc34a'],CR));
    b.tmpl(seatedGeo('#d8d0b8'),.55,0,.55,-Math.PI/2);return merged(b);})();
  T.hole=(()=>{const b=new Builder();b.cyl(.42,.42,.02,0,.01,0,'#0a0a0a',12);b.cyl(.48,.48,.03,0,.0,0,'#5a5a5a',12);b.box(.6,.5,.06,.55,.25,.1,'#5a5a5a',0,.6);return merged(b);})();
  T.dog=(()=>{const b=new Builder();const c='#b8864a';b.box(.32,.3,.75,0,.4,0,c);b.box(.26,.24,.3,0,.55,-.45,c);b.box(.16,.12,.16,0,.5,-.65,'#8a5a2a');
    for(const x of[-.11,.11])for(const z of[-.25,.25])b.box(.08,.3,.08,x,.15,z,c);b.box(.06,.06,.3,0,.55,.45,c,0,.6);b.box(.07,.12,.05,-.08,.7,-.45,'#7a4a1a');b.box(.07,.12,.05,.08,.7,-.45,'#7a4a1a');return merged(b);})();
  T.parkedBike=(()=>{const b=new Builder();wheel(b,.32,.1,0,.32,-.7);wheel(b,.32,.1,0,.32,.7);b.box(.3,.4,1.2,0,.65,0,'#c8332b');b.box(.26,.16,.7,0,.9,.15,'#222');b.box(.7,.05,.05,0,1.1,-.6,'#888');return merged(b);})();
  T.trainCar=(()=>{const b=new Builder();b.box(2.9,3.2,13.6,0,1.6,0,'#f4f4f2');b.box(2.92,.9,12.8,0,2.2,0,'#2a3a48');b.box(2.94,.22,13.62,0,1.45,0,'#d8262c');b.box(2.94,.16,13.62,0,1.2,0,'#0e7a3c');
    b.box(2.6,.3,13,0,3.3,0,'#cfd4d8');return merged(b);})();
  T.trainNose=(()=>{const b=new Builder();b.box(2.9,3.2,1.6,0,1.6,0,'#f4f4f2');b.box(2.4,1.2,.08,0,2.2,-.8,'#1a2a38');b.box(.4,.2,.06,-.9,.9,-.82,'#fffbe0');b.box(.4,.2,.06,.9,.9,-.82,'#fffbe0');return merged(b);})();
  T.ball=new THREE.SphereGeometry(.11,10,8);
  T.pickRing=new THREE.RingGeometry(.7,.95,24);T.pickRing.rotateX(-Math.PI/2);
  T.lampGeo=new THREE.SphereGeometry(.17,8,6);
  T.boardGeo=new THREE.PlaneGeometry(1.9,.45);T.artGeo=new THREE.PlaneGeometry(1.0,.55);T.truckArtGeo=new THREE.PlaneGeometry(2.3,1.2);
  T.shadowGeo=new THREE.PlaneGeometry(1,1);T.shadowGeo.rotateX(-Math.PI/2);
  T.plane=new THREE.PlaneGeometry(1,1);T.plane.rotateX(-Math.PI/2);
}
/* ---------- you (the commuter) ---------- */
const YOU={office:{top:'#4a7fb0',low:'#2b2f3a',bag:'#4a2e1a',skin:'#a86f4c'},varsity:{top:'#e8702a',low:'#3a4a6a',bag:'#2e9b57',skin:'#a86f4c'}};
function youLook(){const tr=(ROUTE.trip&&ROUTE.trip.D&&ROUTE.trip.D.track)||SETTINGS.track;return YOU[tr]||YOU.office;}
/* articulated person: legs and arms swing */
function makeRig(look,o){o=o||{};const g=new THREE.Group(),M=(geo,c)=>new THREE.Mesh(colorize(geo,c),MATS.col),parts={};
  const torso=M(new THREE.BoxGeometry(.5,.66,.3),look.top);torso.position.y=1.18;g.add(torso);
  const neck=M(new THREE.BoxGeometry(.14,.1,.14),look.skin);neck.position.y=1.55;g.add(neck);
  const head=M(new THREE.SphereGeometry(.17,10,8),look.skin);head.position.y=1.74;g.add(head);
  const hair=M(new THREE.SphereGeometry(.175,10,5,0,TAU,0,Math.PI/2),'#15110d');hair.scale.set(1,.6,1);hair.position.set(0,1.79,.02);g.add(hair);
  for(const s of[-1,1]){const hip=new THREE.Group();hip.position.set(s*.11,.86,0);const leg=M(new THREE.BoxGeometry(.17,.85,.2),look.low);leg.position.y=-.43;hip.add(leg);
    const shoe=M(new THREE.BoxGeometry(.18,.08,.28),'#1a1a1a');shoe.position.set(0,-.84,-.04);hip.add(shoe);g.add(hip);parts[s<0?'hipL':'hipR']=hip;
    const sh=new THREE.Group();sh.position.set(s*.33,1.46,0);const arm=M(new THREE.BoxGeometry(.13,.6,.14),look.top);arm.position.y=-.3;sh.add(arm);
    const hand=M(new THREE.BoxGeometry(.12,.12,.12),look.skin);hand.position.y=-.64;sh.add(hand);g.add(sh);parts[s<0?'shL':'shR']=sh;}
  if(o.backpack!==false){const tr=(ROUTE.trip&&ROUTE.trip.D&&ROUTE.trip.D.track)||SETTINGS.track;
    if(tr==='varsity'){const bp=M(new THREE.BoxGeometry(.42,.5,.2),look.bag);bp.position.set(0,1.16,.25);g.add(bp);}
    else{const bag=M(new THREE.BoxGeometry(.08,.3,.4),look.bag);bag.position.set(0,-.72,0);parts.shR.add(bag);}}
  parts.torso=torso;parts.head=head;return{g,parts};}
function animRig(rig,ph,amp,armAmp){const p=rig.parts,s=Math.sin(ph)*amp;p.hipL.rotation.x=s;p.hipR.rotation.x=-s;const a=Math.sin(ph)*(armAmp==null?amp*.8:armAmp);p.shL.rotation.x=-a;p.shR.rotation.x=a;}
function routeBoardTex(text){return canvasTex(256,64,(g,w,h)=>{g.fillStyle='#101010';g.fillRect(0,0,w,h);g.fillStyle='#ffd23a';g.textAlign='center';g.textBaseline='middle';fitText(g,text,w-16,40,'800',FONT_D);g.fillText(text,w/2,h/2+3);});}
/* player models: every mode of the morning */
function buildPlayerModel(kind){const g=new THREE.Group(),body=new THREE.Group();g.add(body);const parts={wheels:[]};
  const mesh=(geo,mat)=>new THREE.Mesh(geo,mat||MATS.col);
  const boxM=(w,h,d,c,x,y,z,mat)=>{const m=mesh(colorize(new THREE.BoxGeometry(w,h,d),c),mat);m.position.set(x,y,z);return m;};
  const wheelM=(r,w,x,y,z,host)=>{const m=mesh(colorize(new THREE.CylinderGeometry(r,r,w,12).rotateZ(Math.PI/2),'#151515'));m.position.set(x,y,z);(host||g).add(m);parts.wheels.push(m);return m;};
  const look=youLook();
  if(kind==='walk'){const rig=makeRig(look);body.add(rig.g);parts.rig=rig;parts.w=.6;parts.l=.5;}
  else if(kind==='cycle'){const b=new Builder();b.box(.06,.06,1.0,0,.62,0,'#c8332b',0,.35);b.box(.06,.62,.06,0,.62,.3,'#c8332b');b.box(.06,.06,.75,0,.9,-.05,'#c8332b');
      b.box(.06,.6,.06,0,.65,-.45,'#c8332b',0,0,0);b.box(.6,.05,.05,0,1.08,-.48,'#999');b.box(.22,.06,.3,0,.98,.33,'#1a1a1a');b.box(.3,.04,.12,0,.36,0,'#333');
      body.add(mesh(merged(b)));wheelM(.36,.05,0,.36,-.6,body);wheelM(.36,.05,0,.36,.62,body);
      const rig=makeRig(look,{backpack:true});rig.g.position.set(0,.2,.25);rig.g.rotation.x=-.18;rig.parts.shL.rotation.x=-1.0;rig.parts.shR.rotation.x=-1.0;body.add(rig.g);parts.rig=rig;
      parts.head=boxM(.12,.08,.04,'#fffbe0',0,1.02,-.6,MATS.light);body.add(parts.head);parts.w=.7;parts.l=1.8;}
  else if(kind==='rickshaw'){const b=new Builder();
      b.box(.08,.08,1.6,0,.65,-.3,'#444');b.box(.7,.06,.06,0,1.15,-1.15,'#666');b.box(1.1,.3,.7,0,.85,.65,'#c8332b');b.box(1.1,.6,.12,0,1.25,1.0,'#c8332b');
      b.box(1.12,.4,.1,0,.75,1.02,'#ffc928');b.box(.36,.08,.5,0,1.05,-.75,'#222');
      const hood=new THREE.CylinderGeometry(.62,.62,1.0,10,1,true,0,Math.PI);colorize(hood,'#c8332b');b.put('col',hood,0,1.35,.65,0,0,Math.PI/2,true);
      b.box(1.26,.08,.08,0,1.36,.12,'#ffc928');b.box(1.26,.06,.06,0,1.36,1.18,'#2e9b57');b.tmpl(seatedGeo(look.top,look.skin),0,.8,.55,0);
      body.add(mesh(merged(b)));const art=new THREE.Mesh(T.artGeo,MATS.rart);art.position.set(0,1.25,1.07);body.add(art);
      const rider=mesh(personGeo({style:'lungi',top:'#e8e2d0',low:'#3a6aa0',hat:'cap',hatC:'#f4f1e8'}));rider.position.set(0,.15,-.78);body.add(rider);parts.rider=rider;
      parts.head=boxM(.24,.14,.06,'#fff',0,.6,-1.22,MATS.light);body.add(parts.head);
      wheelM(.36,.1,0,.36,-1.1);wheelM(.5,.1,-.6,.5,.7);wheelM(.5,.1,.6,.5,.7);parts.w=1.3;parts.l=2.7;}
  else if(kind==='cng'){const b=new Builder();const gr='#2f8a3f';b.box(1.4,.55,2.6,0,.55,0,gr);b.box(1.2,.7,.4,0,1.05,-1.2,gr);b.box(1.5,.1,2.3,0,1.85,.05,gr);
      for(const x of[-.7,.7])for(const z of[-1.0,.1,1.1])b.box(.07,1.05,.07,x,1.3,z,'#1a1a1a');
      for(const x of[-.72,.72])for(let k=0;k<5;k++)b.box(.03,.9,.03,x,1.3,.2+k*.2,'#333');
      b.box(1.0,.5,.05,0,1.4,-1.0,'#26343d');b.tmpl(T.seated[3],0,.55,-.5,0);b.box(1.2,.3,.5,0,.75,.65,'#5a3a2a');b.tmpl(seatedGeo(look.top,look.skin),0,.6,.6,0);
      body.add(mesh(merged(b)));parts.head=boxM(.28,.16,.06,'#fff6c8',0,.8,-1.42,MATS.light);body.add(parts.head);
      wheelM(.28,.2,0,.28,-1.05);wheelM(.28,.2,-.62,.28,.8);wheelM(.28,.2,.62,.28,.8);parts.w=1.5;parts.l=2.8;}
  else if(kind==='bus'||kind==='dd'){const dd=kind==='dd';
      if(dd){body.add(mesh(T.dd));const side=new THREE.Mesh(new THREE.PlaneGeometry(3.2,.5),new THREE.MeshBasicMaterial({map:canvasTex(256,40,(g2,w,h)=>{g2.fillStyle='#c8262a';g2.fillRect(0,0,w,h);g2.fillStyle='#fff';g2.textAlign='center';g2.textBaseline='middle';fitText(g2,'বিআরটিসি',w-10,30,'800',FONT_D);g2.fillText('বিআরটিসি',w/2,h/2+2);})}));
        side.position.set(-1.32,4.0,1.5);side.rotation.y=-Math.PI/2;body.add(side);}
      else{const b=new Builder();const c='#1e7a4a',st='#f4efe2';b.box(2.5,2.4,10,0,1.6,0,c);b.box(2.54,.85,8.4,0,2.15,.5,'#24303a');b.box(2.54,.22,10,0,1.25,0,st);b.box(2.54,.18,10,0,2.75,0,st);
        b.box(2.3,1.0,.06,0,2.2,-5.01,'#24303a');b.box(.7,1.9,.06,-1.27,1.35,-3.7,'#1a1a1a',Math.PI/2);b.box(2.3,.12,9.4,0,2.86,0,'#aaa');
        b.box(.3,.16,.06,-.9,.75,-5.02,'#fff6c8');b.box(.3,.16,.06,.9,.75,-5.02,'#fff6c8');b.box(.3,.2,.06,-.9,.75,5.02,'#d01818');b.box(.3,.2,.06,.9,.75,5.02,'#d01818');
        b.box(2.4,.4,.15,0,.45,-5.02,'#222');b.box(2.3,.5,.06,-.02,1.0,5.03,'#c8332b');body.add(mesh(merged(b)));
        for(const p of[[-1.12,-3.4],[1.12,-3.4],[-1.12,3.3],[1.12,3.3]])wheelM(.52,.32,p[0],.52,p[1]);}
      if(dd)for(const p of[[-1.15,-3.6],[1.15,-3.6],[-1.15,3.4],[1.15,3.4]])wheelM(.54,.34,p[0],.54,p[1]);
      const H=dd?4.45:2.98,ZB=dd?5.28:5.04,txt=ROUTE.trip?(ROUTE.trip.H.name+' — '+ROUTE.trip.D.name):'মিরপুর — মতিঝিল';
      const bm=new THREE.MeshBasicMaterial({map:routeBoardTex(txt)});for(const zz of[-ZB,ZB]){const bp=new THREE.Mesh(T.boardGeo,bm);bp.position.set(0,H,zz);if(zz<0)bp.rotation.y=Math.PI;body.add(bp);}
      const helper=mesh(T.people[3]);helper.position.set(dd?-1.5:-1.45,.35,dd?-3.95:-3.75);helper.rotation.y=Math.PI/2;body.add(helper);parts.helper=helper;
      parts.head=boxM(.5,.2,.06,'#fff',0,.75,-ZB-.01,MATS.light);body.add(parts.head);parts.w=dd?2.6:2.5;parts.l=dd?10.5:10;}
  else if(kind==='metro'){parts.cars=[];for(let i=0;i<6;i++){const cg=new THREE.Group();cg.add(mesh(T.trainCar));if(i===0||i===5){const nose=mesh(T.trainNose);nose.position.z=i===0?-7.5:7.5;if(i===5)nose.rotation.y=Math.PI;cg.add(nose);}
        if(i===0){const l=boxM(.6,.25,.06,'#fff',0,.9,-8.32,MATS.light);cg.add(l);}parts.cars.push(cg);}parts.w=2.9;parts.l=14;}
  else if(kind==='bike'){const b=new Builder();b.box(.34,.42,1.3,0,.66,0,'#1f8fa0');b.box(.3,.18,.75,0,.95,.15,'#1a1a1a');b.box(.75,.05,.05,0,1.15,-.62,'#999');
      b.box(.36,.22,.3,0,.95,-.62,'#1f8fa0');body.add(mesh(merged(b)));
    const rider=mesh(personGeo({top:'#f4efe2',low:'#2b2f3a',hat:'helmet',hatC:'#ffc928'}));rider.position.set(0,.08,.08);body.add(rider);parts.rider=rider;
    parts.head=boxM(.16,.1,.05,'#fffbe0',0,.98,-.78,MATS.light);body.add(parts.head);
    parts.wheels=[];for(const z of[-.72,.72]){const w=mesh(colorize(new THREE.CylinderGeometry(.33,.33,.12,12).rotateZ(Math.PI/2),'#151515'));w.position.set(0,.33,z);g.add(w);parts.wheels.push(w);}
    parts.w=.8;parts.l=2.1;}
  else{const old=kind==='old';const c=old?'#6f8a5a':'#1f8fa0',trim=old?'#c8b48a':'#f4efe2';
    const b=new Builder();b.box(1.86,.6,4.4,0,.66,0,c);b.box(1.66,.58,2.2,0,1.24,.3,'#22323b');b.box(1.7,.09,2.0,0,1.57,.35,old?c:trim);
    b.box(1.88,.1,4.42,0,.92,0,trim);
    if(old){b.box(.5,.3,.6,.55,.85,.9,'#8a5a3a');b.box(.45,.25,.5,-.6,.7,-.6,'#9a6a3a');b.box(1.3,.08,1.4,0,1.66,.35,'#3a3a3a');b.box(.9,.4,.7,0,1.9,.3,'#c8332b');b.box(.7,.3,.5,.1,2.2,.2,'#e8c040');}
    else{b.box(1.4,.06,1.2,0,1.66,.35,'#444');for(const x of[-.65,.65])b.box(.06,.1,1.4,x,1.66,.35,'#555');}
    body.add(mesh(merged(b)));
    parts.hood=boxM(1.8,.08,1.35,c,0,.99,-1.45);body.add(parts.hood);
    parts.bumperF=boxM(1.92,.24,.24,'#2a2a2a',0,.44,-2.2);body.add(parts.bumperF);
    parts.bumperR=boxM(1.92,.24,.24,'#2a2a2a',0,.44,2.2);body.add(parts.bumperR);
    parts.headL=boxM(.36,.16,.06,'#fff',-.64,.8,-2.21,MATS.light);parts.headR=boxM(.36,.16,.06,'#fff',.64,.8,-2.21,MATS.light);body.add(parts.headL,parts.headR);
    parts.tailL=boxM(.36,.16,.06,'#fff',-.64,.8,2.21,MATS.tail);parts.tailR=boxM(.36,.16,.06,'#fff',.64,.8,2.21,MATS.tail);body.add(parts.tailL,parts.tailR);
    parts.mirrorL=boxM(.25,.16,.12,c,-1.02,1.12,-.55);parts.mirrorR=boxM(.25,.16,.12,c,1.02,1.12,-.55);body.add(parts.mirrorL,parts.mirrorR);
    const st=new THREE.Mesh(new THREE.PlaneGeometry(.95,.24),MATS.sticker);st.position.set(0,1.18,1.42);st.rotation.x=-.5;body.add(st);
    parts.wheels=[];[[-.9,-1.4],[.9,-1.4],[-.9,1.4],[.9,1.4]].forEach(p=>{const w=mesh(colorize(new THREE.CylinderGeometry(.34,.34,.26,12).rotateZ(Math.PI/2),'#151515'));w.position.set(p[0],.34,p[1]);
      w.rotation.order='YXZ';g.add(w);parts.wheels.push(w);});
    parts.w=1.9;parts.l=4.4;}
  if(kind!=='metro'){const sh=new THREE.Mesh(T.shadowGeo,MATS.shadow);sh.scale.set(parts.w+.7,1,parts.l+.8);sh.position.y=.03;g.add(sh);}
  return{group:g,body,parts};}
