/* ============================================================
   10 UI: HUD, journey strip, touch, menus, planner, morning,
   results (stamp → stars → score → XP → unlocks), share card
   ============================================================ */
function logEv(s){GAME.log.push(s);}
function addTime(sec){GAME.clock+=sec;GAME.penalty=(GAME.penalty||0)+sec;const c=$('clockBox');c.animate&&c.animate([{transform:'scale(1.14)'},{transform:'scale(1)'}],{duration:400});}
let toastT=null;
function toastMsg(text,cls,ms){const el=$('toast');el.textContent=text;el.className='on '+(cls||'');clearTimeout(toastT);toastT=setTimeout(()=>{el.className=cls||'';},ms||2600);}
const alertMsg=(t,c)=>toastMsg(t,c||'bad');
function popMsg(text){const box=$('pops');const el=document.createElement('div');el.className='pop';el.textContent=text;box.appendChild(el);while(box.children.length>2)box.firstChild.remove();setTimeout(()=>el.remove(),1300);}

/* ---------- mode icons (simple, consistent glyphs) ---------- */
const ICO={
  walk:'<path d="M13 4a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM9.6 7.4l-3 1.6-1.4 4 1.7.6 1.1-3 1.3-.6-1.3 6-3.2 4.8 1.6 1.1 3.4-5 1.6 1.9v4.4h2v-5.2l-2.1-2.6.7-3.3.7 1.3 3.3 1.5.8-1.8-2.7-1.2-1.4-2.7c-.4-.8-1.2-1.3-2.1-1.3h-.9z"/>',
  bus:'<path d="M4 4.5C4 3 5.5 2 8 2h8c2.5 0 4 1 4 2.5V17c0 .8-.4 1.4-1 1.7V21h-2.5v-2h-9v2H5v-2.3c-.6-.3-1-.9-1-1.7zm2 2V11h12V6.5zM7 15.5a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4zm10 0a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4zM9 3.5h6v1.5H9z"/>',
  dd:'<path d="M3 3.5C3 2.7 3.7 2 4.5 2h15c.8 0 1.5.7 1.5 1.5V18c0 .6-.4 1-1 1h-1.2a2.3 2.3 0 0 1-4.5 0H9.7a2.3 2.3 0 0 1-4.5 0H4c-.6 0-1-.4-1-1zm2 1.5v3.5h14V5zm0 6v3.5h14V11zm2.4 10a1.3 1.3 0 1 0 0-2.6 1.3 1.3 0 0 0 0 2.6zm9.2 0a1.3 1.3 0 1 0 0-2.6 1.3 1.3 0 0 0 0 2.6z"/>',
  metro:'<path d="M6 3h12c1.7 0 3 1.3 3 3v9c0 1.5-1 2.7-2.4 3l1.9 2.5h-2.5l-1.6-2.4H7.6L6 20.5H3.5L5.4 18A3 3 0 0 1 3 15V6c0-1.7 1.3-3 3-3zm-1 4v4h6V7zm8 0v4h6V7zM7 16a1.2 1.2 0 1 0 0-2.4A1.2 1.2 0 0 0 7 16zm10 0a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4z"/>',
  rickshaw:'<path d="M11 3c3.9 0 7 2.6 7.6 6H11zM10 10h9.5l-1 3H14l-2 3.4A3.5 3.5 0 1 1 9.9 13l1.4-1.6zM7 15a1.8 1.8 0 1 0 0 3.6A1.8 1.8 0 0 0 7 15zm12-1.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0 1.8a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4zM3 9h4l3 4H8.2L5.8 10.6 3.5 14.5 2 13.6z"/>',
  cng:'<path d="M9 3h9a3 3 0 0 1 3 3v9h-1.2a2.8 2.8 0 0 0-5.5 0H9.7a2.8 2.8 0 0 0-5.4-.3L3 14.5V9.5L6.5 4.4C7 3.5 8 3 9 3zm-.5 2L5.5 9.5h4V5zm3 0v4.5H19V6c0-.6-.4-1-1-1zM7 14.3a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/>',
  bike:'<path d="M14 5h3l3 5.2A4 4 0 1 1 17 14a4 4 0 0 1 1.3-2.9l-.6-1L14.5 15H10a4 4 0 1 1-1.6-4.5L10 9H7V7h6.2L14.6 9h1.4L15 7h-1zm-9 7a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm16 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/>',
  car:'<path d="M6.3 6.4C6.8 5 8 4 9.5 4h5c1.5 0 2.7 1 3.2 2.4l1.3 3.6c1.2.3 2 1.4 2 2.6V17c0 .6-.4 1-1 1h-1v1.5c0 .8-.7 1.5-1.5 1.5S16 20.3 16 19.5V18H8v1.5C8 20.3 7.3 21 6.5 21S5 20.3 5 19.5V18H4c-.6 0-1-.4-1-1v-4.4c0-1.2.8-2.3 2-2.6zm1.9.6L7.2 10h9.6l-1-3c-.2-.6-.7-1-1.3-1h-5c-.6 0-1.1.4-1.3 1zM6.5 15.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm11 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/>',
  cycle:'<path d="M14.5 5a1.8 1.8 0 1 1 0 3.6 1.8 1.8 0 0 1 0-3.6zM11.6 9.5l2.3 2.1H17v2h-3.9l-1.9-1.7-1.6 1.6 2.3 2v5h-2v-4.1L7 13.5a1.4 1.4 0 0 1 0-2l2.5-2.5c.6-.6 1.5-.6 2.1.5zM5 14.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7zm0 1.7a1.8 1.8 0 1 0 0 3.6 1.8 1.8 0 0 0 0-3.6zm14-1.7a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7zm0 1.7a1.8 1.8 0 1 0 0 3.6 1.8 1.8 0 0 0 0-3.6z"/>',
  office:'<path d="M4 21V5l9-3v19zm11 0V9h5v12zM6.5 7h4v2h-4zm0 4h4v2h-4zm0 4h4v2h-4zm10-3h2v2h-2zm0 4h2v2h-2z"/>',
  campus:'<path d="M12 2 1 7.5 12 13l9-4.5V15h2V7.5zM5 11.2V16c0 1.8 3.1 4 7 4s7-2.2 7-4v-4.8L12 15z"/>',
  star:'<path d="M12 2.5l2.9 6.2 6.6.7-4.9 4.5 1.4 6.6L12 17.2l-6 3.3 1.4-6.6-4.9-4.5 6.6-.7z"/>'};
function modeIcon(t){return'<svg viewBox="0 0 24 24" aria-hidden="true">'+(ICO[t]||ICO.walk)+'</svg>';}

/* ---------- HUD: journey strip + nav ---------- */
function updateJourneyStrip(){const box=$('chain');if(!box)return;let h='';JR.legs.forEach((L,i)=>{if(i)h+='<i class="ar"></i>';h+='<span class="lg'+(i<JR.li?' done':i===JR.li?' on':'')+'" title="'+LEG_NAME[L.type]+'">'+modeIcon(L.type)+'</span>';});
  const D=ROUTE.trip?ROUTE.trip.D:null;if(D)h+='<i class="ar"></i><span class="lg">'+modeIcon(D.track==='varsity'?'campus':'office')+'</span><span class="dest">'+esc(D.name)+'</span>';box.innerHTML=h;}
function mStr(m){m=Math.max(0,m);return m>=1000?bn((m/1000).toFixed(1))+' কিমি':bn(Math.round(m/10)*10)+' মি';}
function nextTurn(){for(const j of P.node.juncs){if(j.d1<=P.d)continue;return j;}return null;}
function navText(){const L=JR.leg;if(!L)return['',''];const n=ROUTE.root,D=ROUTE.trip.D,dest=D.track==='varsity'?'ক্যাম্পাস':'অফিস',left=n.officeD-P.d;
  const t=L.type;let now=false,main='',sub='';
  if(t==='walk'){if(L.to==='stop'){const s=JR.legs[JR.li+1].stops?n.stops[0]:null;main='বাস স্টপ'+(s?' ('+s.name+')':'')+' · '+mStr(L.d1-P.d);sub='ফুটপাত ধরে হাঁটো · খোলা ম্যানহোল সাবধান!';}
    else{main=dest+' · '+mStr(left);sub=(legAt(n,P.d).road||'')+(JR.walk&&JR.walk.stam<.15?' · দম নাই!':'');}}
  else if(t==='bus'||t==='dd'){const T=L.target,td=T.d-P.d,B=JR.bus;
    if(B&&B.boardT>0){main='বাসে উঠলে! দাঁড়ানোর জায়গা খোঁজো';sub='ভাড়া ৳'+bn(t==='dd'?25:30)+' দিলে';}
    else if(B&&B.knocked){main='থামছে: '+T.name+' · '+mStr(td);sub='নামার জন্য তৈরি হও';}
    else{main='তোমার স্টপ: '+T.name+' · '+mStr(td);const ns=nextStop(n,P.d);sub=td<190?'এখন "ওস্তাদ, নামবো!" বলো ('+(TOUCH.on?'লাল বোতাম':'E')+')':(ns?'পরের স্টপ: '+ns.name:'');now=td<190&&td>0;}}
  else if(t==='rickshaw'){main='স্টেশন: '+JR.legs[1].A.name+' · '+mStr(L.d1-P.d);sub=(legAt(n,P.d).road||'')+(P.boost<.08?' · মামা হাঁপাচ্ছে!':'');}
  else if(t==='metro'){const M=JR.metro,st=M?M.stations[M.si]:null;main=st?(st===L.B?'তোমার স্টেশন: '+st.name:'পরের স্টেশন: '+st.name):'';sub='নামবে: '+L.B.name+' · '+bn(Math.max(0,M?M.stations.length-M.si:0))+'টা স্টেশন বাকি';}
  else{const j=nextTurn();if(t==='car'&&left<90){main='P বে-তে পার্ক করো · বাম দিকে';sub=mStr(left);now=true;}
    else if(j&&j.d0-P.d<220){const dist=j.d0-P.d;if(j.kind==='cross'){const sig=[...WORLD.signals.values()].find(s=>s.j===j);main=sig&&sig.state!=='green'&&dist>-2?'লাল বাতি! থামো':'সামনে সিগন্যাল · '+mStr(dist);now=sig&&sig.state==='red'&&dist<60&&dist>-2;}
      else{const dir=j.sg>0?'বামে':'ডানে';main=P.d>=j.d0-6?'এখন '+dir+' ঘোরো!':dir+' মোড় · '+mStr(dist);now=P.d>=j.d0-6;}sub=dest+' '+mStr(left);}
    else{main=dest+' · '+mStr(left);sub=legAt(n,P.d).road||'';}}
  return[main,sub,now];}

/* ---------- minimap ---------- */
const MINI={ctx:null};
function miniInit(){MINI.ctx=$('mini').getContext('2d');}
function drawMini(){const c=MINI.ctx,W=248,cx=W/2,cy=W*.62,sc=W/280;if(!c)return;const n=ROUTE.root;c.clearRect(0,0,W,W);c.save();c.beginPath();c.arc(W/2,W/2,W/2-2,0,TAU);c.clip();
  c.fillStyle='rgba(6,42,30,.55)';c.fillRect(0,0,W,W);const ca=Math.cos(PW.a),sa=Math.sin(PW.a);
  const tx=(x,z)=>{const dx=x-PW.x,dz=z-PW.z;return[cx+(dx*ca-dz*sa)*sc,cy+(dx*sa+dz*ca)*sc];};
  c.lineCap='round';c.lineJoin='round';const pts=n.poly;
  for(const pass of[0,1]){c.beginPath();let st=false;for(let i=0;i<pts.length;i+=2){const d=i/2*6;if(pass===0&&d>P.d)continue;if(pass===1&&d<P.d-6)continue;if(d>n.officeD+10)break;
      const dx=pts[i]-PW.x,dz=pts[i+1]-PW.z;if(dx*dx+dz*dz>190*190){st=false;continue;}const[p,r]=tx(pts[i],pts[i+1]);if(!st){c.moveTo(p,r);st=true;}else c.lineTo(p,r);}
    c.strokeStyle=pass?'rgba(255,201,40,.95)':'rgba(200,210,200,.5)';c.lineWidth=13*sc;c.stroke();}
  const mark=(d,col,txt)=>{const f=n.path.pos(d,-8,_f2);let[p,r]=tx(f.x,f.z);const dx=p-W/2,dy=r-W/2,dd=Math.hypot(dx,dy),lim=W/2-14;if(dd>lim){p=W/2+dx/dd*lim;r=W/2+dy/dd*lim;}
    c.fillStyle=col;c.beginPath();c.arc(p,r,9,0,TAU);c.fill();c.fillStyle='#fff3d6';c.font='800 12px '+FONT_D;c.textAlign='center';c.textBaseline='middle';c.fillText(txt,p,r+1);};
  const L=JR.leg;if(L&&(L.type==='bus'||L.type==='dd'))mark(L.target.d,'#1f6fd0','স');else if(L&&L.type==='walk'&&L.to==='stop')mark(L.d1,'#1f6fd0','স');else if(L&&(L.type==='rickshaw'))mark(L.d1,'#d8262c','M');
  mark(n.officeD,'#e0412f','অ');
  c.fillStyle='#1f8fa0';c.strokeStyle='#fff3d6';c.lineWidth=3;c.beginPath();c.moveTo(cx,cy-11);c.lineTo(cx+8,cy+8);c.lineTo(cx,cy+4);c.lineTo(cx-8,cy+8);c.closePath();c.fill();c.stroke();
  c.restore();}

/* ---------- HUD ---------- */
let hudT=0;
function updateHUD(dt){hudT-=dt;if(hudT>0)return;hudT=.1;const cb=$('clockBox');
  const C=GAME.clock,rem=GAME.deadline-C,tr=TRACKS[GAME.track];$('clock').textContent=fmtClock(C);
  if(rem>=0){$('remain').textContent=tr.place+' '+fmtClock(GAME.deadline)+' · বাকি '+fmtMinOnly(rem);cb.classList.remove('late');cb.classList.toggle('tight',rem<5*60);}
  else{$('remain').textContent=tr.late+' '+fmtMinOnly(-rem);cb.classList.add('late');cb.classList.remove('tight');}
  const n=ROUTE.root;$('progFill').style.width=clamp(P.d/n.officeD*100,0,100).toFixed(1)+'%';
  const[m,s,now]=navText();if($('navMain').textContent!==m)$('navMain').textContent=m;if($('navSub').textContent!==s)$('navSub').textContent=s;$('nav').classList.toggle('now',!!now);
  // right plate per mode
  const mode=P.mode,sp=$('spd'),su=$('spdU'),bl=$('boostL');
  if(mode==='walk'){sp.textContent=bn(Math.round(P.v*3.6));su.textContent='কিমি/ঘণ্টা · হাঁটা';bl.textContent='দম';$('boostFill').style.width=((JR.walk?JR.walk.stam:1)*100).toFixed(0)+'%';}
  else if(mode==='stand'||mode==='metro'){sp.textContent=bn(Math.round(Math.abs(P.v)*3.6));su.textContent=mode==='metro'?'মেট্রো':'বাসের গতি';bl.textContent=JR.seat?'বসে আছো 😌':'দাঁড়িয়ে';$('boostFill').style.width=(JR.seat?100:Math.max(0,100-Math.abs(JR.bal)*100)).toFixed(0)+'%';}
  else{sp.textContent=bn(Math.round(Math.abs(P.v)*3.6));su.textContent='কিমি/ঘণ্টা';bl.textContent=P.cfg.stamina?'দম':P.kind==='rickshaw'?'মামার দম':'বুস্ট';$('boostFill').style.width=(P.boost*100).toFixed(0)+'%';}
  const cf=$('comfFill'),cv=clamp(JR.comfort,0,100);cf.style.width=cv.toFixed(0)+'%';cf.className=cv<35?'low':cv<65?'mid':'';
  const ch=[];if(GAME.shield)ch.push('🛡 দোয়া');if(GAME.teaT>0)ch.push('☕ চা '+bn(Math.ceil(GAME.teaT)));if(GAME.vipT>0)ch.push('📣 ভিআইপি '+bn(Math.ceil(GAME.vipT)));if(JR.urgeT>0)ch.push('🔥 টান!');if(JR.snooze)ch.push('😴 ×১.২৫');
  const fx=$('fxChips'),txt=ch.join('  ');if(fx.textContent!==txt)fx.textContent=txt;fx.hidden=!ch.length;
  const h=$('hint');if(P.stuckT>2.5&&P.mode==='drive'){h.hidden=false;h.textContent=TOUCH.on?'আটকে গেছো? ব্রেক চেপে ধরে পেছনে যাও':'আটকে গেছো? R চাপো অথবা S দিয়ে পেছনে যাও';}else h.hidden=true;
  $('mini').hidden=P.mode==='metro';if(P.mode!=='metro')drawMini();
  if(P.mode==='drive'){const lg=legAt(P.node,P.d),zn=lg.road||lg.name;if(zn&&zn!==GAME.lastZone&&lg.type!=='jn'&&lg.type!=='cross'){GAME.lastZone=zn;if(GAME.t>2)toastMsg(zn,'info',1600);}}}

/* ---------- touch controls (layout changes with the mode) ---------- */
const TOUCH={on:false};
function enableTouch(){if(TOUCH.on)return;TOUCH.on=true;document.body.classList.add('touch');if(JR.leg)setTouchLayout(P.mode,JR.leg.type);}
function disableTouch(){if(!TOUCH.on)return;TOUCH.on=false;document.body.classList.remove('touch');}
const TLAY={
  drive:{boost:'বুস্ট',left:'◀',right:'▶',horn:'হর্ন',down:'ব্রেক',up:'গ্যাস'},
  ride:{left:'◀',right:'▶',horn:'বেল',down:'আস্তে',up:'জোরে!'},
  stand:{left:'◀',right:'▶',boost:'টান দেন!'},
  walk:{boost:'দৌড়!',left:'◀',right:'▶',down:'থামো',up:'জোরে'},
  metro:{left:'◀',right:'▶'}};
function setTouchLayout(mode,t){const L=TLAY[mode]||TLAY.drive;
  document.querySelectorAll('#touch .tb').forEach(b=>{const k=b.dataset.k;let lab=L[k];if(k==='boost'&&mode==='stand'&&t==='dd')lab='টান দেন!';if(k==='horn'&&t==='cng')lab='হর্ন';
    b.hidden=lab==null||k==='act';if(lab!=null)b.textContent=lab;});
  const sb=document.querySelector('#touch .tb[data-k="boost"]');if(sb){const host=mode==='stand'?$('padR').querySelector('.col'):$('padL').querySelector('.col');if(sb.parentNode!==host)host.insertBefore(sb,host.firstChild);}
  const K={drive:'<kbd>W</kbd><kbd>S</kbd> গ্যাস/ব্রেক · <kbd>A</kbd><kbd>D</kbd> স্টিয়ার · <kbd>Shift</kbd> বুস্ট · <kbd>H</kbd> হর্ন · <kbd>C</kbd> ক্যামেরা · <kbd>P</kbd> বিরতি',
    ride:'<kbd>A</kbd><kbd>D</kbd> "মামা, বামে/ডানে" · <kbd>W</kbd> জোরে · <kbd>S</kbd> আস্তে · <kbd>H</kbd> বেল · <kbd>P</kbd> বিরতি',
    stand:'<kbd>A</kbd><kbd>D</kbd> ব্যালান্স · <kbd>E</kbd> নামবো! · <kbd>Shift</kbd> টান দেন! · <kbd>P</kbd> বিরতি',
    walk:'<kbd>A</kbd><kbd>D</kbd> পাশ কাটাও · <kbd>W</kbd> জোরে হাঁটো · <kbd>Shift</kbd> দৌড় · <kbd>S</kbd> থামো',
    metro:'<kbd>A</kbd><kbd>D</kbd> ব্যালান্স · <kbd>Space</kbd> মিনিগেম · <kbd>P</kbd> বিরতি'};
  $('keysP').innerHTML=K[mode]||K.drive;
  $('balance').hidden=!(mode==='stand'||mode==='metro');setAction(null);}
function setupTouch(){if(matchMedia('(any-pointer:coarse)').matches&&navigator.maxTouchPoints>0)enableTouch();
  addEventListener('keydown',e=>{if(/^(arrow|[wasd]$)/i.test(e.key))disableTouch();});
  addEventListener('pointerdown',e=>{if(e.pointerType==='touch')enableTouch();},{passive:true});
  for(const pad of[$('padL'),$('padR')]){const ptrs=new Map();
    const keyAt=(x,y)=>{const el=document.elementFromPoint(x,y);const b=el&&el.closest?el.closest('.tb'):null;return b&&!b.hidden&&pad.contains(b)?b:null;};
    const sync=()=>{const ks=new Set();for(const b of ptrs.values())if(b)ks.add(b.dataset.k);pad.querySelectorAll('.tb').forEach(b=>{const k=b.dataset.k;const on=ks.has(k);b.classList.toggle('on',on);
        if(k==='horn'){if(on&&!b._was&&GAME.state==='play')playerHorn();b._was=on;}
        else if(k==='boost'&&P.mode==='stand'){if(on&&!b._was&&GAME.state==='play')urgeBus();b._was=on;}
        else KEYS[k]=on?1:0;});};
    pad.addEventListener('pointerdown',e=>{e.preventDefault();try{pad.setPointerCapture(e.pointerId);}catch(_){}ptrs.set(e.pointerId,keyAt(e.clientX,e.clientY));sync();});
    pad.addEventListener('pointermove',e=>{if(!ptrs.has(e.pointerId))return;const b=keyAt(e.clientX,e.clientY);if(b!==ptrs.get(e.pointerId)){ptrs.set(e.pointerId,b);sync();}});
    const up=e=>{ptrs.delete(e.pointerId);sync();};pad.addEventListener('pointerup',up);pad.addEventListener('pointercancel',up);pad.addEventListener('lostpointercapture',up);}
  $('actB').addEventListener('pointerdown',e=>{e.preventDefault();doAction();});
  $('qteBig').addEventListener('pointerdown',e=>{e.preventDefault();qteAction();});
  addEventListener('contextmenu',e=>e.preventDefault());}

/* ---------- daily morning ---------- */
function dailyTrip(track){const k=todayKey(),rg=mulberry32(hashStr('ojb4-'+k+'-'+track));const homes=Object.keys(HOMES),dests=destsFor(track);
  const home=homes[Math.floor(rg()*homes.length)],dest=dests[Math.floor(rg()*dests.length)];const wr=rg();
  return{home,dest,seed:hashStr('ojb4-day-'+k+'-'+track),weather:wr<.24?'rain':wr<.48?'cloudy':'clear',daily:true,track};}
const WNAME={clear:'রোদ',cloudy:'মেঘলা',rain:'বৃষ্টি'};

/* ---------- title (home) ---------- */
function refreshTitle(){const p=profile(),ls=levelSpan(p.xp),nm=SETTINGS.name||'নতুন যাত্রী';
  $('profAv').textContent=(SETTINGS.name||'?').trim().charAt(0)||'?';$('profName').textContent=nm;$('profLv').textContent='লেভেল '+bn(ls.l)+' · '+LV_TITLE[ls.l-1];$('profBar').firstChild.style.width=(ls.f*100).toFixed(0)+'%';
  const st=streakOf(p),se=$('streak');se.hidden=!st;se.textContent='🔥 টানা '+bn(st)+' দিন সময়মতো';
  const tr=SETTINGS.track,dt=dailyTrip(tr),H=HOMES[dt.home],D=DESTS[dt.dest];$('dailyRoute').textContent=H.name+' → '+D.name;
  const best=store('ojb4-daily-'+todayKey()+'-'+tr);$('dailyMeta').textContent=todayBn()+' · আবহাওয়া: '+WNAME[dt.weather]+' · '+TRACKS[tr].place+' '+fmtClock(TRACKS[tr].deadline)+(best?' · আজকের সেরা '+bn(best.score):'');
  $('tLogo').textContent=TRACKS[tr].title;$('tTag').textContent=tr==='varsity'?'৮:৩০-এ রোল কল। ক্যাম্পাস অনেক দূর। তুমি পারবে?':'১০টায় অফিস। ঢাকার রাস্তা। তুমি পারবে?';}

/* ---------- planner ---------- */
const PLANNER={daily:true,trip:null,plan:null};
function openPlanner(daily){PLANNER.daily=daily;const tr=SETTINGS.track;$('title').hidden=true;$('planner').hidden=false;
  $('plTitle').textContent=daily?'আজকের সকাল: কীভাবে যাবে?':'নিজের সকাল সাজাও';$('destLbl').textContent=tr==='varsity'?'ক্যাম্পাস':'অফিস';
  if(daily){PLANNER.trip=dailyTrip(tr);$('pRoute').hidden=true;$('pRouteFixed').hidden=false;$('pRouteFixed').textContent=HOMES[PLANNER.trip.home].name+' → '+DESTS[PLANNER.trip.dest].name+' · '+WNAME[PLANNER.trip.weather];}
  else{$('pRoute').hidden=false;$('pRouteFixed').hidden=true;const hs=$('homeSel'),ds=$('destSel');hs.innerHTML=Object.keys(HOMES).map(k=>'<option value="'+k+'">'+HOMES[k].name+'</option>').join('');
    const dk=destsFor(tr);ds.innerHTML=dk.map(k=>'<option value="'+k+'">'+DESTS[k].name+'</option>').join('');hs.value=HOMES[SETTINGS.home]?SETTINGS.home:'mirpur10';ds.value=dk.includes(SETTINGS.dest)?SETTINGS.dest:dk[0];
    const upd=()=>{SETTINGS.home=hs.value;SETTINGS.dest=ds.value;saveSettings();PLANNER.trip={home:hs.value,dest:ds.value,seed:(Math.random()*4294967296)>>>0,weather:null,daily:false,track:tr};};hs.onchange=upd;ds.onchange=upd;upd();}
  renderPlans();setTimeout(()=>$('planGo').focus(),50);}
function renderPlans(){const p=profile(),g=$('planGrid');g.innerHTML='';if(!planUnlocked(SETTINGS.plan,p))SETTINGS.plan='bus';
  for(const k of PLAN_ORDER){const pl=PLANS[k],ok=planUnlocked(k,p),b=document.createElement('button');b.type='button';b.dataset.plan=k;b.className='plan'+(ok?'':' lock');b.setAttribute('aria-pressed',String(k===SETTINGS.plan));
    if(!ok)b.dataset.lock='লেভেল '+bn(pl.lvl)+'-এ খুলবে';
    const chain=pl.legs.map(t=>modeIcon(t)).join('<i></i>');const bk=p.best[k];
    b.innerHTML='<div class="pc">'+chain+'</div><h4>'+pl.name+'</h4><p>'+pl.tip+'</p><div class="meta"><span>ভাড়া '+pl.fare+'</span><span>ঝুঁকি '+'●'.repeat(pl.risk)+'○'.repeat(3-pl.risk)+'</span><span>আরাম '+'●'.repeat(pl.comfort)+'○'.repeat(3-pl.comfort)+'</span></div>'+(bk&&ok?'<span class="best">সেরা '+bn(bk)+'</span>':'');
    b.addEventListener('click',()=>{if(!ok){toastLock(pl);return;}SETTINGS.plan=k;saveSettings();renderPlans();AU.click();});g.appendChild(b);}}
function toastLock(pl){const el=$('planGo');el.textContent='লেভেল '+bn(pl.lvl)+' লাগবে!';setTimeout(()=>el.textContent='যাত্রা শুরু!',1300);}

/* ---------- morning: alarm + breakfast ---------- */
function showMorning(done){const tr=TRACKS[GAME.track];JR.hold=99;JR.clockHold=99;JR.xferT=0;$('xfer').hidden=true;AU.alarm();
  showChoice({title:'⏰ '+fmtClock(GAME.clock)+'! অ্যালার্ম বাজছে…',text:tr.place+' '+fmtClock(GAME.deadline)+'-এ। এখনই উঠবে?',secs:7,opts:[
    {t:'উঠে পড়ি!',s:'সময়মতো বের হই',fn:()=>step2()},
    {t:'আর ৫ মিনিট…',s:'কঠিন, কিন্তু স্কোর ×১.২৫',fn:()=>{JR.snooze=true;GAME.clock+=300;GAME.startClock=GAME.clock;toastMsg('৫ মিনিট বেশি ঘুমালে! এখন দৌড়াতে হবে','bad',2200);AU.alarm();step2();}}]});
  function step2(){later(.15,()=>showChoice({title:GAME.track==='varsity'?'আম্মু: "নাস্তা না করে ক্লাসে যাবি না!"':'আম্মু: "নাস্তা না করে অফিসে যাবি না!"',text:'কী করবে?',secs:7,opts:[
    {t:'দৌড়ে বের হই!',s:'সময় বাঁচে',fn:()=>{JR.comfort-=4;toastMsg('খালি পেটে দৌড়! আম্মুর মন খারাপ','info');fin();}},
    {t:'নাস্তা খেয়ে যাই',s:'−২ মিনিট, দম ফুল, দোয়া সাথে',fn:()=>{JR.breakfast=true;GAME.clock+=120;GAME.startClock=GAME.clock;GAME.shield=1;P.boost=1;if(JR.walk)JR.walk.stam=1;JR.comfort=Math.min(100,JR.comfort+8);toastMsg('পরোটা-ডিম শেষ! মায়ের দোয়া সাথে','good');fin();}}]}));}
  function fin(){JR.hold=0;JR.clockHold=.3;showXfer(JR.leg.type,JR.leg);done&&done();}}

/* ---------- results ---------- */
const ACH={early5:'৫ মিনিট আগে!',three:'তিন তারা',noStumble:'পা মাড়ানো ছাড়া বাসযাত্রা',seat:'সিট দখলকারী',shortcut:'শর্টকাটের জুয়াড়ি',park:'নিখুঁত পার্কিং',
  knock:'ঠিক সময়ে "নামবো!"',snooze:'ঘুমিয়েও সময়মতো',rain:'বৃষ্টিতে ভিজে সময়মতো',streak3:'টানা ৩ দিন',plans5:'সব পথের যাত্রী (৫ রকম)',clean:'একটা ধাক্কাও না',varsity:'ক্লাসে সময়মতো'};
function computeScore(failed){const late=GAME.clock-GAME.deadline,onTime=!failed&&late<=0,early=Math.max(0,-late);
  const rows=[];const base=failed?0:400;rows.push(['পৌঁছানো',base]);
  const time=failed?0:onTime?Math.round(Math.min(early,600)*1.5):-Math.round(Math.min(late,1200)*1.2);rows.push([onTime?'আগে পৌঁছানোর বোনাস':'দেরির কাটা',time]);
  rows.push(['স্টাইল (অল্পের জন্য, নিখুঁত মুহূর্ত)',Math.round(GAME.style)]);rows.push(['আরাম',Math.round(clamp(JR.comfort,0,100)*3)]);
  rows.push(['পকেটে বাঁচানো টাকা',Math.max(0,Math.round(GAME.wallet*.5))]);rows.push(['ধাক্কা আর হোঁচট',-(GAME.hits*25+JR.stumbles*15)]);
  let total=rows.reduce((s,r)=>s+r[1],0);if(JR.snooze){const b=Math.round(Math.max(0,total)*.25);rows.push(['ঘুমের ঝুঁকি বোনাস ×১.২৫',b]);total+=b;}total=Math.max(0,Math.round(total));
  let stars=0;if(onTime){stars=1;if(early>=60)stars++;if(early>=150&&JR.comfort>=60&&GAME.hits<=1)stars++;}
  return{rows,total,stars,onTime,late,early};}
let lastCard=null,RES=null;
function finish(failed){if(GAME.state==='result')return;GAME.state='result';$('hud').hidden=true;document.body.classList.remove('playing');closeQte();clearSub();setAction(null);$('xfer').hidden=true;
  const S=computeScore(failed),tr=TRACKS[GAME.track],p=profile();RES={S,failed};
  // achievements
  const got=[];if(S.onTime&&S.early>=300)got.push('early5');if(S.stars===3)got.push('three');if(S.onTime&&(JR.plan==='bus'||JR.plan==='dd')&&JR.stumbles===0)got.push('noStumble');
  if(GAME.log.includes('সিট দখল'))got.push('seat');if(GAME.log.includes('শর্টকাটে জিত'))got.push('shortcut');if(JR.parked&&JR.parked.q>.75)got.push('park');if(JR.perfect&&JR.bus&&JR.bus.knocked)got.push('knock');
  if(S.onTime&&JR.snooze)got.push('snooze');if(S.onTime&&GAME.weather==='rain')got.push('rain');if(S.onTime&&GAME.hits===0&&!failed)got.push('clean');if(S.onTime&&GAME.track==='varsity')got.push('varsity');
  // progress
  const before=p.xp;p.runs++;if(S.onTime){p.onTime++;p.days[todayKey()]=1;}const plansDone=p.plansDone||{};if(S.onTime)plansDone[JR.plan]=1;p.plansDone=plansDone;if(Object.keys(plansDone).length>=5)got.push('plans5');
  const stk=streakOf(p);if(stk>=3)got.push('streak3');
  const fresh=got.filter(k=>!p.ach[k]);fresh.forEach(k=>p.ach[k]=1);
  const dk='ojb4-daily-'+todayKey()+'-'+GAME.track,dbest=store(dk);const firstDaily=GAME.daily&&!dbest;
  const xp=Math.round(S.total/9)+(S.onTime?30:10)+(firstDaily?40:0)+fresh.length*50;p.xp+=xp;
  if(!p.best[JR.plan]||S.total>p.best[JR.plan])p.best[JR.plan]=S.total;saveProfile(p);
  if(GAME.daily&&(!dbest||S.total>dbest.score))store(dk,{score:S.total,arrive:failed?null:GAME.clock,plan:JR.plan});
  const unlocked=PLAN_ORDER.filter(k=>levelOf(before)<PLANS[k].lvl&&levelOf(p.xp)>=PLANS[k].lvl);
  addLocalRun({day:todayKey(),track:GAME.track,plan:JR.plan,score:S.total,arrive:failed?0:Math.round(GAME.clock),stars:S.stars,daily:!!GAME.daily,trip:ROUTE.trip.H.name+' → '+ROUTE.trip.D.name});
  // text
  const tStr=fmtClock(GAME.clock),plan=PLANS[JR.plan];
  const head=failed?'আজকে আর পৌঁছানো হইল না…':S.onTime?(S.early>=300?bn(Math.round(S.early/60))+' মিনিট আগে! আজকে সূর্য কোন দিকে উঠছে?':tStr+'-এ '+tr.arriveVerb+' পৌঁছে গেলে!'):bn(Math.ceil(S.late/60))+' মিনিট লেট! দোষ পুরাটাই ট্রাফিকের!';
  const st=$('stamp');st.textContent=failed?'পৌঁছানো হয়নি':S.onTime?'সময়মতো!':'লেট!';st.className=S.onTime?'':'late';
  $('resHead').textContent=head;
  $('stars').innerHTML=[0,1,2].map(()=>'<svg viewBox="0 0 24 24">'+ICO.star+'</svg>').join('');
  const sr=$('scoreRows');sr.innerHTML='';const all=S.rows.concat([['মোট স্কোর',S.total]]);
  all.forEach((r,i)=>{const a=document.createElement('span'),b=document.createElement('span');a.textContent=r[0];b.textContent='০';b.dataset.v=r[1];if(i===all.length-1){a.className='tot';b.className='tot';}sr.append(a,b);});
  const ls0=levelSpan(before),ls1=levelSpan(p.xp);$('xpLv').textContent='লেভেল '+bn(ls0.l)+' · '+LV_TITLE[ls0.l-1];$('xpGain').textContent='+'+bn(xp)+' XP';$('xpFill').style.width=(ls0.f*100).toFixed(0)+'%';
  const ub=$('unlock');ub.hidden=true;
  const jamMin=Math.round(JR.jamT/60),yearH=Math.round(JR.jamT*250/3600);
  $('jam').innerHTML=jamMin>0?'আজ জ্যামে আর ভিড়ে আটকে ছিলে <b>'+bn(jamMin)+' মিনিট</b>। বছরে এভাবে গেলে প্রায় <b>'+bn(yearH)+' ঘণ্টা</b>, মানে '+bn(Math.max(1,Math.round(yearH/24)))+' দিনেরও বেশি!':'আজ জ্যাম তোমাকে ছুঁতেই পারেনি! বিরল দিন।';
  const who=tr.who,bossLine=failed?(GAME.track==='varsity'?'রোল কল শেষ। প্রক্সিও কাজে লাগলো না।':'আপনার attendance ঠিক আছে। আপনার punctuality-র চিকিৎসা লাগবে।'):S.onTime?pick(GAME.track==='varsity'?['বাহ! আজকে প্রথম বেঞ্চে বসো।','সময়মতো! পরীক্ষাতেও এমন হয় যেন।','উপস্থিত! আজকে তোমার নাম প্রথমে ডাকলাম।']:['আজকে সূর্য কোন দিকে উঠছে? আপনি সময়মতো!','বাহ! জ্যাম আজকে আপনারে ভয় পাইছে নাকি?','অফিসে আসছেন ভালো কথা, এখন কাজটাও করেন।'],CR)
    :(S.late<=300?(GAME.track==='varsity'?'দরজায় দাঁড়াও। পরের বার আগে বের হবা।':fmtClock(GAME.deadline)+' বাজে। আপনার গাড়ি কি অন্য টাইম জোনে চলে?'):pick(GAME.track==='varsity'?['ক্লাস তো প্রায় শেষ! নোট কারো থেকে নিয়ে নিও।']:['লাঞ্চের আগে আসছেন, এইটাই অনেক।','অফিসে আসছেন ভালো কথা, এখন কাজটাও করেন।'],CR));
  const bq=$('bossQ');bq.innerHTML='<small>'+who+' বললেন</small>';bq.appendChild(document.createTextNode('“'+bossLine+'”'));
  const ae=$('resAch');ae.innerHTML='';got.forEach(k=>{const s=document.createElement('span');s.textContent=ACH[k]+(fresh.includes(k)?' · নতুন! +৫০ XP':'');if(fresh.includes(k))s.className='new';ae.appendChild(s);});
  lastCard=drawShareCard({failed,S,tStr,head,plan,jamMin,yearH});$('shareImg').src=lastCard.url;
  $('shareB').hidden=!(navigator.share);$('shareNote').textContent='';$('rankLine').textContent=GAME.daily?'লিডারবোর্ড দেখা হচ্ছে…':'';
  $('result').hidden=false;$('result').scrollTop=0;setTimeout(()=>$('againB').focus({preventScroll:true}),60);
  // the reveal
  const T0=performance.now(),seq=[];const at=(ms,fn)=>seq.push(setTimeout(fn,ms));RES.seq=seq;
  at(250,()=>{st.classList.remove('go');void st.offsetWidth;st.classList.add('go');AU.stamp();if(S.onTime)AU.fanfare();else AU.jingle(false);if(S.onTime)burstConfetti();});
  for(let i=0;i<3;i++)at(800+i*380,()=>{if(i<S.stars){$('stars').children[i].classList.add('on');AU.ding(i);}});
  const spans=[...sr.children];let tt=2000;for(let i=0;i<spans.length;i+=2){const a=spans[i],b=spans[i+1],v=+b.dataset.v;at(tt,()=>{a.classList.add('in');b.classList.add('in');countUp(b,v,i===spans.length-2?900:380);});tt+=i===spans.length-4?420:230;}
  at(tt+700,()=>{if(ls1.l>ls0.l){$('xpFill').style.width='100%';setTimeout(()=>{AU.levelUp();$('xpLv').textContent='লেভেল '+bn(ls1.l)+'! '+LV_TITLE[ls1.l-1];$('xpFill').style.transition='none';$('xpFill').style.width='0%';void $('xpFill').offsetWidth;$('xpFill').style.transition='';$('xpFill').style.width=(ls1.f*100).toFixed(0)+'%';
      if(unlocked.length){ub.hidden=false;ub.textContent='🔓 নতুন পথ খুলেছে: '+unlocked.map(k=>PLANS[k].name).join(', ')+'!';}},900);}
    else $('xpFill').style.width=(ls1.f*100).toFixed(0)+'%';});
  if(GAME.daily)submitDaily(S);}
function countUp(el,v,ms){const t0=performance.now();const neg=v<0,av=Math.abs(v);const tick=()=>{const k=Math.min(1,(performance.now()-t0)/ms),cur=Math.round(av*k*(2-k));el.textContent=(neg&&cur?'−':'')+bn(cur);if(k<1){AU.count();requestAnimationFrame(tick);}};tick();}
function burstConfetti(){if(!P.model)return;FX.confetti(PW.x,PW.y+2.5,PW.z,70);}
async function submitDaily(S){const name=SETTINGS.name;
  if(BOARD.online()&&!name){await askName();}
  const e={day:todayKey(),track:GAME.track,name:SETTINGS.name||'নাম ছাড়া যাত্রী',score:S.total,plan:JR.plan,arrive:RES.failed?0:Math.round(GAME.clock),stars:S.stars,pid:playerId(),ver:VERSION};
  if(BOARD.online()){await BOARD.submit(e);const rows=await BOARD.top(todayKey(),GAME.track,100);if(rows){const i=rows.findIndex(r=>r.pid===e.pid),better=i>=0&&rows[i].score>e.score;
      $('rankLine').innerHTML=i>=0?'আজকের লিডারবোর্ডে তুমি <b>#'+bn(i+1)+'</b> (মোট '+bn(rows.length)+' জন)'+(better?' · তোমার আজকের সেরা '+bn(rows[i].score)+' ধরা হয়েছে':''):'আজকের লিডারবোর্ডে '+bn(rows.length)+' জন খেলেছে';return;}}
  const mine=localRuns().filter(r=>r.day===todayKey()&&r.track===GAME.track&&r.daily);const i=mine.findIndex(r=>r.score===S.total);
  $('rankLine').innerHTML=mine.length>1?'আজকের তোমার '+bn(mine.length)+'টা চেষ্টার মধ্যে এটা <b>#'+bn(i+1)+'</b>':'';}
function askName(){return new Promise(res=>{$('nameDlg').hidden=false;const inp=$('nameIn');inp.value='';setTimeout(()=>inp.focus(),50);
  const done=(save)=>{if(save){const v=cleanName(inp.value);if(v){SETTINGS.name=v;saveSettings();}}$('nameDlg').hidden=true;$('nameOk').onclick=null;$('nameSkip').onclick=null;res();};
  $('nameOk').onclick=()=>done(true);$('nameSkip').onclick=()=>done(false);inp.onkeydown=e=>{if(e.key==='Enter')done(true);};});}
function drawShareCard(o){const W=1080,H=1350,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d'),S=o.S,tr=TRACKS[GAME.track];
  const gr=g.createLinearGradient(0,0,0,H);gr.addColorStop(0,'#0f5038');gr.addColorStop(1,'#062a1e');g.fillStyle=gr;g.fillRect(0,0,W,H);
  const cols=['#e0412f','#ffc928','#2e9b57','#fff3d6'];for(let i=0;i<W;i+=48){g.fillStyle=cols[(i/48)%4];g.fillRect(i,0,48,24);g.fillRect(i,H-24,48,24);}
  for(let i=0;i<H;i+=48){g.fillStyle=cols[(i/48+2)%4];g.fillRect(0,i,24,48);g.fillRect(W-24,i,24,48);}
  g.strokeStyle='rgba(255,201,40,.45)';g.setLineDash([14,10]);g.lineWidth=4;g.strokeRect(46,46,W-92,H-92);g.setLineDash([]);
  g.textAlign='center';g.textBaseline='alphabetic';g.fillStyle='#ffc928';g.font='800 104px '+FONT_D;g.shadowColor='#e0412f';g.shadowOffsetY=8;fitText(g,tr.title,W-160,104,'800',FONT_D);g.fillText(tr.title,W/2,190);g.shadowColor='transparent';g.shadowOffsetY=0;
  g.fillStyle='#fff3d6';g.font='600 34px '+FONT_B;g.fillText((GAME.daily?'আজকের সকাল':'নিজের সকাল')+' · '+todayBn(),W/2,250);
  // route + plan chain
  g.font='800 46px '+FONT_D;g.fillStyle='#fff3d6';g.fillText(ROUTE.trip.H.name+'  →  '+ROUTE.trip.D.name,W/2,330);
  g.fillStyle='#b9c7bd';g.font='700 32px '+FONT_B;g.fillText(o.plan.name+' · '+WNAME[GAME.weather]+(JR.snooze?' · ৫ মিনিট বেশি ঘুম':''),W/2,380);
  // stamp
  g.save();g.translate(W/2,520);g.rotate(-.08);g.strokeStyle=S.onTime?'#2e9b57':'#ff6b55';g.lineWidth=10;const sw=560,sh=150;g.strokeRect(-sw/2,-sh/2,sw,sh);g.fillStyle=S.onTime?'#2e9b57':'#ff6b55';
  g.font='800 96px '+FONT_D;g.textBaseline='middle';g.fillText(o.failed?'পৌঁছানো হয়নি':S.onTime?'সময়মতো!':'লেট!',0,8);g.restore();g.textBaseline='alphabetic';
  g.fillStyle='#ffc928';g.font='800 150px '+FONT_D;g.fillText(o.failed?'—':o.tStr,W/2,760);
  g.fillStyle='#b9c7bd';g.font='600 34px '+FONT_B;g.fillText(tr.place+' ছিল '+fmtClock(GAME.deadline)+'-এ',W/2,812);
  // stars
  for(let i=0;i<3;i++){const x=W/2+(i-1)*120,y=890;g.fillStyle=i<S.stars?'#ffc928':'rgba(255,255,255,.15)';g.beginPath();for(let k=0;k<10;k++){const a=k/10*TAU-Math.PI/2,r=k%2?22:52;g.lineTo(x+Math.cos(a)*r,y+Math.sin(a)*r);}g.closePath();g.fill();}
  g.fillStyle='#fff3d6';g.font='800 60px '+FONT_D;g.fillText('স্কোর '+bn(S.total),W/2,1010);
  if(o.jamMin>0){g.fillStyle='#fff3d6';g.beginPath();g.roundRect?g.roundRect(110,1050,W-220,110,24):g.rect(110,1050,W-220,110);g.fill();g.fillStyle='#1c1912';g.font='700 34px '+FONT_B;
    fitText(g,'জ্যামে গেল '+bn(o.jamMin)+' মিনিট · বছরে প্রায় '+bn(o.yearH)+' ঘণ্টা!',W-280,34,'700',FONT_B);g.fillText('জ্যামে গেল '+bn(o.jamMin)+' মিনিট · বছরে প্রায় '+bn(o.yearH)+' ঘণ্টা!',W/2,1118);}
  g.fillStyle='#e0412f';g.fillRect(140,1190,W-280,80);g.fillStyle='#fff3d6';g.font='800 44px '+FONT_D;g.fillText(GAME.track==='varsity'?'তুমি কয়টায় ক্লাসে পৌঁছাতে পারো?':'তুমি কয়টায় অফিসে পৌঁছাতে পারো?',W/2,1245);
  const url=/^https?:/.test(location.protocol)&&!/claude|localhost|127\.0|usercontent/.test(location.host)?location.host+location.pathname.replace(/index\.html$/,''):'';
  if(url){g.fillStyle='#b9c7bd';g.font='600 26px '+FONT_B;g.fillText(url,W/2,1308);}
  return{canvas:c,url:c.toDataURL('image/png')};}
/* inside the claude.ai viewer a plain download link is blocked: use its downloads capability when present */
let DLNS;(function(){try{if(window.claude&&claude.use)claude.use('downloads').then(n=>{DLNS=n;}).catch(()=>{});}catch(e){}})();
function saveCard(){if(!lastCard)return;if(DLNS){lastCard.canvas.toBlob(b=>{DLNS.save({filename:'office-jabo-bhai.png',data:b}).then(()=>{$('shareNote').textContent='ছবি সেভ হয়েছে!';}).catch(()=>{$('shareNote').textContent='ছবির ওপর চেপে ধরে (বা রাইট-ক্লিক করে) সেভ করো।';});},'image/png');return;}
  try{lastCard.canvas.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='office-jabo-bhai.png';document.body.appendChild(a);a.click();
    setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},2000);$('shareNote').textContent='ছবি সেভ না হলে ছবির ওপর চেপে ধরে সেভ করো।';},'image/png');}catch(e){$('shareNote').textContent='ছবির ওপর চেপে ধরে (বা রাইট-ক্লিক করে) সেভ করো।';}}
function shareCard(){if(!lastCard)return;const txt=(GAME.track==='varsity'?'আজকে ক্লাসে পৌঁছালাম ':'আজকে অফিসে পৌঁছালাম ')+fmtClock(GAME.clock)+'-এ! তুমি পারবে?';
  lastCard.canvas.toBlob(async b=>{try{const f=new File([b],'office-jabo-bhai.png',{type:'image/png'});
    if(navigator.canShare&&navigator.canShare({files:[f]}))await navigator.share({files:[f],title:'অফিস যাবো, ভাই!',text:txt});
    else await navigator.share({title:'অফিস যাবো, ভাই!',text:txt,url:location.href});}catch(e){}},'image/png');}

/* ---------- leaderboard screen ---------- */
async function openBoard(tab){$('board').hidden=false;const set=segInit.setters.boardTabs;tab=tab||SETTINGS.track;set&&set(tab);renderBoard(tab);}
async function renderBoard(tab){const list=$('boardList'),note=$('boardNote');list.innerHTML='';note.textContent='';
  const row=(i,name,sub,plan,score,me)=>{const d=document.createElement('div');d.className='br'+(me?' me':'');d.innerHTML='<span class="rk">'+bn(i)+'</span><span class="nm">'+esc(name)+'<small>'+esc(sub)+'</small></span>'+modeIcon(PLANS[plan]?PLANS[plan].legs.find(t=>t!=='walk')||'walk':'walk')+'<span class="sc">'+bn(score)+'</span>';list.appendChild(d);};
  if(tab==='mine'){const l=localRuns();if(!l.length){note.textContent='এখনো কোনো খেলা হয়নি। আজকের সকাল দিয়ে শুরু করো!';return;}
    l.slice(0,30).forEach((r,i)=>row(i+1,r.trip||'',(r.arrive?fmtClock(r.arrive)+'-এ':'পৌঁছায়নি')+' · '+bn(Math.floor(r.day/100%100))+'/'+bn(r.day%100)+' · '+(PLANS[r.plan]?PLANS[r.plan].short:''),r.plan,r.score,false));return;}
  if(BOARD.online()){note.textContent='লোড হচ্ছে…';const rows=await BOARD.top(todayKey(),tab,50);if(rows){note.textContent=rows.length?'আজকের সকাল · সবার জন্য একই রাস্তা':'আজকে এখনো কেউ খেলেনি। তুমিই প্রথম হও!';
      const pid=playerId();rows.forEach((r,i)=>row(i+1,r.name,(r.arrive?fmtClock(r.arrive)+'-এ':'পৌঁছায়নি')+' · '+(PLANS[r.plan]?PLANS[r.plan].short:''),r.plan,r.score,r.pid===pid));return;}
    note.textContent='ইন্টারনেট সমস্যা, তাই এখন শুধু তোমার নিজের রেকর্ড দেখাচ্ছি।';}
  const mine=localRuns().filter(r=>r.day===todayKey()&&r.track===tab&&r.daily);
  if(!mine.length){note.textContent=(note.textContent?note.textContent+' ':'')+'আজকের সকালে এখনো খেলোনি।';return;}
  mine.forEach((r,i)=>row(i+1,SETTINGS.name||'তুমি',(r.arrive?fmtClock(r.arrive)+'-এ':'পৌঁছায়নি')+' · '+(PLANS[r.plan]?PLANS[r.plan].short:''),r.plan,r.score,true));
  if(!BOARD.online())note.textContent='এই ডিভাইসে তোমার আজকের চেষ্টাগুলো।';}

/* ---------- how to play ---------- */
function renderHow(){const g=$('howGrid');const items=[['bus','লোকাল বাস','স্টপে চলন্ত বাসে লাফিয়ে ওঠো। ভেতরে ◀ ▶ দিয়ে ব্যালান্স রাখো। নিজের স্টপের আগে "ওস্তাদ, নামবো!"'],
  ['metro','রিকশা + মেট্রো','রিকশায় দরদাম, গেটে কার্ড ট্যাপ, দরজা বন্ধের আগে ঢোকো, নিজের স্টেশনে ভিড় ঠেলে নামো।'],['bike','বাইক / গাড়ি / সাইকেল','নিজে চালাও। অল্পের জন্য পাশ কাটালে স্টাইল পয়েন্ট। গাড়ি হলে শেষে P-এ পার্ক।'],
  ['cng','সিএনজি','মিটারে যাবে না! দরদাম করো, শর্টকাটের জুয়া খেলো। ◀ ▶ দিয়ে লেন বলে দাও।'],['walk','হাঁটা','ফুটপাতে হকার, ম্যানহোল, ফোনে ব্যস্ত মানুষ। দম থাকলে দৌড়াও।'],
  ['star','তারা ও স্কোর','সময়মতো = ১ তারা, ১ মিনিট আগে = ২, আড়াই মিনিট আগে + আরাম = ৩। লেভেল বাড়লে নতুন পথ খোলে।']];
  g.innerHTML=items.map(i=>'<div class="how"><b>'+modeIcon(i[0])+i[1]+'</b>'+i[2]+'</div>').join('');
  $('howKeys').innerHTML=TOUCH.on?'<div>বামে ◀ ▶ আর বুস্ট, ডানে গ্যাস-ব্রেক। লাল বোতাম আর মিনিগেমের বড় বোতাম চাপলেই হবে।</div>':
    '<div><kbd>W</kbd><kbd>S</kbd>গ্যাস/ব্রেক</div><div><kbd>A</kbd><kbd>D</kbd>স্টিয়ার/ব্যালান্স</div><div><kbd>Shift</kbd>বুস্ট/দৌড়</div><div><kbd>E</kbd>নামবো!</div><div><kbd>Space</kbd>মিনিগেম</div><div><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd>বেছে নাও</div><div><kbd>H</kbd>হর্ন</div><div><kbd>P</kbd>বিরতি</div>';}

/* ---------- menus wiring ---------- */
function segInit(id,val,cb){const seg=$(id);const set=v=>seg.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v===v)));set(val);
  seg.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;set(b.dataset.v);cb(b.dataset.v);});segInit.setters[id]=set;return set;}
segInit.setters={};
function openSettings(){$('settings').hidden=false;$('autoNote').textContent='এখন: '+TIERS[autoTier()].name;$('nameSet').value=SETTINGS.name||'';}
function setupMenus(){
  segInit('trackSeg',SETTINGS.track,v=>{SETTINGS.track=v;saveSettings();refreshTitle();AU.click();});
  segInit('qSeg',SETTINGS.quality,v=>{SETTINGS.quality=v;saveSettings();});
  segInit('muteSeg',SETTINGS.mute?'off':'on',v=>{SETTINGS.mute=v==='off';saveSettings();AU.setOn(!SETTINGS.mute);});
  segInit('gasSeg',SETTINGS.autoGas?'auto':'manual',v=>{SETTINGS.autoGas=v==='auto';saveSettings();});
  segInit('swapSeg',SETTINGS.swap?'swap':'std',v=>{SETTINGS.swap=v==='swap';saveSettings();document.body.classList.toggle('swap',SETTINGS.swap);});document.body.classList.toggle('swap',!!SETTINGS.swap);
  segInit('boardTabs',SETTINGS.track,v=>renderBoard(v));
  const vr=$('volR');vr.value=SETTINGS.vol;vr.addEventListener('input',()=>{SETTINGS.vol=+vr.value;saveSettings();AU.setVol(SETTINGS.vol/100);});
  const mr=$('musR');mr.value=SETTINGS.music;mr.addEventListener('input',()=>{SETTINGS.music=+mr.value;saveSettings();MUS.setVol(SETTINGS.music/100);});
  $('nameSet').addEventListener('change',()=>{SETTINGS.name=cleanName($('nameSet').value);saveSettings();refreshTitle();});
  $('mapB').addEventListener('click',openMap);$('mini').addEventListener('click',()=>{if(GAME.state==='play'){pauseGame();openMap();}});
  $('mapClose').addEventListener('click',()=>{$('mapScr').hidden=true;});
  $('setB').addEventListener('click',openSettings);$('pSetB').addEventListener('click',openSettings);
  $('setDone').addEventListener('click',()=>{SETTINGS.name=cleanName($('nameSet').value);saveSettings();refreshTitle();$('settings').hidden=true;});
  $('howB').addEventListener('click',()=>{renderHow();$('how').hidden=false;});$('howDone').addEventListener('click',()=>{$('how').hidden=true;store('ojb4-howSeen',1);});
  $('boardB').addEventListener('click',()=>openBoard());$('boardClose').addEventListener('click',()=>{$('board').hidden=true;});
  $('goDaily').addEventListener('click',()=>{unlockAudio();openPlanner(true);});$('customB').addEventListener('click',()=>{unlockAudio();openPlanner(false);});
  $('planBack').addEventListener('click',()=>{$('planner').hidden=true;$('title').hidden=false;});
  $('planGo').addEventListener('click',()=>{const p=profile();if(!planUnlocked(SETTINGS.plan,p))return;$('planner').hidden=true;goFull();requestRun(Object.assign({},PLANNER.trip,{plan:SETTINGS.plan}));});
  $('againB').addEventListener('click',()=>{goFull();requestRun(Object.assign({},LASTRUN));});
  $('otherB').addEventListener('click',()=>{$('result').hidden=true;openPlanner(!!LASTRUN.daily);});
  $('resumeB').addEventListener('click',resumeGame);
  $('restartB').addEventListener('click',()=>{$('pause').hidden=true;requestRun(Object.assign({},LASTRUN));});
  $('menuB').addEventListener('click',toMenu);$('menu2B').addEventListener('click',toMenu);
  $('pauseB').addEventListener('click',pauseGame);$('saveB').addEventListener('click',saveCard);$('shareB').addEventListener('click',shareCard);
  $('rotOk').addEventListener('click',()=>{ROT.dismissed=true;$('rotate').hidden=true;if(ROT.pending){const o=ROT.pending;ROT.pending=null;startRun(o);}});
  refreshTitle();}
function unlockAudio(){AU.init();MUS.init();if(AU.ctx&&AU.ctx.state==='suspended')AU.ctx.resume();AU.setOn(!SETTINGS.mute);AU.setVol(SETTINGS.vol/100);MUS.setVol(SETTINGS.music/100);}
const ROT={dismissed:false,pending:null};
function goFull(){if(!TOUCH.on)return;const el=document.documentElement;try{const r=(el.requestFullscreen||el.webkitRequestFullscreen||function(){}).call(el,{navigationUI:'hide'});
  const lock=()=>{try{screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{});}catch(e){}};if(r&&r.then)r.then(lock).catch(()=>{});else lock();}catch(e){}}
function portrait(){return innerHeight>innerWidth*1.05;}
let LASTRUN={};
function requestRun(o){LASTRUN=o;$('result').hidden=true;$('title').hidden=true;$('planner').hidden=true;if(RES&&RES.seq)RES.seq.forEach(clearTimeout);
  if(TOUCH.on&&portrait()&&!ROT.dismissed){ROT.pending=o;$('rotate').hidden=false;return;}startRun(o);}
addEventListener('resize',()=>{if(ROT.pending&&!portrait()){const o=ROT.pending;ROT.pending=null;$('rotate').hidden=true;startRun(o);}});
function toMenu(){document.body.classList.remove('playing');for(const id of['pause','result','hud','planner','board'])$(id).hidden=true;closeQte();clearSub();if(RES&&RES.seq)RES.seq.forEach(clearTimeout);
  enterTitle();}
function pauseGame(){if(GAME.state!=='play'&&GAME.state!=='arrive')return;GAME.prevState=GAME.state;GAME.state='pause';$('pause').hidden=false;document.body.classList.remove('playing');for(const k in KEYS)KEYS[k]=0;}
function resumeGame(){$('pause').hidden=true;$('settings').hidden=true;document.body.classList.add('playing');GAME.state=GAME.prevState||'play';LAST=performance.now();}
function openMap(){const cv=$('mapCv');$('mapScr').hidden=false;requestAnimationFrame(()=>{const b=cv.getBoundingClientRect();cv.width=Math.round(b.width*Math.min(2,devicePixelRatio||1));cv.height=Math.round(b.height*Math.min(2,devicePixelRatio||1));drawDhakaMap(cv);});}
