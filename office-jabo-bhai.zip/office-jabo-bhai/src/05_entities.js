/* ============================================================
   05 ENTITIES: player, traffic, crossers, walkers, debris, collisions
   ============================================================ */
let scene,camera,renderer;
const GAME={state:'title',t:0,clock:0,weather:'clear',veh:[],free:[],cross:[],walk:[],obst:[],debris:[],solids:[],camMode:0,log:[]};
const P={node:null,d:6,x:-2.8,h:0,v:0,sv:0,steer:0,acc:0,boost:1,frozen:0,stuckT:0,damage:0,fall:0,model:null,kind:'car',mode:'drive',w:1.9,l:4.4,cfg:null,inp:null};
/* player vehicle configs (speeds in m/s of the compressed city) */
const CARS={
  car:{name:'প্রাইভেট কার',maxV:22,boostV:28,acc:8,steer:1.35,dmg:1,w:1.9,l:4.4,drive:true},
  bike:{name:'মোটরবাইক',maxV:24,boostV:30,acc:10,steer:1.9,dmg:.8,w:.8,l:2.1,drive:true},
  cycle:{name:'সাইকেল',maxV:10.5,boostV:13,acc:4.6,steer:2.0,dmg:.6,w:.7,l:1.8,drive:true,stamina:true},
  rickshaw:{name:'রিকশা',maxV:5.6,boostV:7.4,acc:2.4,steer:1.8,dmg:.4,w:1.3,l:2.7,ride:true},
  cng:{name:'সিএনজি',maxV:13,boostV:16,acc:5,steer:1.6,dmg:.4,w:1.5,l:2.8,ride:true},
  bus:{name:'লোকাল বাস',maxV:14,boostV:16.5,acc:3.4,steer:1.05,dmg:0,w:2.5,l:10,heavy:true},
  dd:{name:'ডাবল ডেকার',maxV:12.5,boostV:14,acc:2.8,steer:.95,dmg:0,w:2.6,l:10.5,heavy:true},
  walk:{name:'হাঁটা',maxV:2.6,boostV:5.2,acc:6,steer:2,dmg:0,w:.6,l:.5},
  metro:{name:'মেট্রো',maxV:27,boostV:27,acc:3.4,steer:0,dmg:0,w:2.9,l:14}};
const VT={bus:{len:10,w:2.5,vmax:13,acc:1.8,dec:6,lat:.8,name:'বাস হেলপার',role:'helper',mass:6},
  dd:{len:10.5,w:2.6,vmax:11,acc:1.6,dec:6,lat:.7,name:'বিআরটিসি ড্রাইভার',role:'helper',mass:6},
  cng:{len:2.8,w:1.5,vmax:12,acc:3.5,dec:7,lat:1.6,name:'সিএনজি ড্রাইভার',role:'cng',mass:1.2},
  rickshaw:{len:2.7,w:1.3,vmax:4.2,acc:1.2,dec:4,lat:1.1,name:'রিকশাওয়ালা',role:'rickshaw',mass:.7},
  bike:{len:2,w:.8,vmax:15,acc:5,dec:9,lat:2.6,name:'বাইকার',role:'bike',mass:.6},
  car:{len:4.4,w:1.85,vmax:15,acc:3.5,dec:8,lat:1.4,name:'প্রাইভেট কার',role:'car',mass:2},
  van:{len:5,w:2.1,vmax:11,acc:2.5,dec:6,lat:1.0,name:'ভ্যান ড্রাইভার',role:'car',mass:3},
  truck:{len:7.2,w:2.4,vmax:10,acc:1.6,dec:5,lat:.7,name:'ট্রাক ড্রাইভার',role:'truck',mass:7},
  police:{len:2.1,w:.8,vmax:32,acc:9,dec:10,lat:4,name:'ট্রাফিক পুলিশ',role:'police',mass:.8},
  tesla:{len:2.9,w:1.45,vmax:10,acc:5,dec:7,lat:1.6,name:'অটোওয়ালা',role:'tesla',mass:.9}};
function shadowMesh(w,l){const m=new THREE.Mesh(T.shadowGeo,MATS.shadow);m.scale.set(w,1,l);m.position.y=.03;m.renderOrder=1;return m;}
const _f1={},_f2={},_v3=new THREE.Vector3();

/* ---------- player ---------- */
function buildPlayer(kind){if(P.model){scene.remove(P.model.group);if(P.model.parts.cars)P.model.parts.cars.forEach(c=>scene.remove(c));}P.kind=kind;P.cfg=CARS[kind];P.model=buildPlayerModel(kind);P.w=P.cfg.w;P.l=P.cfg.l;scene.add(P.model.group);
  if(P.model.parts.cars)P.model.parts.cars.forEach(c=>scene.add(c));}
function playerWorld(o){P.node.path.pos(P.d,P.x,o);o.a+=P.h;return o;}
const PW={x:0,y:0,z:0,a:0,k:0};

/* ---------- vehicles ---------- */
let VID=0;
function vehGeo(type){return type==='dd'?T.dd:type==='bus'?pick(T.bus,CR):type==='cng'?T.cng:type==='rickshaw'?pick(T.rickshaw,CR):type==='bike'?pick(T.bike,CR):type==='van'?pick(T.van,CR):type==='truck'?pick(T.truck,CR):type==='police'?T.policeBike:type==='tesla'?pick(T.tesla,CR):pick(T.car,CR);}
function spawnVehicle(type,node,d,x,dir,v0,o){o=o||{};const t=VT[type],mesh=new THREE.Mesh(vehGeo(type),MATS.col);mesh.rotation.order='YXZ';
  mesh.add(shadowMesh(t.w+.5,t.len+.6));
  if(type==='bus'){const bm=pick(MATS.boards,CR);for(const zz of[-5.04,5.04]){const b=new THREE.Mesh(T.boardGeo,bm);b.position.set(0,2.98,zz);if(zz<0)b.rotation.y=Math.PI;mesh.add(b);}}
  if(type==='rickshaw'){const a=new THREE.Mesh(T.artGeo,MATS.rart);a.position.set(0,1.25,1.07);mesh.add(a);}
  if(type==='truck'){const a=new THREE.Mesh(T.truckArtGeo,MATS.truckArt);a.position.set(0,1.9,3.47);mesh.add(a);}
  if(type==='police'){const l=new THREE.Mesh(new THREE.BoxGeometry(.3,.12,.12),MATS.blue);l.position.set(0,1.32,.75);mesh.add(l);mesh.userData.light=l;}
  const leg=legAt(node,d),cap=leg.vmax*(type==='bike'?1.35:1);
  const v={id:++VID,type,t,mesh,node,d,x,dir,len:t.len,w:t.w,li:o.li||0,xOff:o.xOff!=null?o.xOff:rr(-.3,.3),
    vDes:o.vDes||Math.min(t.vmax,cap)*rr(.62,1),v:0,stopT:0,hitCd:0,honkCd:rr(2,6),weaveCd:0,script:o.script||null,st:{},yaw:0,spin:0,sx:0,tip:0,tipDir:1,tipT:0,
    prevRel:null,nm:false,wx:0,wz:0,wy:0,wa:0,forkPref:o.forkPref};
  v.v=v0!=null?v0:v.vDes*.8;placeVeh(v);scene.add(mesh);GAME.veh.push(v);return v;}
function placeVeh(v){const f=v.node.path.pos(v.d,v.x,_f1);v.wx=f.x;v.wz=f.z;v.wy=f.y;v.wa=f.a+(v.dir<0?Math.PI:0)+v.yaw+v.spin;
  const bob=(v.type==='rickshaw'||v.type==='cng'||v.type==='tesla')?Math.abs(Math.sin(GAME.t*9+v.id))*.03*Math.min(1,v.v):0;
  v.mesh.position.set(f.x,f.y+bob,f.z);v.mesh.rotation.y=v.wa;v.mesh.rotation.z=v.tip*1.4*v.tipDir;}
function removeVeh(v){scene.remove(v.mesh);v.dead=true;}
function freeAt(node,d,x,len){for(const v of GAME.veh)if(Math.abs(v.d-d)<(len+v.len)/2+5&&Math.abs(v.x-x)<2.3&&related(v.node,node))return false;
  if(related(P.node,node)&&Math.abs(P.d-d)<(len+P.l)/2+10&&Math.abs(P.x-x)<2.6)return false;return true;}
const _lay={our:[],onc:[]};
function trySpawn(side,d){const node=nodeAt(P.node,d);if(d>node.dEnd-2||d<node.dStart)return;const leg=legAt(node,d);if(leg.type==='jn'||leg.type==='cross')return;
  if(node.office&&d>node.officeD-25)return;
  const lay=laneLayout(node,d,_lay),arr=lay[side];let type=wpick(leg.mix);let li=ri(0,arr.length-1);
  if(lay.div&&(type==='rickshaw'||type==='bus'||type==='truck')&&R()<.7)li=arr.length-1;
  const x=arr[li];if(!freeAt(node,d,x,VT[type].len))return;spawnVehicle(type,node,d,x,side==='our'?1:-1,null,{li});}
function initialTraffic(){for(let i=0;i<34*TIER.traffic;i++){trySpawn(i%2?'our':'onc',P.d+rr(30,320));}}
let spawnT=0;
function trafficSpawner(dt){spawnT-=dt;if(spawnT>0)return;spawnT=.3;
  const node=nodeAt(P.node,P.d+150),leg=legAt(node,P.d+150),want=Math.round(leg.density*4*TIER.traffic);let our=0,onc=0;
  for(const v of GAME.veh){if(v.type==='police')continue;const rel=v.d-P.d;if(rel<-30||rel>360)continue;if(v.dir>0)our++;else onc++;}
  const d=P.d+rr(170,290);if(our<want&&GAME.clearUntil<d)trySpawn('our',d);if(onc<want*.8)trySpawn('onc',P.d+rr(150,290));}
function laneX(v){const lay=laneLayout(v.node,v.d,_lay),arr=v.dir>0?lay.our:lay.onc;return arr[Math.min(v.li,arr.length-1)];}
function sigBlock(v,sigs){let gap=1e9;for(const s of sigs){if(s.state==='green')continue;
    if(v.dir>0){const ah=s.stop-v.d-v.len/2;if(ah>-1&&ah<45&&ah<gap)gap=ah;}else{const ah=v.d-s.stopOnc-v.len/2;if(ah>-1&&ah<45&&ah<gap)gap=ah;}}return gap;}
function updateVehicles(dt){const sigsAll=[...WORLD.signals.values()];GAME.frame=(GAME.frame||0)+1;
  for(const v of GAME.veh){if(v.dead)continue;v.hitCd-=dt;v.honkCd-=dt;v.weaveCd-=dt;
    // knock-back / spin / tip recovery
    v.spin*=Math.exp(-dt*1.6);v.sx*=Math.exp(-dt*4);
    if(v.tip>0){v.tipT-=dt;if(v.tipT<0)v.tip=Math.max(0,v.tip-dt*.8);else v.tip=Math.min(1,v.tip+dt*4);}
    const leg=legAt(v.node,v.d);let target=Math.min(v.vDes,leg.vmax*(v.type==='bike'?1.35:v.type==='police'?3:1));let lat=v.t.lat,tx=null;
    if(v.stopT>0){v.stopT-=dt;target=0;}if(v.tip>.05)target=0;
    if(v.script){const r=v.script(v,dt,target);if(r){if(r.target!=null)target=r.target;if(r.tx!=null)tx=r.tx;if(r.lat)lat=r.lat;}}
    let gap=1e9,leadV=0;const hw=v.w/2;
    if(v.type!=='police'){
    for(const u of GAME.veh){if(u===v||u.dead||u.dir!==v.dir)continue;const ah=(u.d-v.d)*v.dir;if(ah<=0||ah>60)continue;
      if(Math.abs(u.x-v.x)>u.w/2+hw+.2)continue;if(!related(u.node,v.node))continue;const g=ah-(u.len+v.len)/2;if(g<gap){gap=g;leadV=u.v;}}
    if(related(P.node,v.node)){const ah=(P.d-v.d)*v.dir;if(ah>0&&ah<60&&Math.abs(P.x-v.x)<P.w/2+hw+.3){const g=ah-(P.l+v.len)/2;if(g<gap){gap=g;leadV=v.dir>0?Math.max(0,P.v):0;
      if(v.dir<0&&v.honkCd<=0&&ah<45){v.honkCd=rr(2,4);hornAt(v);if(R()<.4)sayV(v,'wrongway');}}}}
    for(const c of GAME.cross){if(c.role==='police'&&c.stay)continue;const ah=(c.d-v.d)*v.dir;if(ah<=0||ah>40||!related(c.node,v.node))continue;if(Math.abs(c.x-v.x)<c.w/2+hw+.6){const g=ah-(c.len+v.len)/2;if(g<gap){gap=g;leadV=0;}
        if((c.wander||c.vx===0||c.stay)&&g<14&&v.weaveCd<=0){v.weaveCd=2.5;const side=v.x<c.x?-1:1;v.xOff=c.x+side*(c.w/2+hw+.7)-laneX(v);}}}
    for(const o of GAME.obst){if(!related(o.node,v.node))continue;const ah=((o.d0+o.d1)/2-v.d)*v.dir;if(ah<=0||ah>50)continue;if(v.x+hw>o.x0-.3&&v.x-hw<o.x1+.3){const g=ah-(o.d1-o.d0)/2-v.len/2;
      if(g<gap){gap=g;leadV=0;if(g<14&&v.weaveCd<=0){v.weaveCd=2;const goLeft=Math.abs(o.x0-v.x)<Math.abs(o.x1-v.x);v.xOff=(goLeft?o.x0-hw-.6:o.x1+hw+.6)-laneX(v);}}}}
    const sg=sigBlock(v,sigsAll);if(sg<gap){gap=sg;leadV=0;}
    for(const o of GAME.obst)if(o.surface&&v.d>o.d0-2&&v.d<o.d1&&related(o.node,v.node)){target=Math.min(target,o.surface==='flood'?4.5:7);break;}
    if(gap<1e8){const safe=2.5+v.v*.9;if(gap<safe)target=Math.min(target,Math.max(0,leadV*(gap/safe)-.5));if(gap<1.2)target=0;
      if(gap<9&&leadV<v.v+1&&v.weaveCd<=0&&(v.type==='bike'||v.type==='cng'||(v.type==='car'&&R()<.3))){v.weaveCd=rr(2.5,4);v.xOff=(R()<.5?-1:1)*rr(1.3,2.1);}
      if(gap<4&&v.v<2&&v.honkCd<=0&&Math.abs(v.d-P.d)<110){v.honkCd=rr(3,8);hornAt(v);}}
    if(v.weaveCd<-4&&Math.abs(v.xOff)>.6)v.xOff*=.98;}
    if(target>v.v)v.v=Math.min(target,v.v+v.t.acc*dt);else v.v=Math.max(target,v.v-(target===0?v.t.dec*1.4:v.t.dec)*dt);
    v.d+=v.v*v.dir*dt;
    // node transitions
    if(v.d>=v.node.dEnd){if(v.node.children.length){const k=v.node.children;v.node=k.length>1?(v.forkPref!=null?k[v.forkPref]:(v.dir>0&&v.x<-halfAt(v.node,v.node.dEnd-1)*.5?k[0]:k[R()<.5?0:1])):k[0];}else if(v.dir>0){removeVeh(v);continue;}}
    if(v.d<v.node.dStart){if(v.node.parent)v.node=v.node.parent;else{removeVeh(v);continue;}}
    const lay=laneLayout(v.node,v.d,_lay);if(tx==null)tx=laneX(v)+v.xOff;
    const ourSide=v.side?v.side==='our':v.dir>0;
    const dv=divHalf(lay.leg)+.55;let lo,hi;if(lay.div){lo=ourSide?-lay.half+.4+hw:dv+hw;hi=ourSide?-dv-hw:lay.half-.4-hw;}else{lo=-lay.half+.4+hw;hi=lay.half-.4-hw;}
    if(v.type==='police'){lo=-lay.half+.4+hw;}
    tx=clamp(tx,lo,hi);const dx=clamp(tx-v.x,-lat*dt,lat*dt);v.x+=dx+v.sx*dt;v.x=clamp(v.x,-lay.half+hw*.6,lay.half-hw*.6);
    const lv=dx/Math.max(dt,1e-3),want=v.v>.5?Math.atan2(-lv*v.dir,v.v):0;v.yaw+=(clamp(want,-.5,.5)-v.yaw)*Math.min(1,dt*5);
    if(v.v>5&&WORLD.puddles.length&&((v.id+GAME.frame)%6===0)&&Math.abs(v.d-P.d)<55){for(const pd of WORLD.puddles){if(Math.abs(pd.d-v.d)<pd.l&&Math.abs(pd.x-v.x)<pd.w+.4&&related(pd.node,v.node)){FX.splash(v.wx,v.wy+.1,v.wz,4,v.v);break;}}}
    placeVeh(v);if(v.mesh.userData.light)v.mesh.userData.light.material=(Math.floor(GAME.t*6)%2)?MATS.blue:MATS.red;
    const rel=v.d-P.d;if((rel<-80||rel>460)&&v.type!=='police')removeVeh(v);}
  GAME.veh=GAME.veh.filter(v=>!v.dead);
  // free cross traffic (world space)
  for(const f of GAME.free){f.life-=dt;f.wx+=Math.cos(f.dirA)*f.v*dt;f.wz+=Math.sin(f.dirA)*f.v*dt;f.mesh.position.set(f.wx,f.wy,f.wz);
    if(f.life<0){scene.remove(f.mesh);f.dead=true;}}
  GAME.free=GAME.free.filter(f=>!f.dead);}
function hornAt(v){const dist=Math.hypot(v.wx-PW.x,v.wz-PW.z);AU.horn(v.type,clamp(1-dist/130,0,1),clamp(((v.wx-PW.x)*Math.cos(PW.a)-(v.wz-PW.z)*Math.sin(PW.a))/20,-1,1));}
function spawnFree(type,wx,wy,wz,dirA,v){const t=VT[type],mesh=new THREE.Mesh(vehGeo(type),MATS.col);mesh.add(shadowMesh(t.w+.5,t.len+.6));
  mesh.rotation.y=-dirA-Math.PI/2;mesh.position.set(wx,wy,wz);scene.add(mesh);const f={type,t,mesh,wx,wy,wz,dirA,v,len:t.len,w:t.w,life:14,free:true};GAME.free.push(f);return f;}

/* ---------- crossers: people, carts, animals on the road ---------- */
function spawnCrosser(geo,node,d,x,vx,o){o=o||{};const m=new THREE.Mesh(geo,MATS.col);m.rotation.order='YXZ';if(!o.noShadow)m.add(shadowMesh(o.w||.8,o.len||.8));
  scene.add(m);const c={m,node,d,x,vx,w:o.w||.7,len:o.len||.6,kind:o.kind||'person',t:CR()*5,pauseAt:o.pauseAt,pauseT:o.pauseT||0,bounds:o.bounds,hitCd:0,role:o.role||'ped',name:o.name||'পথচারী',
    jump:0,fall:0,life:o.life||60,wander:o.wander,stay:o.stay,ry:o.ry,dodged:false,canDodge:o.kind!=='cow'&&o.kind!=='cart'&&!o.noDodge,y0:o.y0||0,target:o.target,anim:o.anim};
  GAME.cross.push(c);placeCrosser(c);return c;}
function placeCrosser(c){const f=c.node.path.pos(c.d,c.x,_f2);const h=halfAt(c.node,c.d),leg=legAt(c.node,c.d);
  const onWalk=Math.abs(c.x)>h&&!leg.elevated;c.wx=f.x;c.wz=f.z;
  const bob=c.kind==='person'?Math.abs(Math.sin(c.t*8))*.05*(c.moving?1:0):c.kind==='duck'?Math.abs(Math.sin(c.t*10))*.04:0;
  c.m.position.set(f.x,f.y+(onWalk?.22:0)+bob+Math.sin(Math.min(1,c.jump)*Math.PI)*.8+c.y0,f.z);
  let ry=c.ry!=null?c.ry:(c.vx>0?-Math.PI/2:Math.PI/2);c.m.rotation.y=f.a+ry;c.m.rotation.x=c.fall>0?-Math.min(1,c.fall)*1.3:0;
  if(c.anim==='shout')c.m.rotation.z=Math.sin(c.t*7)*.12;}
function updateCrossers(dt){for(const c of GAME.cross){c.t+=dt;c.hitCd-=dt;c.life-=dt;
    if(c.pauseAt!=null&&!c.paused&&((c.vx>0&&c.x>=c.pauseAt)||(c.vx<0&&c.x<=c.pauseAt))){c.paused=true;c.pauseLeft=c.pauseT;}
    let vx=c.vx;if(c.paused&&c.pauseLeft>0){c.pauseLeft-=dt;vx=0;}
    if(c.fall>0){c.fall-=dt*.6;vx=0;if(c.fall<=0)c.fall=0;}
    if(c.wander){c.wt=(c.wt||0)-dt;if(c.wt<=0){c.wt=rr(1.5,3.5);c.vx=rr(-.6,.6);}const h=halfAt(c.node,c.d)-1.2;if(c.x+c.vx*dt>h||c.x+c.vx*dt<-h)c.vx*=-1;vx=c.vx;}
    if(c.target){const dx=c.target.x-c.x,dd=c.target.d-c.d,dist=Math.hypot(dx,dd);if(dist>.3){const sp=Math.min(2.2,dist*2);c.x+=dx/dist*sp*dt;c.d+=dd/dist*sp*dt;c.ry=Math.atan2(dx,dd)+Math.PI;c.moving=true;}else{c.moving=false;}vx=0;}
    else c.moving=vx!==0;
    // dodge the player car
    if(c.canDodge&&!c.dodged&&related(P.node,c.node)&&!c.target){const rel=c.d-P.d,ttc=rel/Math.max(1,P.v);if(rel>2&&ttc<1.1&&P.v>4&&Math.abs(c.x-P.x)<P.w/2+1){c.dodged=true;c.jump=.01;
        c.dodgeV=(c.x<P.x?-1:1)*5.5;c.paused=true;c.pauseLeft=0;if(R()<.6)sayAt(c.role==='kids'?'kidsDodge':'dodge',c,c.name);}}
    if(c.dodgeV){c.x+=c.dodgeV*dt;c.dodgeV*=Math.exp(-dt*5);if(Math.abs(c.dodgeV)<.2)c.dodgeV=0;}
    c.x+=vx*dt;if(c.jump>0)c.jump=c.jump>=1?0:Math.min(1,c.jump+dt*2.6);
    if(c.d<c.node.dStart&&c.node.parent)c.node=c.node.parent;
    placeCrosser(c);
    const far=c.bounds||halfAt(c.node,c.d)+5;if((c.vx>0&&c.x>far)||(c.vx<0&&c.x<-far)||(c.stay&&P.d>c.d+40&&related(P.node,c.node))||(related(P.node,c.node)&&c.d<P.d-60)||c.life<0||(!related(P.node,c.node)&&Math.abs(c.d-P.d)>80)){scene.remove(c.m);c.dead=true;}}
  GAME.cross=GAME.cross.filter(c=>!c.dead);}

/* ---------- sidewalk walkers ---------- */
function updateWalkers(dt){
  if(GAME.walk.length<TIER.walkers&&CR()<dt*4){const d=P.d+rr(20,240,CR),node=nodeAt(P.node,d,CR),leg=legAt(node,d);
    if(leg.type!=='jn'&&leg.type!=='cross'&&!pSkip(node,d)&&d<node.dEnd){const s=CR()<.5?-1:1,dir=CR()<.5?1:-1,rain=GAME.weather==='rain'&&CR()<.6;
      const geo=rain?pick(T.umbrella,CR):pick(T.people,CR),m=new THREE.Mesh(geo,MATS.col);scene.add(m);
      const sw=leg.elevated?4:(leg.sw||3),off=rr(.5,Math.max(.6,sw-.5),CR);
      GAME.walk.push({m,node,d,s,off,vd:dir*rr(.9,1.5,CR),t:CR()*9,elev:!!leg.elevated});}}
  for(const w of GAME.walk){w.t+=dt;w.d+=w.vd*dt;if(w.d>w.node.dEnd||w.d<w.node.dStart){scene.remove(w.m);w.dead=true;continue;}
    const leg=legAt(w.node,w.d);if(leg.type==='jn'||leg.type==='cross'||!!leg.elevated!==w.elev){scene.remove(w.m);w.dead=true;continue;}
    const h=w.elev?leg.groundHalf:halfAt(w.node,w.d);const f=w.node.path.pos(w.d,w.s*(h+w.off),_f2);
    w.m.position.set(f.x,(w.elev?0:f.y)+.22+Math.abs(Math.sin(w.t*7))*.04,f.z);w.m.rotation.y=f.a+(w.vd>0?0:Math.PI);
    if(!related(P.node,w.node)||w.d<P.d-40||w.d>P.d+300){scene.remove(w.m);w.dead=true;}}
  GAME.walk=GAME.walk.filter(w=>!w.dead);}

/* ---------- static obstacles from events (barricades, trucks…) ---------- */
function addObstacle(node,d0,d1,x0,x1,meshes,kind,o){const ob=Object.assign({node,d0,d1,x0,x1,meshes,kind},o||{});meshes.forEach(m=>scene.add(m));GAME.obst.push(ob);return ob;}
function updateObstacles(){for(const o of GAME.obst)if((related(P.node,o.node)&&o.d1<P.d-50)||(!related(P.node,o.node)&&Math.abs(o.d0-P.d)>100)){o.meshes.forEach(m=>{scene.remove(m);m.traverse(x=>{if(x.isMesh&&x.userData.own)x.geometry.dispose();});});o.dead=true;}
  GAME.obst=GAME.obst.filter(o=>!o.dead);}
/* ---------- flying debris (cones, crates, car parts) ---------- */
function spawnDebris(mesh,x,y,z,vx,vy,vz,spin){mesh.position.set(x,y,z);scene.add(mesh);GAME.debris.push({m:mesh,vx,vy,vz,wx:spin||rr(-6,6,CR),wz:rr(-6,6,CR),life:6,ground:y-1.5});}
function updateDebris(dt){for(const b of GAME.debris){b.life-=dt;b.vy-=18*dt;b.m.position.x+=b.vx*dt;b.m.position.y+=b.vy*dt;b.m.position.z+=b.vz*dt;
    b.m.rotation.x+=b.wx*dt;b.m.rotation.z+=b.wz*dt;const gy=b.floor!=null?b.floor:0;
    if(b.m.position.y<gy+.1){b.m.position.y=gy+.1;b.vy*=-.3;b.vx*=.6;b.vz*=.6;b.wx*=.5;b.wz*=.5;}
    if(b.life<0||Math.hypot(b.m.position.x-PW.x,b.m.position.z-PW.z)>160){scene.remove(b.m);b.dead=true;}}
  GAME.debris=GAME.debris.filter(b=>!b.dead);}

/* ---------- oriented-box collision (world XZ) ---------- */
function obb(cx,cz,a,hl,hw,o){o=o||{};o.cx=cx;o.cz=cz;o.fx=-Math.sin(a);o.fz=-Math.cos(a);o.rx=Math.cos(a);o.rz=-Math.sin(a);o.hl=hl;o.hw=hw;return o;}
const _ax=[0,0,0,0,0,0,0,0];
function sat(A,B,out){const dx=B.cx-A.cx,dz=B.cz-A.cz;_ax[0]=A.fx;_ax[1]=A.fz;_ax[2]=A.rx;_ax[3]=A.rz;_ax[4]=B.fx;_ax[5]=B.fz;_ax[6]=B.rx;_ax[7]=B.rz;
  let best=1e9,bx=0,bz=0;
  for(let i=0;i<8;i+=2){const ax=_ax[i],az=_ax[i+1];
    const ra=A.hl*Math.abs(A.fx*ax+A.fz*az)+A.hw*Math.abs(A.rx*ax+A.rz*az),rb=B.hl*Math.abs(B.fx*ax+B.fz*az)+B.hw*Math.abs(B.rx*ax+B.rz*az);
    const dist=dx*ax+dz*az,ov=ra+rb-Math.abs(dist);if(ov<=0)return null;if(ov<best){best=ov;const sg=dist>0?-1:1;bx=ax*sg;bz=az*sg;}}
  out.depth=best;out.nx=bx;out.nz=bz;return out;} // normal points from B toward A
const _A={},_B={},_hit={};

/* ---------- player physics (path space) ---------- */
const KEYS={up:0,down:0,left:0,right:0,hand:0,boost:0};
const AIK={up:0,down:0,left:0,right:0,hand:0,boost:0};
function surfaceAt(){// puddles, mud, flood
  let s=null;for(const p of WORLD.puddles){if(Math.abs(p.d-P.d)<p.l&&Math.abs(p.x-P.x)<p.w+.4){s='puddle';break;}}
  for(const o of GAME.obst){if(o.surface&&P.d>o.d0&&P.d<o.d1&&P.x>o.x0&&P.x<o.x1)return o.surface;}
  return s;}
function updatePlayer(dt){const c=P.cfg,inp=P.inp||KEYS,human=inp===KEYS;
  let thr=inp.up||(human&&SETTINGS.autoGas&&TOUCH.on&&!inp.down?1:0),brk=inp.down,st=inp.left-inp.right;
  if(P.frozen>0){P.frozen-=dt;thr=0;brk=1;st=0;}
  if(P.fall>0){P.fall-=dt;thr=0;brk=1;st=0;}
  if(GAME.state==='arrive'||JR.hold>0){thr=0;brk=1;st=0;}
  const surf=surfaceAt();P.surface=surf;
  const wet=GAME.weather==='rain',grip=(surf==='mud'?.45:wet?.82:1)*(surf==='flood'?.8:1)*(c.heavy?1.1:1);
  let boosting=inp.boost&&P.boost>.02&&thr&&P.v>(c.stamina?2:4);
  // stamina (cycle) / boost tank
  if(c.stamina){const use=boosting?.2:thr?.028:0;P.boost=clamp(P.boost-use*dt+(thr&&!boosting?.012*dt:.1*dt),0,1);}
  else P.boost=boosting?Math.max(0,P.boost-.28*dt):Math.min(1,P.boost+.035*dt);
  P.boosting=boosting;
  let vmax=(boosting?c.boostV:c.maxV)*(P.damage>70?.88:1)*(JR.vMul||1);
  if(c.stamina&&P.boost<=.02)vmax*=.72;
  if(surf==='flood')vmax=Math.min(vmax,7);if(surf==='mud')vmax=Math.min(vmax,12);
  const acc=(boosting?c.acc*1.4:c.acc)*(surf==='mud'?.6:1);let a=0;
  if(thr)a=P.v<0?14:(P.v<vmax?acc*(1-.7*P.v/vmax):-6);
  if(brk)a=P.v>.3?-(c.heavy?11:20)*(wet?.8:1):(human?-5:0);
  if(!thr&&!brk){a=-Math.sign(P.v)*(1.2+Math.abs(P.v)*.045);if(Math.abs(P.v)<.3){a=0;P.v=0;}}
  if(inp.hand&&Math.abs(P.v)>.2)a+=-Math.sign(P.v)*11;
  if(surf==='flood'&&P.v>7)a-=10;if(surf==='puddle'&&P.v>8)a-=3;
  P.v+=a*dt;if(P.v<-6)P.v=-6;if(!human&&P.v<0)P.v=0;P.acc=lerp(P.acc,a,Math.min(1,dt*6));
  P.steer=lerp(P.steer,st,Math.min(1,dt*(st?5:8)));
  const F=P.node.path.frame(P.d,_f1),k=F.k;
  const sf=Math.min(1,Math.abs(P.v)/5)*(1-Math.min(.45,Math.abs(P.v)/70));
  P.h+=P.steer*c.steer*sf*grip*(inp.hand?1.7:1)*dt*(P.v<0?-1:1);
  if(!st){const assist=k!==0?(Math.abs(k)>.03?.45:1.2):1.8;P.h*=Math.exp(-assist*dt);}
  if(grip<1&&Math.abs(P.steer)>.3&&P.v>10)P.sv+=-P.steer*(1-grip)*P.v*.12*dt*10;
  const dd=P.v*Math.cos(P.h)*dt/Math.max(.2,1+k*P.x);P.d+=dd;P.h-=k*dd;
  P.x+=(-P.v*Math.sin(P.h)+P.sv)*dt;P.sv*=Math.exp(-dt*4);
  P.h=clamp(P.h,-1.1,1.1);
  if(inp.hand&&Math.abs(P.v)>8)P.x-=P.steer*dt*2.2;
  if(P.d>P.node.dEnd-2){P.d=P.node.dEnd-2;P.v=Math.min(P.v,0);}
  if(P.d<2){P.d=2;P.v=Math.max(P.v,0);}
  // bounds
  const lay=laneLayout(P.node,P.d,_lay),h=lay.half,leg=lay.leg;let lo=-h+P.w/2+.05,hi=h-P.w/2-.05;
  if(leg.type==='jn'){const j=P.node.juncs.find(j=>P.d>=j.d0-1&&P.d<=j.d1+1);if(j){if(j.sg>0)hi+=2.5;else lo-=2.5;}}
  const dvh=divHalf(leg)+P.w/2;if(lay.div){if(P.x>0){lo=dvh;if(human&&GAME.wrongWayT<=0){GAME.wrongWayT=8;alertMsg('উল্টা পথে! ডিভাইডারের ওপাশে যাও','bad');}}else hi=-dvh;}
  GAME.wrongWayT-=dt;
  if(lay.div&&P.x>0&&Math.abs(P.v)<2&&P.frozen<=0){GAME.wrongStuck=(GAME.wrongStuck||0)+dt;if(GAME.wrongStuck>5){GAME.wrongStuck=0;resetCar();toastMsg('উল্টো পথ থেকে তুলে আনা হলো','info');}}else GAME.wrongStuck=0;
  if(human&&!lay.div&&P.x>-.3){const ahead=isDivided(P.node,P.d+12)&&!isDivided(P.node,P.d);if(ahead&&GAME.keepLeftT<=GAME.t){GAME.keepLeftT=GAME.t+5;toastMsg('বাম দিকে চাপো, সামনে ডিভাইডার!','bad',1800);}}
  const latV=Math.abs(P.v*Math.sin(P.h))+Math.abs(P.sv);
  if(P.x<lo||P.x>hi){const side=P.x<lo?-1:1;P.x=clamp(P.x,lo,hi);P.h*=.4;P.sv=0;
    if(latV>2.2){P.v*=.82;GAME.shake=Math.max(GAME.shake,.25);AU.scrape(clamp(latV/8,.2,1));FX.sparks(PW.x+Math.cos(PW.a)*side*P.w/2,PW.y+.4,PW.z-Math.sin(PW.a)*side*P.w/2,6);
      if(latV>5)damagePlayer(latV*.15,'side',side);} else P.v*=1-dt*1.2;}
  playerWorld(PW);
  collidePlayer(dt);
  // near-miss (style points) — only when you or your driver are weaving
  if(c.drive||c.ride)for(const v of GAME.veh){const rel=P.d-v.d;if(v.prevRel!=null&&Math.sign(rel)!==Math.sign(v.prevRel)&&P.v>(c.ride?4:9)&&!v.nm&&v.hitCd<=0){
      const cl=Math.abs(P.x-v.x)-(P.w+v.w)/2;if(cl<.8&&cl>-.05){v.nm=true;nearMiss(v);}}v.prevRel=rel;}
  if(P.d-GAME.cleanSince>GAME.cleanBest)GAME.cleanBest=P.d-GAME.cleanSince;
  if(thr&&Math.abs(P.v)<.6&&P.frozen<=0&&P.fall<=0)P.stuckT+=dt;else P.stuckT=Math.max(0,P.stuckT-dt*2);
  if(P.stuckT>6&&GAME.state==='play'&&P.inp===KEYS){resetCar();toastMsg('লোকজন ঠেলে বের করে দিলো!','info');}
  if((surf==='puddle'||surf==='flood')&&P.v>4&&CR()<dt*12){FX.splash(PW.x,PW.y+.1,PW.z,surf==='flood'?10:5,P.v);if(CR()<.2)AU.splash(clamp(P.v/20,.2,1));}
  if(surf==='mud'&&P.v>4&&CR()<dt*8)FX.dust(PW.x,PW.y+.2,PW.z,3,'#6a4a2a');
  poseModel(dt);
}
function poseModel(dt){const m=P.model,g=m.group;g.position.set(PW.x,PW.y,PW.z);g.rotation.y=PW.a;
  const body=m.body,pr=m.parts;
  if(P.kind==='bike'||P.kind==='cycle'){const lean=-P.steer*Math.min(1,Math.abs(P.v)/14)*.35;body.rotation.z=P.fall>0?lerp(body.rotation.z,1.35,Math.min(1,dt*8)):lerp(body.rotation.z,lean,Math.min(1,dt*6));
    if(pr.rider)pr.rider.position.y=P.fall>0?-.1:.08;
    if(pr.rig){P.pedal=(P.pedal||0)+Math.abs(P.v)*dt*1.9;const s=Math.sin(P.pedal)*.6;pr.rig.parts.hipL.rotation.x=-1.1+s;pr.rig.parts.hipR.rotation.x=-1.1-s;}}
  else{const heavy=P.cfg.heavy;body.rotation.x=lerp(body.rotation.x,clamp(P.acc*(heavy?.006:.004),-.06,.05),Math.min(1,dt*8));
    body.rotation.z=lerp(body.rotation.z,-P.steer*Math.min(1,Math.abs(P.v)/18)*(heavy?.09:.06)+(JR.sway||0)*.04,Math.min(1,dt*6));}
  body.position.y=Math.sin(GAME.t*13)*.012*Math.min(1,Math.abs(P.v)/8)+(P.surface==='mud'||P.surface==='flood'?Math.sin(GAME.t*17)*.02:0);
  pr.wheels.forEach((w,i)=>{w.rotation.x-=P.v*dt/.34;if(P.kind==='car'&&i<2)w.rotation.y=P.steer*.45;});
  if(P.kind==='rickshaw'&&pr.rider){const f=Math.max(2,P.v*(P.boosting?2:1.4));pr.rider.position.y=.15+Math.abs(Math.sin(GAME.t*f))*.08*Math.min(1,P.v/2);pr.rider.rotation.z=Math.sin(GAME.t*f)*.06*Math.min(1,P.v/2);}
  if(pr.helper){pr.helper.rotation.z=Math.sin(GAME.t*3)*.08;}
  if(P.damage>60&&CR()<dt*(P.damage>85?14:6))FX.smoke(PW.x-Math.sin(PW.a)*1.8,PW.y+1.1,PW.z-Math.cos(PW.a)*1.8,P.damage>85?'#3a3a3a':'#9a9a9a');}
function collidePlayer(dt){obb(PW.x,PW.z,PW.a,P.l/2,P.w/2,_A);
  for(const v of GAME.veh){if(Math.abs(v.wy-PW.y)>2.5)continue;const dx=v.wx-PW.x,dz=v.wz-PW.z;if(dx*dx+dz*dz>200)continue;
    obb(v.wx,v.wz,v.wa,v.len/2,v.w/2,_B);if(!sat(_A,_B,_hit))continue;
    const vvx=-Math.sin(v.wa)*v.v,vvz=-Math.cos(v.wa)*v.v;v.touching=(GAME.frame-(v.lastTouch||-9))<=3;v.lastTouch=GAME.frame;resolveHit(_hit,vvx,vvz,v.t.mass,v,null);}
  for(const f of GAME.free){const dx=f.wx-PW.x,dz=f.wz-PW.z;if(dx*dx+dz*dz>200)continue;obb(f.wx,f.wz,-f.dirA-Math.PI/2,f.len/2,f.w/2,_B);if(!sat(_A,_B,_hit))continue;
    resolveHit(_hit,Math.cos(f.dirA)*f.v,Math.sin(f.dirA)*f.v,3,f,null);}
  for(const c of GAME.cross){const dx=c.wx-PW.x,dz=c.wz-PW.z;if(dx*dx+dz*dz>80)continue;const fa=c.node.path.frame(c.d,_f2).a;
    obb(c.wx,c.wz,fa,c.len/2,c.w/2,_B);if(!sat(_A,_B,_hit))continue;resolveHit(_hit,0,0,c.kind==='cow'?20:c.kind==='cart'?4:c.kind==='duck'?.1:1,null,c);}
  for(const o of GAME.obst){if(o.surface||!related(o.node,P.node))continue;const cd=(o.d0+o.d1)/2;if(Math.abs(cd-P.d)>(o.d1-o.d0)/2+6)continue;const f=o.node.path.pos(cd,(o.x0+o.x1)/2,_f2);
    obb(f.x,f.z,f.a,(o.d1-o.d0)/2,(o.x1-o.x0)/2,_B);if(!sat(_A,_B,_hit))continue;resolveHit(_hit,0,0,50,null,null,o);}
  for(const s of GAME.solids){const dx=s.x-PW.x,dz=s.z-PW.z;if(dx*dx+dz*dz>60)continue;obb(s.x,s.z,s.a,s.hl,s.hw,_B);if(!sat(_A,_B,_hit))continue;resolveHit(_hit,0,0,50,null,null,s);}
}
/* hit response: normal (nx,nz) points from other toward player */
function resolveHit(hit,ovx,ovz,mass,veh,cr,ob){const nx=hit.nx,nz=hit.nz;
  const fa=PW.a,pfx=-Math.sin(fa),pfz=-Math.cos(fa),ux=pfx*P.v,uz=pfz*P.v;
  const rvx=ux-ovx,rvz=uz-ovz,vn=rvx*nx+rvz*nz;const imp=Math.max(0,-vn);
  if(cr&&cr.kind==='duck'){cr.dodged=true;cr.dodgeV=(cr.x<P.x?-1:1)*7;cr.jump=.01;if(!cr.quacked){cr.quacked=1;AU.quack();}return;}
  const pm=P.cfg.heavy?7:P.cfg.ride?(P.kind==='rickshaw'?.9:1.3):(P.kind==='cycle'?.7:1.6),share=veh?mass/(mass+pm):(P.cfg.heavy&&cr?.15:1);const push=hit.depth*share;
  // positional correction → path space
  const F=P.node.path.frame(P.d,_f1),ca=Math.cos(F.a),sa=Math.sin(F.a);
  const px=nx*push,pz=nz*push;P.x+=px*ca-pz*sa;P.d+=(-px*sa-pz*ca)/Math.max(.3,1+F.k*P.x);
  if(veh&&!veh.free){veh.d-=(-px*sa-pz*ca)*(1-share)*.6*veh.dir;}
  if(vn<0){const e=.15,j=-(1+e)*vn*share;const nux=ux+j*nx,nuz=uz+j*nz;
    const uf=nux*(-sa)+nuz*(-ca),ul=nux*ca+nuz*(-sa);const cs=Math.cos(P.h);P.v=cs>.3?uf/cs:uf;P.sv=ul+P.v*Math.sin(P.h);
    if(veh&&!veh.free){const dv=imp*(1-share)*1.4;veh.sx+=-(nx*Math.cos(veh.wa)-nz*Math.sin(veh.wa))*dv*1.5;
      const cross=(PW.x-veh.wx)*(-Math.cos(veh.wa))-(PW.z-veh.wz)*(-Math.sin(veh.wa));if(veh.t.mass<3)veh.spin+=clamp(imp*.08,0,.9)*(cross>0?1:-1);}}
  if(imp>1.2)onImpact(imp,veh,cr,ob,nx,nz);}
function onImpact(imp,veh,cr,ob,nx,nz){const now=GAME.t;
  const front=(nx*-Math.sin(PW.a)+nz*-Math.cos(PW.a))<-.55,rear=(nx*-Math.sin(PW.a)+nz*-Math.cos(PW.a))>.55,zone=front?'front':rear?'rear':'side';
  const side=(nx*Math.cos(PW.a)-nz*Math.sin(PW.a))>0?-1:1;
  const cx=PW.x-nx*(P.w/2),cz=PW.z-nz*(P.w/2);
  if(veh&&(veh.hitCd>0||veh.touching)&&imp<5)return;if(cr&&cr.hitCd>0)return;if(ob&&ob.hitCd>now)return;
  if(veh)veh.hitCd=1.2;if(cr)cr.hitCd=2;if(ob)ob.hitCd=now+1.2;
  const tier=imp<2.6?1:imp<6?2:3;
  if(tier>=2&&GAME.shield){GAME.shield=0;GAME.shake=.3;AU.pickup('doa');FX.confetti(PW.x,PW.y+1.5,PW.z,20);toastMsg('মায়ের দোয়া! এইবার বাঁচলে','good',2200);if(veh)veh.stopT=2;if(cr)cr.fall=1;return;}
  GAME.shake=Math.max(GAME.shake,tier===1?.12:tier===2?.3:.6);
  if(tier===1){AU.thud(.35);if(P.cfg.heavy||P.cfg.ride)jolt(.25);return;}
  FX.sparks(cx,PW.y+.5,cz,tier===3?14:8);FX.dust(cx,PW.y+.3,cz,tier===3?9:5,'#b8a888');AU.crash(clamp(imp/12,.3,1),veh?veh.type:cr?cr.kind:'wall');
  GAME.hits++;GAME.combo=0;GAME.cleanSince=P.d;JR.comfort=Math.max(0,JR.comfort-(tier===3?10:5));
  if(P.cfg.heavy||P.cfg.ride){jolt(tier===3?.9:.55);}
  damagePlayer(Math.min(10,imp*(tier===3?1.0:.6)),zone,side);
  if((P.kind==='bike'||P.kind==='cycle')&&imp>3.2&&P.fall<=0){P.fall=2.2;P.v=0;sayMe('bikeFall');logEv(P.kind==='cycle'?'সাইকেল থেকে পড়ে যাওয়া':'বাইক থেকে পড়ে যাওয়া');}
  if(veh&&!veh.free){veh.stopT=Math.max(veh.stopT,2+tier);
    if(veh.type==='rickshaw'&&imp>4.5&&veh.tip===0&&!P.cfg.ride){veh.tip=.01;veh.tipT=5;veh.tipDir=side;}
    else if(veh.type==='bike'&&imp>3.5){veh.tip=.01;veh.tipT=4;veh.tipDir=side;}
    if(!P.cfg.heavy)sayV(veh,'hit');logEv('ধাক্কা: '+veh.t.name);}
  if(cr){if(cr.kind==='cow'){AU.moo(1);sayAt('cow',cr,'গরু');logEv('গরুর সাথে মুখোমুখি');}
    else if(cr.kind==='cart'){sayAt('vendor',cr,cr.name,'shout');logEv('ভ্যানগাড়িতে ধাক্কা');}
    else{cr.fall=1.2;cr.dodged=true;sayAt(cr.role==='wedding'?'wedding':cr.role==='kids'?'kidsHit':'pedhit',cr,cr.name,'shout');logEv('পথচারীর সাথে ঝামেলা');}}
  if(ob){if(ob.kind==='work'&&!ob.said){ob.said=1;sayAt('worker',{x:PW.x,z:PW.z,y:2.4},'নির্মাণ শ্রমিক');}
    if(ob.cones&&ob.cones.length){for(const m of ob.cones.splice(0,3)){const wp=m.getWorldPosition(new THREE.Vector3());m.parent&&m.parent.remove(m);spawnDebris(m,wp.x,wp.y+.3,wp.z,-nx*P.v*.4+rr(-2,2,CR),rr(3,6,CR),-nz*P.v*.4+rr(-2,2,CR));}}}
  // a real crash costs time: you stop, say sorry, sort it out (no mobs, no drama)
  if(tier===3&&(veh&&!veh.free&&!P.cfg.heavy||cr&&cr.kind==='person')&&now>(GAME.fussCd||0)){GAME.fussCd=now+14;GAME.warp=.3;GAME.warpT=.5;fuss(veh,cr);}}
function fuss(veh,cr){const who=cr?'পথচারী':veh.t.name;P.frozen=Math.max(P.frozen,1.6);addTime(45);GAME.fusses=(GAME.fusses||0)+1;
  setTimeout(()=>{if(GAME.state==='play')say(pickLine(P.cfg.ride?'sorryDriver':'sorryMe'),P.cfg.ride?'চালক':'তুমি',{obj:P.model.group,y:2.6},PRIO.urgent,P.cfg.ride?'':'me',2.4);},300);
  toastMsg(who+'-এর সাথে ঝামেলা মিটাতে ৪৫ সেকেন্ড','bad',2600);}
function damagePlayer(amt,zone,side){if(!P.cfg.drive){return;}if(!P.model.parts.hood){P.damage=Math.min(100,P.damage+amt*.6*P.cfg.dmg);return;}
  const before=P.damage;P.damage=Math.min(100,P.damage+amt*P.cfg.dmg);const m=P.model.parts;
  if(zone==='side'&&amt>3){const mir=side<0?m.mirrorL:m.mirrorR;if(mir&&mir.parent){const wp=mir.getWorldPosition(new THREE.Vector3());mir.parent.remove(mir);
      spawnDebris(mir,wp.x,wp.y,wp.z,Math.cos(PW.a)*side*3+rr(-1,1,CR),4,-Math.sin(PW.a)*side*3,8);toastMsg('সাইড মিরর গেল!','bad');sayMe('mirror');AU.glass();}}
  if(zone==='front'){if(P.damage>25&&m.headL.material!==MATS.dead){m.headL.material=MATS.dead;AU.glass();}if(P.damage>40)m.bumperF.rotation.x=Math.min(.5,(P.damage-40)/60*.6);
    if(P.damage>40)m.bumperF.position.y=.44-Math.min(.18,(P.damage-40)/200);if(P.damage>55)m.hood.rotation.x=-Math.min(.22,(P.damage-55)/150);if(P.damage>70)m.headR.material=MATS.dead;}
  if(zone==='rear'&&P.damage>35){m.bumperR.rotation.x=-Math.min(.45,(P.damage-35)/80);m.tailL.material=MATS.dead;}
  if(before<60&&P.damage>=60){toastMsg('ইঞ্জিন থেকে ধোঁয়া বের হচ্ছে!','bad');}
  if(before<85&&P.damage>=85){toastMsg('গাড়ির অবস্থা খারাপ, স্পিড কমে গেছে','bad');}}
function resetCar(){const lay=laneLayout(P.node,P.d,_lay);P.x=lay.our[nearestLane(lay.our,P.x)];P.h=0;P.v=0;P.sv=0;P.stuckT=0;P.fall=0;
  for(const v of GAME.veh)if(Math.abs(v.d-P.d)<9&&Math.abs(v.x-P.x)<2.6)removeVeh(v);GAME.veh=GAME.veh.filter(v=>!v.dead);
  for(const c of GAME.cross)if(Math.abs(c.d-P.d)<6&&Math.abs(c.x-P.x)<2.5&&!c.stay){scene.remove(c.m);c.dead=true;}
  if(P.cfg.drive){addTime(15);toastMsg('আবার রাস্তায়!  −১৫ সেকেন্ড','info');}}
function nearMiss(v){GAME.near++;GAME.combo=Math.min(GAME.combo+1,5);const pts=40*GAME.combo;GAME.style+=pts;P.boost=Math.min(1,P.boost+(P.cfg.stamina?.08:.18));AU.whoosh();
  popMsg('অল্পের জন্য! +'+bn(pts));if(GAME.near%4===0&&R()<.6)sayMe(P.cfg.ride?'nearRide':'nearMe');}
