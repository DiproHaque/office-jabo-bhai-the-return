/* ============================================================
   07 AUDIO — everything synthesized with Web Audio (no files)
   ============================================================ */
const AU={ctx:null,on:true,vol:.7,ambT:2};
AU.init=function(){if(AU.ctx)return;try{AU.ctx=new(window.AudioContext||window.webkitAudioContext)();}catch(e){return;}const c=AU.ctx;
  AU.master=c.createGain();AU.master.gain.value=AU.on?AU.vol:0;const comp=c.createDynamicsCompressor();AU.master.connect(comp);comp.connect(c.destination);
  const len=c.sampleRate*2,buf=c.createBuffer(1,len,c.sampleRate),d=buf.getChannelData(0);for(let i=0;i<len;i++)d[i]=Math.random()*2-1;AU.noise=buf;
  AU.eo1=c.createOscillator();AU.eo1.type='sawtooth';AU.eo2=c.createOscillator();AU.eo2.type='square';AU.ef=c.createBiquadFilter();AU.ef.type='lowpass';AU.ef.frequency.value=500;
  AU.eg=c.createGain();AU.eg.gain.value=0;AU.eo1.connect(AU.ef);AU.eo2.connect(AU.ef);AU.ef.connect(AU.eg);AU.eg.connect(AU.master);AU.eo1.start();AU.eo2.start();
  const loop=(rate,type,freq,q)=>{const n=c.createBufferSource();n.buffer=buf;n.loop=true;n.playbackRate.value=rate;const f=c.createBiquadFilter();f.type=type;f.frequency.value=freq;if(q)f.Q.value=q;
    const g=c.createGain();g.gain.value=0;n.connect(f);f.connect(g);g.connect(AU.master);n.start();return{g,f};};
  AU.amb=loop(1,'bandpass',650,.6);AU.road=loop(.5,'lowpass',120);AU.rain=loop(1,'highpass',2500);AU.water=loop(.7,'bandpass',900,1.2);
  // crowd babble: three modulated band-passed noises
  AU.bab=[0,1,2].map(i=>{const l=loop(1,'bandpass',[420,700,1050][i],4);const lfo=c.createOscillator(),lg=c.createGain();lfo.frequency.value=2.5+i*1.3;lg.gain.value=.5;lfo.connect(lg);
    const vg=c.createGain();vg.gain.value=0;l.g.disconnect();l.g.connect(vg);vg.connect(AU.master);lg.connect(l.g.gain);lfo.start();l.g.gain.value=.5;return vg;});};
AU.setOn=function(on){AU.on=on;if(AU.master)AU.master.gain.setTargetAtTime(on?AU.vol:0,AU.ctx.currentTime,.05);};
AU.setVol=function(v){AU.vol=v;if(AU.master&&AU.on)AU.master.gain.setTargetAtTime(v,AU.ctx.currentTime,.05);};
AU.tone=function(f,type,t0,dur,vol,o){const c=AU.ctx;if(!c||vol<=.003)return;o=o||{};const os=c.createOscillator(),g=c.createGain();os.type=type;os.frequency.setValueAtTime(f,t0);
  if(o.to)os.frequency.exponentialRampToValueAtTime(o.to,t0+dur);g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(vol,t0+(o.att||.01));
  g.gain.setValueAtTime(vol,t0+Math.max(o.att||.01,dur-(o.rel||.05)));g.gain.linearRampToValueAtTime(0,t0+dur);let node=g;
  if(o.lp){const f2=c.createBiquadFilter();f2.type='lowpass';f2.frequency.value=o.lp;g.connect(f2);node=f2;}
  if(o.vib){const l=c.createOscillator(),lg=c.createGain();l.frequency.value=o.vib;lg.gain.value=o.vibA||20;l.connect(lg);lg.connect(os.frequency);l.start(t0);l.stop(t0+dur);}
  let out=node;if(c.createStereoPanner&&o.pan){const p=c.createStereoPanner();p.pan.value=o.pan;node.connect(p);out=p;}
  os.connect(g);out.connect(AU.master);os.start(t0);os.stop(t0+dur+.05);};
AU.burst=function(t0,dur,vol,freq,q,type){const c=AU.ctx;if(!c)return;const s=c.createBufferSource();s.buffer=AU.noise;const f=c.createBiquadFilter();f.type=type||'bandpass';f.frequency.value=freq;f.Q.value=q||1;
  const g=c.createGain();g.gain.setValueAtTime(vol,t0);g.gain.exponentialRampToValueAtTime(.001,t0+dur);s.connect(f);f.connect(g);g.connect(AU.master);s.start(t0,Math.random());s.stop(t0+dur);};
AU.horn=function(type,vol,pan){if(!AU.ctx)return;const t=AU.ctx.currentTime;vol=(vol==null?1:vol)*.16;if(vol<.004)return;const o={lp:2400,pan,att:.02};
  if(type==='player'){const k=P.kind;if(k==='rickshaw'||k==='cycle'){AU.bell(k==='cycle'?1.6:2.2,0);}else if(k==='bike'){for(let q=0;q<2;q++)AU.tone(760,'square',t+q*.13,.1,vol*.8,o);}
    else if(k==='cng'){for(let q=0;q<2;q++)AU.tone(640,'square',t+q*.16,.11,vol*.8,o);}else if(k==='bus'||k==='dd'){AU.tone(196,'sawtooth',t,.7,vol,{...o,lp:1200});AU.tone(247,'sawtooth',t,.7,vol*.8,{...o,lp:1200});}
    else{AU.tone(415,'square',t,.38,vol,o);AU.tone(523,'square',t,.38,vol*.8,o);}}
  else if(type==='bus'||type==='truck'){AU.tone(196,'sawtooth',t,.7,vol,{...o,lp:1200});AU.tone(247,'sawtooth',t,.7,vol*.8,{...o,lp:1200});if(type==='truck')AU.tone(330,'sawtooth',t+.75,.4,vol*.7,{...o,lp:1200});}
  else if(type==='cng'){for(let k=0;k<2;k++)AU.tone(640,'square',t+k*.16,.11,vol*.8,o);}
  else if(type==='bike'){for(let k=0;k<3;k++)AU.tone(880,'square',t+k*.12,.08,vol*.7,o);}
  else if(type==='rickshaw')AU.bell(vol*5,pan);
  else{AU.tone(370,'square',t,.3,vol,o);AU.tone(466,'square',t,.3,vol*.8,o);}};
AU.bell=function(vol,pan){if(!AU.ctx)return;const t=AU.ctx.currentTime;vol=(vol==null?1:vol)*.12;for(let k=0;k<2;k++){AU.tone(1850,'sine',t+k*.17,.22,vol,{pan,rel:.18});AU.tone(2780,'sine',t+k*.17,.15,vol*.4,{pan});}};
AU.whistle=function(vol){if(!AU.ctx)return;const t=AU.ctx.currentTime;vol=(vol==null?1:vol)*.13;AU.tone(2900,'sine',t,.35,vol,{vib:28,vibA:120});AU.tone(2900,'sine',t+.45,.6,vol,{vib:28,vibA:120});};
AU.crash=function(k,what){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.burst(t,.45,.5*k,900,.7);AU.burst(t,.25,.35*k,3000,1.5);AU.tone(90,'sine',t,.25,.4*k,{to:45});
  if(what==='rickshaw'||what==='bike'){AU.tone(1400,'triangle',t+.05,.25,.12*k,{to:900});AU.bell(.5*k);}
  if(what==='bus'||what==='truck'){AU.tone(60,'sine',t,.4,.5*k,{to:35});}
  if(what==='person')AU.tone(520,'sawtooth',t+.05,.25,.06,{to:380,lp:1600});};
AU.thud=function(k){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(110,'sine',t,.18,.3*k,{to:55});AU.burst(t,.12,.15*k,400,1);};
AU.scrape=function(k){if(!AU.ctx||AU._scr>AU.ctx.currentTime)return;const t=AU.ctx.currentTime;AU._scr=t+.25;AU.burst(t,.3,.25*k,2200,2);AU.burst(t,.3,.15*k,4200,3);};
AU.glass=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;for(let k=0;k<5;k++)AU.tone(rr(2500,5200,CR),'sine',t+k*.035,.12,.05);AU.burst(t,.2,.15,6000,2);};
AU.whoosh=function(){if(!AU.ctx)return;const c=AU.ctx,t=c.currentTime,s=c.createBufferSource();s.buffer=AU.noise;const f=c.createBiquadFilter();f.type='bandpass';f.Q.value=2;
  f.frequency.setValueAtTime(600,t);f.frequency.exponentialRampToValueAtTime(2400,t+.35);const g=c.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.18,t+.1);g.gain.linearRampToValueAtTime(0,t+.4);
  s.connect(f);f.connect(g);g.connect(AU.master);s.start(t);s.stop(t+.45);};
AU.moo=function(vol){if(!AU.ctx)return;const t=AU.ctx.currentTime;vol=(vol==null?1:vol)*.2;AU.tone(150,'sawtooth',t,1.1,vol,{to:105,lp:520,att:.15,rel:.3,vib:5,vibA:6});};
AU.quack=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;for(let k=0;k<3;k++)AU.tone(rr(520,640,CR),'sawtooth',t+k*.16,.1,.08,{to:380,lp:1800});};
AU.splash=function(k){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.burst(t,.35,.25*k,1200,.8);AU.burst(t+.05,.3,.15*k,3000,1);};
AU.ring=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;for(let k=0;k<3;k++){AU.tone(880,'sine',t+k*.5,.18,.09);AU.tone(660,'sine',t+k*.5+.2,.18,.09);}};
AU.chime=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(880,'sine',t,.16,.08);AU.tone(1320,'sine',t+.14,.22,.08);};
AU.bird=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;for(let k=0;k<ri(2,4,CR);k++)AU.tone(rr(3000,4200,CR),'sine',t+k*.13,.09,.025,{to:rr(2400,5000,CR)});};
AU.drum=function(vol){if(!AU.ctx||vol<.02)return;const t=AU.ctx.currentTime;for(let k=0;k<4;k++){AU.tone(k%2?140:95,'sine',t+k*.22,.16,.35*vol,{to:60});AU.burst(t+k*.22+.11,.08,.12*vol,6000,1);}
  AU.tone(rr(500,700,CR),'square',t,.8,.04*vol,{vib:6,vibA:30,lp:1500});};
AU.siren=function(vol){if(!AU.ctx||vol<.02)return;const t=AU.ctx.currentTime;AU.tone(700,'square',t,.45,.06*vol,{to:1100,lp:2000});AU.tone(1100,'square',t+.45,.45,.06*vol,{to:700,lp:2000});};
AU.backfire=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.burst(t,.18,.6,300,.6);AU.tone(70,'sine',t,.15,.4,{to:40});};
AU.bat=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(900,'triangle',t,.06,.2,{to:500});AU.burst(t,.05,.2,2500,2);};
AU.coin=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(1500,'square',t,.07,.06);AU.tone(2000,'square',t+.07,.12,.06);};
AU.jingle=function(win){if(!AU.ctx)return;const t=AU.ctx.currentTime;
  if(win)[523,659,784,1046].forEach((f,i)=>AU.tone(f,'triangle',t+i*.13,i===3?.6:.16,.18));
  else[392,370,349,294].forEach((f,i)=>AU.tone(f,'sawtooth',t+i*.35,i===3?.9:.32,.12,{lp:900,vib:i===3?6:0,vibA:10}));};
AU.pickup=function(k){if(!AU.ctx)return;const t=AU.ctx.currentTime;[660,880,1320].forEach((f,i)=>AU.tone(f,'triangle',t+i*.07,.12,.12));if(k==='charge')AU.tone(220,'sawtooth',t,.35,.08,{to:880,lp:2500});};
AU.vip=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;for(let k=0;k<3;k++){AU.tone(900,'square',t+k*.5,.25,.07,{to:1400,lp:2400});AU.tone(1400,'square',t+k*.5+.25,.25,.07,{to:900,lp:2400});}};
AU.trainHorn=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(523,'triangle',t,.25,.07);AU.tone(659,'triangle',t+.28,.35,.07);};
AU.trainPass=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime,c=AU.ctx,s=c.createBufferSource();s.buffer=AU.noise;const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=320;
  const g=c.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.22,t+1.2);g.gain.linearRampToValueAtTime(0,t+3.2);s.connect(f);f.connect(g);g.connect(AU.master);s.start(t);s.stop(t+3.3);
  for(let k=0;k<10;k++)AU.tone(70,'square',t+.4+k*.24,.06,.05,{lp:300});};
AU.chain=function(v){if(!AU.ctx||v<.5)return;const t=AU.ctx.currentTime;AU.tone(2400,'square',t,.015,.025);};
AU.knock=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;for(let k=0;k<3;k++){AU.tone(160,'sine',t+k*.14,.09,.5,{to:90});AU.burst(t+k*.14,.06,.35,900,1.2);}};
AU.beep=function(n){if(!AU.ctx)return;const t=AU.ctx.currentTime;if(n===2){AU.tone(1568,'square',t,.09,.06);AU.tone(2093,'square',t+.1,.14,.06);}else AU.tone(1318,'square',t,.07,.04);};
AU.buzz=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(140,'sawtooth',t,.35,.09,{lp:900});};
AU.doorChime=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;[784,659,523].forEach((f,i)=>AU.tone(f,'sine',t+i*.22,.3,.08,{rel:.2}));};
AU.tick=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(rr(900,1200,CR),'triangle',t,.05,.09);};
AU.click=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(1400,'triangle',t,.04,.07);AU.tone(900,'triangle',t+.03,.04,.05);};
AU.bark=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;for(let k=0;k<2;k++){AU.tone(420,'sawtooth',t+k*.22,.12,.12,{to:260,lp:1500});AU.burst(t+k*.22,.1,.12,900,1);}};
AU.step=function(v){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.burst(t,.05,.05*v,rr(500,800,CR),1.5);};
AU.stamp=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(80,'sine',t,.25,.6,{to:40});AU.burst(t,.18,.45,600,.8);};
AU.ding=function(n){if(!AU.ctx)return;const t=AU.ctx.currentTime,f=[880,1108,1318][n%3]||880;AU.tone(f,'triangle',t,.5,.16,{rel:.4});AU.tone(f*2,'sine',t,.35,.05,{rel:.3});};
AU.count=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(rr(1700,1900,CR),'square',t,.025,.025);};
AU.levelUp=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;[523,659,784,1046,1318].forEach((f,i)=>AU.tone(f,'triangle',t+i*.09,.3,.12));AU.burst(t+.45,.5,.1,6000,.8);};
AU.alarm=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;for(let k=0;k<6;k++)AU.tone(k%2?1760:1568,'square',t+k*.12,.1,.05);};
AU.fanfare=function(){if(!AU.ctx)return;const t=AU.ctx.currentTime;[[523,0],[659,.12],[784,.24],[1046,.36],[784,.6],[1046,.72]].forEach(([f,d],i)=>AU.tone(f,'sawtooth',t+d,i>3?.45:.14,.07,{lp:2600}));
  AU.tone(130,'sine',t,.9,.18,{to:65});};
AU.heart=function(v){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.tone(55,'sine',t,.12,.35*v,{to:40});AU.tone(52,'sine',t+.18,.12,.25*v,{to:38});};
/* ---------- music: a small procedural loop that speeds up as time runs out ---------- */
const MUS={on:true,vol:.55,step:0,nt:0,bpm:104,int:.3,gain:null,scale:[0,1,4,5,7,8,11]};
MUS.init=function(){if(!AU.ctx||MUS.gain)return;MUS.gain=AU.ctx.createGain();MUS.gain.gain.value=0;MUS.gain.connect(AU.master);};
MUS.setVol=function(v){MUS.vol=v;};
MUS.note=function(semi,oct){return 110*Math.pow(2,(semi+12*oct)/12);};
MUS.update=function(){if(!AU.ctx||!MUS.gain)return;const c=AU.ctx,now=c.currentTime,want=(MUS.on&&!SETTINGS.mute?MUS.vol:0)*(GAME.state==='pause'?.35:1);
  MUS.gain.gain.setTargetAtTime(want*.55,now,.3);if(want<=.001){MUS.nt=now;return;}
  if(MUS.nt<now)MUS.nt=now+.05;const spb=60/MUS.bpm/4;
  while(MUS.nt<now+.15){MUS.play(MUS.step,MUS.nt);MUS.step=(MUS.step+1)%64;MUS.nt+=spb;}};
MUS.hit=function(f,type,t,dur,vol,o){const c=AU.ctx;o=o||{};const os=c.createOscillator(),g=c.createGain();os.type=type;os.frequency.setValueAtTime(f,t);if(o.to)os.frequency.exponentialRampToValueAtTime(o.to,t+dur);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol,t+(o.att||.005));g.gain.exponentialRampToValueAtTime(.0008,t+dur);let n=g;if(o.lp){const fl=c.createBiquadFilter();fl.type='lowpass';fl.frequency.value=o.lp;g.connect(fl);n=fl;}
  os.connect(g);n.connect(MUS.gain);os.start(t);os.stop(t+dur+.05);};
MUS.noise=function(t,dur,vol,freq,type){const c=AU.ctx,s=c.createBufferSource();s.buffer=AU.noise;const f=c.createBiquadFilter();f.type=type||'highpass';f.frequency.value=freq;const g=c.createGain();
  g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0008,t+dur);s.connect(f);f.connect(g);g.connect(MUS.gain);s.start(t,Math.random());s.stop(t+dur+.02);};
MUS.play=function(st,t){const I=MUS.int,s16=st%16,bar=Math.floor(st/16),sc=MUS.scale;
  // dhol-ish kick + tabla-ish taps
  if(I>.25&&(s16===0||s16===10||(I>.7&&s16===7)))MUS.hit(120,'sine',t,.28,.55,{to:42});
  if(I>.25&&(s16===4||s16===12))MUS.noise(t,.12,.22,1800,'bandpass');
  if(I>.45&&s16%2===1)MUS.noise(t,.04,.06+I*.05,7000);
  if(s16===6||s16===14)MUS.hit(330,'triangle',t,.09,.08*I+.03,{to:250});
  // bass
  const prog=[0,0,5,4],root=prog[bar%4];if(I>.2&&(s16===0||s16===3||s16===8||s16===11))MUS.hit(MUS.note(root,-1),'sawtooth',t,.22,.12,{lp:500});
  // hook (plucky, in a Bhairav-ish scale)
  const hook=[0,null,2,4,null,3,2,null,1,null,0,null,2,null,4,5];const h=hook[s16];
  if(h!=null&&(bar%2===0||I>.6)){const deg=sc[(h+root+7)%7],oct=1+Math.floor((h+root)/7);MUS.hit(MUS.note(deg,oct),'triangle',t,.18,.07+.03*I,{lp:3000});}
  if(I<.25&&s16%4===0)MUS.hit(MUS.note(sc[(bar+s16/4)%7],1),'sine',t,.6,.05);};
AU.babble=0;
AU.update=function(dt){if(!AU.ctx)return;MUS.update();const t=AU.ctx.currentTime,s=Math.abs(P.v),run=GAME.state==='play'||GAME.state==='arrive';const k=P.kind,inp=P.inp||KEYS;
  const g=Math.floor(s/7),rev=(s-g*7)/7;let f=42+rev*55+g*7+(inp.up?6:0);if(k==='bike')f*=1.9;if(k==='cng')f=60+s*6;if(k==='bus'||k==='dd')f=30+rev*30+g*4;if(k==='metro')f=120+s*22;
  AU.eo1.frequency.setTargetAtTime(f,t,.05);AU.eo2.frequency.setTargetAtTime(f*.5,t,.05);
  AU.ef.frequency.setTargetAtTime((k==='metro'?900:380)+s*28+(inp.up?300:0),t,.08);
  const quiet=k==='walk'||k==='rickshaw'||k==='cycle';
  AU.eg.gain.setTargetAtTime(run&&P.fall<=0&&!quiet?(k==='metro'?.012+s*.0009:(k==='bus'||k==='dd')?.06:.05+(inp.up?.035:0)+(P.boosting?.03:0)+(P.damage>80?.02:0)):0,t,.1);
  const leg=P.node?legAt(P.node,P.d):null,z=leg?zoneKind(leg.type):'res';
  AU.amb.g.gain.setTargetAtTime(run?(z==='market'?.07:z==='main'?.055:.03):0,t,.4);AU.road.g.gain.setTargetAtTime(run?.12+s*.004:0,t,.3);
  AU.rain.g.gain.setTargetAtTime(run&&GAME.weather==='rain'?.12:0,t,.5);
  AU.water.g.gain.setTargetAtTime(run&&(P.surface==='flood')?.1+s*.01:0,t,.15);
  const bab=run?Math.min(.06,AU.babble+(z==='market'?.015:0)):0;for(const b of AU.bab)b.gain.setTargetAtTime(bab,t,.3);AU.babble=Math.max(0,AU.babble-dt*.02);
  if(!run)return;
  if(P.kind==='rickshaw'||P.kind==='cycle'){AU._ch=(AU._ch||0)-dt*Math.abs(P.v)*.9;if(AU._ch<=0){AU._ch=1;AU.chain(Math.abs(P.v));}}
  if(P.kind==='walk'&&P.v>.5){AU._st=(AU._st||0)-dt*P.v*.8;if(AU._st<=0){AU._st=1;AU.step(clamp(P.v/4,.3,1));}}
  AU.ambT-=dt;if(AU.ambT<=0){AU.ambT=z==='main'?rr(.8,2.5,CR):z==='market'?rr(1.2,3,CR):rr(2.5,5,CR);
    const types=['car','bus','cng','bike','rickshaw'];const r=CR();
    if(leg&&leg.elevated&&r<.6)AU.horn(pick(['car','bus','truck'],CR),rr(.08,.2,CR),rr(-.9,.9,CR));
    else if((z==='res'||z==='alley')&&r<.35&&GAME.weather!=='rain')AU.bird();else if((z==='res'||z==='market'||z==='alley')&&r<.55)AU.bell(rr(.15,.4,CR),rr(-.8,.8,CR));
    else AU.horn(pick(types,CR),rr(.12,.35,CR),rr(-.9,.9,CR));}};
