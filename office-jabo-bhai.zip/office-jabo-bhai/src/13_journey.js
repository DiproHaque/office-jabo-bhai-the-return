/* ============================================================
   13 JOURNEY: plans (your way to work), legs, AI drivers,
   walking, local bus / double-decker, metro, mini-games
   ============================================================ */
const PLANS={
  bus:{name:'লোকাল বাস',short:'বাস',lvl:1,legs:['walk','bus','walk'],fare:'৳৩০',tip:'সস্তা, কিন্তু ভিড়। দাঁড়িয়ে ব্যালান্স রাখো, ঠিক সময়ে "ওস্তাদ, নামবো!"',risk:2,comfort:1,par:9.8},
  metro:{name:'রিকশা + মেট্রো',short:'মেট্রো',lvl:1,legs:['rickshaw','metro','walk'],fare:'৳১৪০',tip:'রিকশায় দরদাম, গেটে কার্ড, দরজায় যুদ্ধ। তারপর জ্যামের ওপর দিয়ে উড়ে যাও!',risk:1,comfort:2,par:9.6},
  bike:{name:'মোটরবাইক',short:'বাইক',lvl:1,legs:['bike'],fare:'৳৪০',tip:'চিপায় চিপায় ঢুকে যাও। দ্রুত, কিন্তু পড়লে খবর আছে।',risk:3,comfort:2,par:12.6},
  car:{name:'প্রাইভেট কার',short:'গাড়ি',lvl:2,legs:['car'],fare:'৳১৫০',tip:'এসির আরাম, জ্যামের যন্ত্রণা। শেষে ঠিকমতো পার্কিং করতে হবে।',risk:2,comfort:3,par:12.6},
  dd:{name:'ডাবল ডেকার',short:'ডাবল ডেকার',lvl:3,legs:['walk','dd','walk'],fare:'৳২৫',tip:'বিআরটিসি! উপরতলার সিট পেলে রাজা, না পেলে ব্যালান্সের খেলা।',risk:1,comfort:2,par:10.3},
  cng:{name:'সিএনজি',short:'সিএনজি',lvl:4,legs:['cng'],fare:'৳৩০০',tip:'মিটারে যাবে না! দরদাম করো, শর্টকাটের জুয়া খেলো।',risk:2,comfort:2,par:10.0},
  cycle:{name:'সাইকেল',short:'সাইকেল',lvl:5,legs:['cycle'],fare:'৳০',tip:'ভাড়া শূন্য, দম লাগে। গ্যাস ছাড়লে দম ফেরে।',risk:2,comfort:1,par:7.6}};
const PLAN_ORDER=['bus','metro','bike','car','dd','cng','cycle'];
const LEG_NAME={walk:'হাঁটা',bus:'লোকাল বাস',dd:'ডাবল ডেকার',rickshaw:'রিকশা',cng:'সিএনজি',metro:'মেট্রো',car:'প্রাইভেট কার',bike:'মোটরবাইক',cycle:'সাইকেল'};
const CAMCFG={car:{back:8.6,up:3.7,look:11},bike:{back:6.8,up:3.1,look:10},cycle:{back:5.8,up:2.7,look:9},walk:{back:4.6,up:2.3,look:7},
  rickshaw:{back:6.4,up:3.1,look:10},cng:{back:7,up:3.3,look:11},bus:{back:12.8,up:5.2,look:15},dd:{back:13.8,up:6.6,look:16},metro:{back:26,up:10,look:24}};

const TIMERS=[];function later(sec,fn){TIMERS.push({t:sec,fn});}
function updateTimers(dt){for(let i=0;i<TIMERS.length;i++){const tm=TIMERS[i];tm.t-=dt;if(tm.t<=0){TIMERS.splice(i--,1);try{tm.fn();}catch(e){console.error(e);}}}}
function clearTimers(){TIMERS.length=0;}
const JR={plan:null,legs:[],li:-1,leg:null,comfort:100,perfect:0,fares:0,stumbles:0,seat:false,bal:0,balV:0,stun:0,hold:0,vMul:1,sway:0,
  req:0,urgeT:0,urgeCd:0,jamT:0,flags:{},snooze:false,breakfast:false,qte:null,xferT:0,lastA:0,lastV:0};
function resetJR(){Object.assign(JR,{plan:null,legs:[],li:-1,leg:null,comfort:100,perfect:0,fares:0,stumbles:0,seat:false,bal:0,balV:0,stun:0,hold:0,vMul:1,sway:0,
  req:0,urgeT:0,urgeCd:0,jamT:0,flags:{},snooze:false,breakfast:false,qte:null,xferT:0,bus:null,metro:null,walk:null,ride:null,parked:null,lastA:0,lastV:0,clockHold:0,boarding:null});}

/* ---------- plan → legs on today's route ---------- */
function planLegs(pk){const n=ROUTE.root,st=n.stations,stops=n.stops,od=n.officeD,ms=ROUTE.mainStart;
  if(pk==='bus'||pk==='dd'){const A=stops[0],B=stops[stops.length-1];let mid=stops.slice(1,-1);if(pk==='dd')mid=mid.filter((s,i)=>i%2===1);
    return[{type:'walk',d0:Math.max(ms-58,A.d-104),d1:A.d-4,to:'stop'},{type:pk,d0:A.d,d1:B.d,stops:mid.concat([B]),target:B},{type:'walk',d0:Math.max(B.d+3,od-112),d1:od,to:'dest'}];}
  if(pk==='metro'){const SA=st[0],SB=st[st.length-1];
    return[{type:'rickshaw',d0:8,d1:SA.d-13,to:'station'},{type:'metro',d0:SA.d,d1:SB.d,stations:st.filter(s=>s.d>SA.d+1&&s.d<SB.d-1),A:SA,B:SB},{type:'walk',d0:Math.max(SB.d+14,od-112),d1:od,to:'dest'}];}
  return[{type:pk,d0:8,d1:od,to:'dest'}];}
function legKind(t){return t==='walk'?'walk':t==='bus'||t==='dd'?'stand':t==='metro'?'metro':(t==='rickshaw'||t==='cng')?'ride':'drive';}
/* par time (real seconds) of a plan on today's route — sets how fast the clock runs */
function planPar(pk){const legs=planLegs(pk);let t=0;
  for(const L of legs){const len=Math.max(0,L.d1-L.d0);
    if(L.type==='walk')t+=len/2.75+(L.to==='stop'?5:0);
    else if(L.type==='bus')t+=len/PLANS.bus.par+L.stops.length*1.6+4;
    else if(L.type==='dd')t+=len/PLANS.dd.par+L.stops.length*1.5+1;
    else if(L.type==='rickshaw')t+=len/5.2+5;
    else if(L.type==='metro')t+=len/19.5+L.stations.length*5.6+14;
    else t+=len/PLANS[L.type].par+(L.type==='car'?7:L.type==='cng'?4:0);}
  return t;}

/* ---------- journey lifecycle ---------- */
function startJourney(pk){resetJR();JR.plan=pk;JR.legs=planLegs(pk);JR.li=-1;GAME.style=0;GAME.near=0;GAME.combo=0;}
function nextLeg(){JR.li++;if(JR.li>=JR.legs.length){arrive();return;}const L=JR.legs[JR.li];JR.leg=L;startLeg(L,JR.li===0);}
function legModel(t){return t==='walk'?'walk':t;}
function startLeg(L,first){const t=L.type,n=ROUTE.root;JR.vMul=1;JR.seat=false;JR.bal=0;JR.balV=0;JR.stun=0;JR.urgeT=0;JR.req=0;JR.hold=0;JR.sway=0;
  buildPlayer(legModel(t));P.mode=legKind(t);P.v=0;P.sv=0;P.h=0;P.steer=0;P.fall=0;P.frozen=0;P.damage=t==='car'||t==='bike'||t==='cycle'?0:P.damage;P.stuckT=0;
  if(t!=='cycle')P.boost=JR.breakfast?1:.75;else P.boost=JR.breakfast?1:.8;
  P.inp=P.mode==='drive'?KEYS:AIK;for(const k in AIK)AIK[k]=0;
  const lay=laneLayout(n,L.d0,_lay);
  if(t==='walk'){P.d=L.d0;P.x=-(halfAt(n,L.d0)+swAt(n,L.d0)*.55);JR.walk={stam:JR.breakfast?1:.8,ph:0,trip:0};}
  else if(t==='bus'||t==='dd'){P.d=L.d0+3.2;P.x=lay.our[lay.our.length-1];setupBus(L);}
  else if(t==='metro'){setupMetro(L);}
  else{P.d=L.d0;P.x=lay.our[lay.our.length-1]*.5+(lay.our[0])*.5;if(!lay.div)P.x=-lay.half*.55;JR.ride={stuckT:0};}
  // clear vehicles on top of us
  for(const v of GAME.veh)if(Math.abs(v.d-P.d)<(t==='bus'||t==='dd'?16:9)&&Math.abs(v.x-P.x)<3.2)removeVeh(v);GAME.veh=GAME.veh.filter(v=>!v.dead);
  if(t!=='metro'){playerWorld(PW);poseModel(0);}else placeMetro();
  CAM.yaw=PW.a;updateCamera(0,true);
  setTouchLayout(P.mode,t);updateJourneyStrip();
  if(!first||true)showXfer(t,L);
  // leg intros
  if(t==='rickshaw')later(2.1,()=>haggleRickshaw());
  if(t==='cng')later(2.1,()=>haggleCng());
  if(t==='dd'&&!first)later(1.7,()=>seatRace('ddTop'));
  if(t==='car')JR.parked=null;
  logEv(LEG_NAME[t]+' শুরু');}

/* ---------- transfer card ---------- */
const XFER_TIP={walk:'হাঁটো · ◀ ▶ দিয়ে পাশ কাটাও · দৌড়াতে বুস্ট',bus:'দাঁড়িয়ে আছো! ◀ ▶ দিয়ে ব্যালান্স রাখো · স্টপের আগে "নামবো!"',dd:'◀ ▶ দিয়ে ব্যালান্স · স্টপের আগে "নামবো!"',
  rickshaw:'◀ ▶ = "মামা, বামে/ডানে" · গ্যাস = "জোরে চালান!"',cng:'◀ ▶ = লেন বলে দাও · গ্যাস = "টান দেন!"',metro:'ব্যালান্স রাখো, নিজের স্টেশনে নামার জন্য তৈরি থাকো',
  car:'চালাও! শেষে অফিসের সামনে P-এ পার্ক করো',bike:'চিপায় ঢোকো, কিন্তু সাবধানে',cycle:'গ্যাস চাপলে দম কমে, ছাড়লে ফেরে'};
function showXfer(t,L){const el=$('xfer');$('xferIco').innerHTML=modeIcon(t);$('xferT').textContent=xferTitle(t,L);$('xferS').textContent=TOUCH.on?XFER_TIP[t].replace(/গ্যাস/g,'ডানের বোতাম'):XFER_TIP[t];
  el.hidden=false;el.classList.remove('go');void el.offsetWidth;el.classList.add('go');JR.clockHold=1.1;JR.hold=1.1;JR.xferT=1.9;AU.whoosh();}
function xferTitle(t,L){if(t==='walk')return L.to==='stop'?'বাস স্টপ পর্যন্ত হাঁটো':L.to==='dest'?(ROUTE.trip.D.track==='varsity'?'ক্যাম্পাসে ঢোকো!':'অফিস পর্যন্ত হাঁটো!'):'হাঁটো';
  if(t==='metro')return'মেট্রো: '+L.A.name+' → '+L.B.name;if(t==='rickshaw')return'রিকশায় স্টেশন';if(t==='bus'||t==='dd')return LEG_NAME[t]+': '+L.target.name+' পর্যন্ত';return LEG_NAME[t]+'। চলো!';}

/* ---------- shared AI: pick a free lateral position, steer to it ---------- */
function aiFreeX(lo,hi,pref,prefW){let best=P.x,bestF=-1e9;const look=P.cfg.heavy?120:90;
  for(let x=lo;x<=hi+.01;x+=.45){let free=look;
    for(const v of GAME.veh){const rel=v.d-P.d;if(rel>-(P.l/2+1)&&Math.abs(v.x-x)<(v.w+P.w)/2+.35){const f=rel-(v.len+P.l)/2+(v.dir>0?v.v*2.2:-v.v*2.5);if(f<free)free=f;}}
    for(const c of GAME.cross){const rel=c.d-P.d;if(rel>-1&&Math.abs(c.x-x)<(c.w+P.w)/2+.5)free=Math.min(free,rel-P.l/2-2);}
    for(const o of GAME.obst){if(o.surface==='puddle'||o.surface==='mud')continue;if(o.d1>P.d&&x+P.w/2>o.x0-.3&&x-P.w/2<o.x1+.3)free=Math.min(free,o.d0-P.d-P.l/2-2);}
    let sc=free-Math.abs(x-P.x)*1.1-(pref!=null?Math.abs(x-pref)*(prefW||0):0);if(sc>bestF){bestF=sc;best=x;JR._free=free;}}
  return best;}
function aiSteer(tx,inp,gain){const want=Math.atan2(-(tx-P.x),Math.max(6,P.v*1.1+5))*(gain||1);inp.left=P.h<want-.03?1:0;inp.right=P.h>want+.03?1:0;}
function aiSpeed(vDes,inp){inp.up=P.v<vDes-.3?1:0;inp.down=P.v>vDes+.8?1:0;}
function aiSignalStop(){for(const s of WORLD.signals.values()){const rel=s.stop-P.d-P.l/2;if(s.state!=='green'&&rel>-1&&rel<P.v*1.8+8)return Math.max(0,rel);}return null;}
function aiPolice(){for(const c of GAME.cross){if(c.role==='police'&&c.stay&&!c.apDone){const rel=c.d-P.d;if(rel>0&&rel<45){if(rel<17&&P.v<1)c.apDone=true;return rel;}}}return null;}
function freeAhead(x){let free=200;for(const v of GAME.veh){const rel=v.d-P.d;if(rel>0&&Math.abs(v.x-x)<(v.w+P.w)/2+.3){const f=rel-(v.len+P.l)/2;if(f<free)free=f;}}
  for(const c of GAME.cross){const rel=c.d-P.d;if(rel>0&&Math.abs(c.x-x)<(c.w+P.w)/2+.4)free=Math.min(free,rel-P.l/2-1.5);}
  for(const o of GAME.obst){if(o.surface==='puddle'||o.surface==='mud')continue;const along=o.d0<P.d-1,m=along?-.15:(P.cfg&&P.cfg.heavy?.02:.2);/* already alongside it and not touching → it is not in our way */
    if(o.d1>P.d&&x+P.w/2>o.x0-m&&x-P.w/2<o.x1+m)free=Math.min(free,along?0:o.d0-P.d-P.l/2-1.2);}return free;}

/* ---------- rickshaw / CNG: the driver drives, you shout directions ---------- */
function rideControl(dt){const L=JR.leg,inp=AIK,lay=laneLayout(P.node,P.d,_lay),h=lay.half;
  // your requests
  const want=KEYS.left-KEYS.right;if(want){JR.req=clamp(JR.req+want*dt*1.6,-1,1);if(!JR.reqSaid||GAME.t-JR.reqSaid>4){JR.reqSaid=GAME.t;say(want>0?'মামা, বামে চাপেন!':'মামা, ডানে চাপেন!','তুমি',{obj:P.model.group,y:2.4},PRIO.react,'me',1.4);}}
  else JR.req*=Math.exp(-dt*.25);
  let lo,hi;if(lay.div){const isR=P.kind==='rickshaw';lo=lay.our[lay.our.length-1]-.6;hi=isR?lay.our[Math.max(0,lay.our.length-2)]+.4:lay.our[0]+.2;}else{lo=-h+P.w/2+.3;hi=Math.min(h*.45,h-P.w/2-.3);}
  const pref=lerp(hi,lo,(JR.req+1)/2);const tx=aiFreeX(lo,hi,pref,1.6);aiSteer(tx,inp);
  // speed: urge with gas, calm with brake
  const urge=KEYS.up||KEYS.boost;let vDes=P.cfg.maxV;
  if(urge&&P.boost>.05){inp.boost=1;vDes=P.cfg.boostV;if(!JR.urgeSaid||GAME.t-JR.urgeSaid>6){JR.urgeSaid=GAME.t;say(P.kind==='rickshaw'?pickLine('urgeRickshaw'):pickLine('urgeCng'),'তুমি',{obj:P.model.group,y:2.4},PRIO.react,'me',1.6);}}
  else{inp.boost=0;if(urge&&P.boost<=.05&&(!JR.tiredSaid||GAME.t-JR.tiredSaid>7)){JR.tiredSaid=GAME.t;say(pickLine(P.kind==='rickshaw'?'rickshawTired':'cngTired'),P.kind==='rickshaw'?'রিকশাওয়ালা':'সিএনজি ড্রাইভার',{obj:P.model.group,y:2.6},PRIO.event);}}
  if(KEYS.down)vDes*=.45;
  const free=freeAhead(P.x);vDes=Math.min(vDes,Math.max(0,(free-1.5)*.9));
  const sg=aiSignalStop();if(sg!=null)vDes=Math.min(vDes,Math.max(0,sg*.5-.5));
  const pol=aiPolice();if(pol!=null){vDes=Math.min(vDes,pol>17?Math.max(1.5,(pol-14)*.5):0);}
  if(P.d>L.d1-30)vDes=Math.min(vDes,Math.max(0,(L.d1-P.d)*.4));
  aiSpeed(vDes,inp);inp.hand=0;
  if(P.boosting&&P.kind==='rickshaw')AU.chainFast=1;
  // unstick
  if(P.v<.4&&!sg&&!pol&&P.d<L.d1-3){JR.ride.stuckT+=dt;if(JR.ride.stuckT>(free>8?4:9)){JR.ride.stuckT=0;if(free>8)resetCar();else unstickAhead();}}else JR.ride.stuckT=0;
  if(P.d>=L.d1-3&&P.v<.4)endRide();}
function endRide(){const L=JR.leg;if(L.done)return;L.done=true;if(L.to==='dest'){const f=JR.fare||300;GAME.wallet-=f;JR.fares+=f;AU.coin();arrive();return;}
  const fare=JR.fareDue||0;if(fare){GAME.wallet-=fare;JR.fares+=fare;AU.coin();toastMsg('রিকশা ভাড়া ৳'+bn(fare),'info',1800);}
  say(pickLine('rickshawBye'),'রিকশাওয়ালা',{obj:P.model.group,y:2.6},PRIO.event);
  later(0.9,()=>{if(GAME.state==='play')metroGate();});}

/* haggling */
function haggleRickshaw(){if(GAME.state!=='play')return;const st=JR.legs[1].A.name;
  showChoice({title:'রিকশাওয়ালা: "'+st+' স্টেশন? ৮০ টাকা।"',text:'দরদাম করবে?',secs:6,opts:[
    {t:'৫০ টাকা দিবো',s:'ঝুঁকি আছে',fn:()=>{if(R()<.6){JR.fareDue=50;JR.vMul=.9;say('আইচ্ছা, ৫০-ই দেন… (মন খারাপ)','রিকশাওয়ালা',{obj:P.model.group,y:2.6},PRIO.event);toastMsg('৳৩০ বাঁচলো! কিন্তু মামা একটু ধীরে চালাবে','info');}
      else{JR.fareDue=70;addTime(30);say('৫০ টাকায় যামু না! অন্য রিকশা দেখেন!','রিকশাওয়ালা',{obj:P.model.group,y:2.6},PRIO.event,'shout');toastMsg('অন্য রিকশা খুঁজতে ৩০ সেকেন্ড গেল','bad');}}},
    {t:'৭০ চলেন',s:'মাঝামাঝি',fn:()=>{JR.fareDue=70;say('চলেন, উঠেন!','রিকশাওয়ালা',{obj:P.model.group,y:2.6},PRIO.event);}},
    {t:'ঠিক আছে, ৮০',s:'মামা খুশি',fn:()=>{JR.fareDue=80;JR.vMul=1.07;P.boost=1;say('আপনি ভালো মানুষ! টান দিতেছি!','রিকশাওয়ালা',{obj:P.model.group,y:2.6},PRIO.event);}}]});}
function haggleCng(){if(GAME.state!=='play')return;const tr=ROUTE.trip;
  showChoice({title:'সিএনজি: "'+tr.D.name+'? ৩৫০ টাকা।"',text:'মিটারে যাবে না বলছে…',secs:6,opts:[
    {t:'মিটারে চলেন!',s:'৳২২০ · ঝুঁকি',fn:()=>{if(R()<.5){JR.fare=220;JR.vMul=.9;say('মিটার নষ্ট মামা… আচ্ছা চলেন!','সিএনজি ড্রাইভার',{obj:P.model.group,y:2.6},PRIO.event);}
      else{JR.fare=300;addTime(60);say('মিটারে যামু না! পরেরটা দেখেন!','সিএনজি ড্রাইভার',{obj:P.model.group,y:2.6},PRIO.event,'shout');toastMsg('পরের সিএনজি পেতে ১ মিনিট গেল','bad');}}},
    {t:'৩০০ দিবো',s:'মাঝামাঝি',fn:()=>{JR.fare=300;say('আচ্ছা, উঠেন!','সিএনজি ড্রাইভার',{obj:P.model.group,y:2.6},PRIO.event);}},
    {t:'৪০০, টান দেন!',s:'দ্রুত',fn:()=>{JR.fare=400;JR.vMul=1.1;P.boost=1;say('এইটা হইলো কথা! ধরেন শক্ত কইরা!','সিএনজি ড্রাইভার',{obj:P.model.group,y:2.6},PRIO.event);}}]});}
function cngShortcut(){if(JR.flags.short||GAME.state!=='play')return;JR.flags.short=1;
  showChoice({title:'ড্রাইভার: "মামা, শর্টকাট নিমু? গলি দিয়া!"',text:'জুয়া খেলবে?',secs:5,opts:[
    {t:'হ্যাঁ, শর্টকাট!',s:'লাভ বা লস',fn:()=>shortcutJump(R()<.6)},{t:'না, মেইন রোডেই',s:'নিরাপদ',fn:()=>say('আপনার যেমন ইচ্ছা মামা।','সিএনজি ড্রাইভার',{obj:P.model.group,y:2.6},PRIO.event)}]});}
function shortcutJump(ok){const L=JR.leg,skip=Math.min(150,L.d1-P.d-60);if(skip<40)return;fadeCut(()=>{
    P.d+=skip;const lay=laneLayout(P.node,P.d,_lay);P.x=lay.div?lay.our[1]||lay.our[0]:-lay.half*.5;P.h=0;P.v=6;
    for(const v of GAME.veh)if(Math.abs(v.d-P.d)<14)removeVeh(v);GAME.veh=GAME.veh.filter(v=>!v.dead);for(const c of GAME.cross){if(Math.abs(c.d-P.d)<10){scene.remove(c.m);c.dead=true;}}
    updateChunks(P.node,P.d,0,true);playerWorld(PW);CAM.yaw=PW.a;updateCamera(0,true);
    if(ok){addTime(35);GAME.style+=120;toastMsg('শর্টকাট কাজে লাগলো! অনেক সময় বাঁচলো','good',2600);say('দেখছেন? ঢাকার গলি আমি চিনি!','সিএনজি ড্রাইভার',{obj:P.model.group,y:2.6},PRIO.event);logEv('শর্টকাটে জিত');}
    else{addTime(330);toastMsg('গলিতে আরও বড় জ্যাম! ৫ মিনিট গেল','bad',2800);say('গলিতে আজকে বিয়া বাড়ি… সরি মামা!','সিএনজি ড্রাইভার',{obj:P.model.group,y:2.6},PRIO.event);logEv('শর্টকাটে ধরা');}});}

function unstickAhead(){const lay=laneLayout(P.node,P.d+14,_lay);let bx=P.x,bf=-1;for(const x of lay.our){const f=freeAheadAt(P.d+14,x);if(f>bf){bf=f;bx=x;}}
  P.d+=14;P.x=bx;P.h=0;P.v=Math.max(P.v,2);for(const v of GAME.veh)if(Math.abs(v.d-P.d)<(P.l+v.len)/2+2&&Math.abs(v.x-P.x)<(P.w+v.w)/2+.4)removeVeh(v);GAME.veh=GAME.veh.filter(v=>!v.dead);playerWorld(PW);}
function freeAheadAt(d,x){let free=60;for(const v of GAME.veh){const rel=v.d-d;if(rel>-P.l&&Math.abs(v.x-x)<(v.w+P.w)/2+.3)free=Math.min(free,rel);}for(const o of GAME.obst){if(o.surface)continue;if(o.d1>d-P.l&&x+P.w/2>o.x0&&x-P.w/2<o.x1)free=Math.min(free,o.d0-d);}return free;}
/* ---------- local bus / double-decker ---------- */
function setupBus(L){JR.bus={next:0,dwell:0,stopping:null,knocked:false,missed:false,alight:false,boardT:1.6,said:{}};
  const rg=mulberry32(ROUTE.seed^0x7777);for(const s of L.stops)s.board=rg()<.42;L.target.board=false;
  JR.fares+=JR.leg.type==='dd'?25:30;GAME.wallet-=JR.leg.type==='dd'?25:30;}
function busControl(dt){const L=JR.leg,B=JR.bus,inp=AIK,lay=laneLayout(P.node,P.d,_lay);
  if(B.boardT>0){B.boardT-=dt;aiSpeed(0,inp);inp.left=inp.right=0;return;}
  // next stop we will stop at
  let ns=null;for(const s of L.stops){if(s.d+(s===L.target?9:5)<P.d)continue;if(s===L.target?(B.knocked):s.board){ns=s;break;}}
  if(B.knocked&&!B.alight&&!B.missed&&P.d>L.target.d+9){B.missed=true;missedStop();}
  const curb=lay.our[lay.our.length-1],second=lay.our[Math.max(0,lay.our.length-2)];
  let lo=Math.min(curb,second)-.3,hi=Math.max(curb,second)+.3;if(!lay.div){lo=-lay.half+P.w/2+.3;hi=-lay.half*.3;}
  if((B.blockT||0)>2.5){lo=lay.our[lay.our.length-1]-.3;hi=lay.our[0]+.3;}
  let stopNear=ns&&ns.d-P.d<110;if(stopNear&&ns.d-P.d>14&&freeAhead(curb)<Math.min(40,ns.d-P.d-6)){stopNear=false;lo=lay.our[lay.our.length-1]-.3;hi=lay.our[0]+.3;}/* curb blocked (roadworks, parked bus): go round first */
  if(!stopNear&&lay.div){lo=Math.min(lo,lay.our[lay.our.length-1]-.3);hi=Math.max(hi,lay.our[0]+.3);}const tx=stopNear?curb:aiFreeX(lo,hi,curb,.35);aiSteer(tx,inp,.9);
  let vDes=P.cfg.maxV*(JR.urgeT>0?1.18:1);if(JR.urgeT>0)inp.boost=1;else inp.boost=0;
  const free=freeAhead(P.x);vDes=Math.min(vDes,Math.max(0,(free-2)*.8));
  const sg=aiSignalStop();if(sg!=null)vDes=Math.min(vDes,Math.max(0,sg*.5-.5));
  if(ns){const dist=ns.d+1.5-P.d;vDes=Math.min(vDes,Math.sqrt(Math.max(0,2*2.3*dist))+(dist>2?.6:0));
    if(dist<6&&P.v>vDes+.15)inp.down=1;
    if(dist<2.2&&P.v<.6){// stopped at a stop
      if(B.dwellAt!==ns){B.dwellAt=ns;B.dwell=ns===L.target?0:1.3;if(ns!==L.target){spawnBoarders(ns);if(R()<.35)sayHelper();}}
      B.dwell-=dt;vDes=0;if(ns===L.target){aiSpeed(0,inp);alightBus();return;}
      if(B.dwell<=0){ns.board=false;}}}
  // knock window & the missed-stop jump
  const T=L.target,td=T.d-P.d;
  if(!B.knocked&&!B.missed&&td<-5){B.missed=true;missedStop();}
  if(B.missed&&!B.alight){vDes=Math.min(vDes,2.6);}
  if(P.d>ROUTE.mainEnd-6)vDes=0;
  const precise=ns&&ns.d+1.5-P.d<6;aiSpeed(vDes,inp);if(precise&&P.v>vDes+.15){inp.down=1;inp.up=0;}inp.hand=0;
  // stuck behind something that will not move (roadworks, a broken bus): go round it, or at worst squeeze past
  const waiting=(ns&&ns.d+1.5-P.d<3)||sg!=null||B.dwell>0;
  if(P.v<.5&&!waiting&&free<12){B.blockT=(B.blockT||0)+dt;if(B.blockT>5){B.blockT=0;unstickAhead();}}else if(P.v>3)B.blockT=Math.max(0,(B.blockT||0)-dt*.5);
  setAction(B.knocked||B.missed?null:(td<190&&td>-5?'knock':null));
  // balance while standing
  updateBalance(dt,JR.urgeT>0?1.5:1);
  if(JR.urgeT>0)JR.urgeT-=dt;if(JR.urgeCd>0)JR.urgeCd-=dt;
  // the occasional free seat
  if(!JR.seat&&!JR.flags.seat1&&P.d>L.d0+(L.d1-L.d0)*.4&&P.v<3&&R()<dt*.5){JR.flags.seat1=1;seatRace('seat');}
  // bus race on the main road
  if(!JR.flags.race&&P.d>L.d0+(L.d1-L.d0)*.25&&lay.div&&R()<dt*.08){JR.flags.race=1;busRace();}}
function sayHelper(){say(pickLine('helperRide'),'হেলপার',{obj:P.model.group,y:3.6},PRIO.event,'shout');}
function spawnBoarders(s){const h=halfAt(P.node,s.d);for(let k=0;k<2;k++){const c=spawnCrosser(pick(T.people,CR),P.node,s.d+rr(-1,1),-(h+1.2+k*.6),1.1,{bounds:-(h-.4),life:5,noDodge:true});}}
function knock(){const B=JR.bus,L=JR.leg;if(!B||B.knocked||B.missed)return;const td=L.target.d-P.d;
  if(td>190){say('এখনো অনেক দূর মামা, বসেন!','হেলপার',{obj:P.model.group,y:3.6},PRIO.event);return;}
  B.knocked=true;AU.knock();say(pickLine('knockMe'),'তুমি',{obj:P.model.group,y:3.2},PRIO.urgent,'me',1.6);
  if(td>=30&&td<=135){JR.perfect++;GAME.style+=80;popMsg('ঠিক সময়ে ডাক! +৮০');later(0.7,()=>{if(GAME.state==='play')say('ওস্তাদ, '+L.target.name+' থামান! নামবো!','হেলপার',{obj:P.model.group,y:3.6},PRIO.event,'shout');});}
  else if(td<30){jolt(.8);JR.comfort-=5;toastMsg('শেষ মুহূর্তে! বাস ঝাঁকি দিয়ে থামছে','info');}
  else{popMsg('একটু আগেভাগে…');}}
function alightBus(){const B=JR.bus;if(B.alight)return;B.alight=true;setAction(null);AU.chime();
  say(pickLine('alightHelper'),'হেলপার',{obj:P.model.group,y:3.6},PRIO.event,'shout');JR.hold=.7;later(0.7,()=>{if(GAME.state==='play')nextLeg();});}
function missedStop(){say('নামবেন? এইখানেই নামেন, তাড়াতাড়ি!','হেলপার',{obj:P.model.group,y:3.6},PRIO.urgent,'shout');
  showTiming({title:'চলন্ত বাস থেকে নামো!',text:'সবুজ ঘরে থাকলে চাপো',secs:3.2,zone:.22,fn:q=>{const B=JR.bus;B.alight=true;
    if(q>=.5){toastMsg(q>.85?'নিখুঁত লাফ!':'নেমে পড়লে!','good');if(q>.85){JR.perfect++;GAME.style+=60;}JR.comfort-=4;}
    else{toastMsg('ধপাস! পড়ে গেলে  −৩০ সেকেন্ড','bad');addTime(30);JR.comfort-=14;JR.stumbles++;AU.thud(1);logEv('চলন্ত বাস থেকে পড়ে যাওয়া');}
    nextLeg();}});}
function busRace(){const lay=laneLayout(P.node,P.d,_lay);const x=lay.our[Math.max(0,lay.our.length-2)];if(Math.abs(x-P.x)<1.5)return;
  const v=spawnVehicle('bus',P.node,P.d-14,x,1,P.v+2,{vDes:15,script:(v)=>{v.st.t=(v.st.t||0)+.016;if(v.st.t>14)return null;return{target:Math.max(P.v+.8,8),tx:x};}});
  toastMsg('বাসের রেস! শক্ত করে ধরো!','bad',2400);say(pickLine('busRace'),'হেলপার',{obj:P.model.group,y:3.6},PRIO.urgent,'shout');JR.urgeT=6;AU.horn('bus',.9,-.4);logEv('দুই বাসের রেস');}
function urgeBus(){if(JR.urgeCd>0||!JR.bus)return;JR.urgeT=6;JR.urgeCd=13;say('ওস্তাদ, টান দেন! অফিস লেট!','তুমি',{obj:P.model.group,y:3.2},PRIO.event,'me',1.6);
  later(0.9,()=>{if(GAME.state==='play')say('ধরেন শক্ত কইরা!','বাস ড্রাইভার',{obj:P.model.group,y:3.6},PRIO.event,'shout');});}

/* ---------- standing balance (bus, double-decker, metro) ---------- */
function jolt(k){if(JR.seat||P.mode==='walk'||P.mode==='drive')return;JR.balV+=(CR()<.5?-1:1)*k*2.2;}
function updateBalance(dt,hard){const bar=$('balance');if(JR.seat){bar.className='seated';JR.comfort=Math.min(100,JR.comfort+dt*.6);return;}
  bar.className='';const yaw=wrapA(PW.a-(JR.lastA||PW.a))/Math.max(dt,1e-3);JR.lastA=PW.a;const aLat=P.v*yaw,aLong=(P.v-(JR.lastV||0))/Math.max(dt,1e-3);JR.lastV=P.v;
  const metro=P.mode==='metro',k=metro?.55:1;
  let f=-aLat*.11*k;if(aLong<-1.6)f+=(JR.bal>=0?1:-1)*(-aLong-1.6)*.13*k;
  if(CR()<dt*(.9+P.v*.06)*hard)f+=(CR()-.5)*7*k*hard;   // potholes, crowd pushes
  const ctl=(KEYS.left-KEYS.right);   // lean against it
  if(JR.stun>0){JR.stun-=dt;JR.balV*=Math.exp(-dt*4);JR.bal*=Math.exp(-dt*3);}
  else{JR.balV+=(f+JR.bal*1.15-ctl*2.6-JR.balV*.9)*dt;JR.bal+=JR.balV*dt;}
  JR.sway=JR.bal;
  if(Math.abs(JR.bal)>=1&&JR.stun<=0){JR.stun=1.3;JR.stumbles++;JR.comfort=Math.max(0,JR.comfort-9);AU.thud(.8);GAME.shake=.25;toastMsg(pick(['ধপাস! পাশের লোকের পা মাড়ালে!','ধাক্কা খেয়ে হেলে পড়লে!','ব্যাগ গেল এক দিকে, তুমি আরেক দিকে!'],CR),'bad',1800);
    later(0.25,()=>{if(GAME.state==='play')say(pickLine('stumbled'),'পাশের যাত্রী',{obj:P.model.group,y:3},PRIO.event,'shout');});JR.bal=clamp(JR.bal,-1,1);}
  else if(Math.abs(JR.bal)<.35)JR.comfort=Math.min(100,JR.comfort+dt*.15);
  const nd=$('balNeedle');if(nd)nd.style.transform='translateX('+(clamp(JR.bal,-1,1)*46).toFixed(1)+'%) rotate('+(JR.bal*24).toFixed(1)+'deg)';
  bar.classList.toggle('warn',Math.abs(JR.bal)>.7);}

/* ---------- seat race (mash) ---------- */
function seatRace(kind){if(JR.seat||GAME.state!=='play')return;
  showMash({title:kind==='ddTop'?'উপরতলার সিট! দৌড়াও!':'সিট খালি হলো!',text:'জলদি চাপো, পাশের লোকের আগে বসতে হবে',taps:7,secs:2.3,fn:ok=>{
    if(ok){JR.seat=true;JR.comfort=Math.min(100,JR.comfort+10);GAME.style+=70;toastMsg(kind==='ddTop'?'উপরতলায় জানালার পাশে! রাজার মতো যাত্রা':'বসার সিট পেলে! আর ব্যালান্সের চিন্তা নাই','good',2400);AU.pickup('doa');logEv('সিট দখল');}
    else{toastMsg('মামা আগে বসে গেলেন… দাঁড়িয়েই যাও','info');say(pickLine('seatLost'),'পাশের যাত্রী',{obj:P.model.group,y:3},PRIO.event);}}});}

/* ---------- metro ---------- */
function setupMetro(L){const n=ROUTE.root;JR.metro={phase:'board',v:0,si:0,dwell:0,stations:L.stations.concat([L.B]),doorT:0};
  P.d=L.A.d+14;P.x=-1.8;}
function placeMetro(){const cars=P.model.parts.cars,n=ROUTE.root;for(let i=0;i<cars.length;i++){const d=P.d-i*14.2-7.1;const f=n.path.pos(clamp(d,0,n.dEnd),-1.8,_f2);cars[i].position.set(f.x,9.8,f.z);cars[i].rotation.y=f.a;cars[i].visible=i<3;}
  const f=n.path.pos(P.d-7.1,-1.8,{});PW.x=f.x;PW.y=9.8;PW.z=f.z;PW.a=f.a;P.model.group.position.set(PW.x,PW.y,PW.z);}
function metroGate(){// station: card tap, then the doors
  const SA=JR.legs[1].A;fadeCut(()=>{nextLeg();});}
function metroControl(dt){const M=JR.metro,L=JR.leg;
  if(M.phase==='board'){M.phase='gate';JR.hold=99;later(0.6,()=>cardTap());}
  if(M.phase==='gate'||M.phase==='doors'){placeMetro();return;}
  const st=M.stations[M.si];const stopD=st?st.d+14:L.B.d+14;const dist=stopD-P.d;
  if(M.phase==='run'){const vmax=P.cfg.maxV;let vDes=Math.min(vmax,Math.sqrt(Math.max(0,2*2.6*dist)));if(M.v<vDes)M.v=Math.min(vDes,M.v+P.cfg.acc*dt);else M.v=Math.max(vDes,M.v-3.4*dt);
    P.d+=M.v*dt;P.v=M.v;if(dist<.4&&M.v<.5){M.v=0;P.v=0;M.phase='dwell';M.dwell=1.7;AU.doorChime();
      if(st===L.B||!st){M.phase='final';exitMetro();}else{say('স্টেশন: '+st.name+'। দরজা বাম দিকে খুলবে।','মেট্রো ঘোষণা',{obj:P.model.group,y:4},PRIO.event,'metro');}}
    else if(st&&dist<260&&!st.ann){st.ann=1;const nx=M.stations[M.si];say('পরবর্তী স্টেশন '+nx.name+(nx===L.B?' — তোমার স্টেশন!':''),'মেট্রো ঘোষণা',{obj:P.model.group,y:4},PRIO.event,'metro');}}
  else if(M.phase==='dwell'){M.dwell-=dt;if(M.dwell<=0){M.si++;M.phase='run';AU.doorChime();}}
  placeMetro();
  if(M.phase!=='final')updateBalance(dt,.8);
  if(!JR.seat&&!JR.flags.seat1&&M.phase==='dwell'&&M.si>=1&&R()<.5){JR.flags.seat1=1;later(0.4,()=>seatRace('seat'));}
  setAction(null);}
function cardTap(){if(GAME.state!=='play')return;AU.beep(1);
  showTiming({title:'গেটে কার্ড ট্যাপ করো!',text:'MRT পাস ধরো সবুজ ঘরে',secs:3,zone:.24,ring:true,fn:q=>{
    if(q>=.5){AU.beep(2);if(q>.85){JR.perfect++;GAME.style+=50;popMsg('বিপ! নিখুঁত ট্যাপ +৫০');}
      if(R()<.18&&!JR.flags.balance){JR.flags.balance=1;lowBalance();return;}
      JR.fares+=60;GAME.wallet-=60;platformDoors();}
    else{AU.buzz();toastMsg('"আবার ট্যাপ করুন" · ৫ সেকেন্ড গেল','bad');addTime(5);later(0.5,()=>cardTap());}}});}
function lowBalance(){showChoice({title:'গেট: "অপর্যাপ্ত ব্যালান্স"!',text:'কার্ডে টাকা নাই! কী করবে?',secs:6,opts:[
  {t:'রিচার্জ লাইনে দাঁড়াও',s:'−২ মিনিট',fn:()=>{addTime(120);JR.fares+=160;GAME.wallet-=160;toastMsg('লম্বা লাইন… রিচার্জ হলো','info');platformDoors();}},
  {t:'একক যাত্রার টিকিট',s:'−১ মিনিট, ৳ বেশি',fn:()=>{addTime(60);JR.fares+=90;GAME.wallet-=90;toastMsg('টিকিট কেটে ঢুকে পড়লে','info');platformDoors();}}]});}
function platformDoors(){const M=JR.metro;M.phase='doors';AU.trainHorn();toastMsg('ট্রেন এসে গেছে!','good',1400);
  later(1.1,()=>{if(GAME.state!=='play')return;AU.doorChime();showMash({title:'দরজা বন্ধ হচ্ছে! ঢুকে পড়ো!',text:'জলদি চাপো, ভিড় ঠেলে ঢোকো',taps:6,secs:2.4,fn:ok=>{
    if(ok){toastMsg('ঢুকে পড়লে!','good');GAME.style+=40;}else{toastMsg('দরজা বন্ধ! পরের ট্রেন… ৩ মিনিট গেল','bad',2400);addTime(180);logEv('মেট্রো মিস');}
    M.phase='run';JR.hold=0;AU.doorChime();say(pickLine('metroIn'),'তুমি',{obj:P.model.group,y:4},PRIO.react,'me');}});});}
function exitMetro(){const L=JR.leg;AU.doorChime();
  showMash({title:L.B.name+'! নামো নামো!',text:'"সরেন ভাই, নামবো!" ভিড় ঠেলে দরজা পর্যন্ত যাও',taps:7,secs:2.6,fn:ok=>{
    if(ok){toastMsg('নেমে পড়লে!','good');GAME.style+=50;}else{toastMsg('দরজা বন্ধ হয়ে গেল! পরের স্টেশন থেকে ফিরতি ট্রেন  −২ মিনিট','bad',2600);addTime(120);JR.comfort-=6;logEv('স্টেশন মিস');}
    fadeCut(()=>nextLeg());}});}

/* ---------- walking ---------- */
const WALKOB={list:[],next:0};
function walkControl(dt){const W=JR.walk,L=JR.leg,n=ROUTE.root,h=halfAt(n,P.d),sw=swAt(n,P.d),leg=legAt(n,P.d);
  let tv=3.3;const run=KEYS.up,spr=KEYS.boost;
  if(KEYS.down)tv=0;else if(spr&&W.stam>.03){tv=6.2;W.stam=Math.max(0,W.stam-.22*dt);}else if(run&&W.stam>.03){tv=4.6;W.stam=Math.max(0,W.stam-.06*dt);}else W.stam=Math.min(1,W.stam+.1*dt);
  if(P.surface==='wpuddle')tv=Math.min(tv,1.6);if(P.surface==='mat')tv=Math.min(tv,1.2);
  if(JR.hold>0||P.frozen>0||P.fall>0){tv=0;}
  if(P.fall>0)P.fall-=dt;if(P.frozen>0)P.frozen-=dt;
  P.v+=clamp(tv-P.v,-9*dt,6*dt);P.boost=W.stam;P.boosting=spr&&W.stam>.03&&P.v>3.5;
  const F=n.path.frame(P.d,_f1),k=F.k;P.d+=P.v*dt/Math.max(.3,1+k*P.x);
  P.x+=(KEYS.left?-1:0)*0+(KEYS.right-KEYS.left)*2.4*dt*(P.fall>0?0:1);
  // where can you walk: the left sidewalk, or step down into the road edge
  let lo=-(h+sw)+.35,hi=-h+1.1;if(leg.type==='cross'){lo=-(h+4)+.3;}
  P.x=clamp(P.x,lo,hi);P.h=lerp(P.h,(KEYS.right-KEYS.left)*-.35,Math.min(1,dt*8));
  const onRoad=P.x>-h+.1;
  // obstacles & people on the walk
  updateWalkObs(dt);
  for(const o of WALKOB.list){const ov=Math.abs(o.d-P.d)<o.len/2+.3&&Math.abs(o.x-P.x)<o.w/2+.28;if(o.hitCd>0)o.hitCd-=dt;
    /* only on stepping into it: standing up inside the same hole must not trip you again */
    if(ov&&!o.touch&&o.hitCd<=0){o.hitCd=1.5;walkHit(o);}o.touch=ov;}
  P.surface=null;for(const o of WALKOB.list){if(o.surf&&Math.abs(o.d-P.d)<o.len/2&&Math.abs(o.x-P.x)<o.w/2+.1){P.surface=o.surf;break;}}
  if(onRoad){for(const v of GAME.veh){if(v.dir<0)continue;const rel=v.d-P.d;if(Math.abs(rel)<(v.len)/2+.4&&Math.abs(v.x-P.x)<v.w/2+.35&&v.hitCd<=0){v.hitCd=2;v.stopT=1.5;walkHit({kind:'veh',v});}
      if(rel<0&&rel>-14&&Math.abs(v.x-P.x)<v.w/2+.8&&v.honkCd<=0){v.honkCd=3;hornAt(v);}}}
  // pose
  const m=P.model,rig=m.parts.rig;W.ph+=P.v*dt*3.2;animRig(rig,W.ph,Math.min(.9,P.v*.22),Math.min(1,P.v*.26));
  playerWorld(PW);const y=PW.y+(onRoad?0:.22)+Math.abs(Math.sin(W.ph))*.05*Math.min(1,P.v/2);m.group.position.set(PW.x,y,PW.z);m.group.rotation.y=PW.a;
  m.body.rotation.x=P.fall>0?lerp(m.body.rotation.x,-1.2,Math.min(1,dt*10)):lerp(m.body.rotation.x,-Math.min(.25,P.v*.04),Math.min(1,dt*6));
  if(P.d>=L.d1){if(L.to==='stop')waitForBus();else if(L.to==='dest')arrive();}
  if(P.v<.3&&!KEYS.down&&JR.hold<=0&&P.fall<=0&&P.frozen<=0){W.stuck=(W.stuck||0)+dt;if(W.stuck>3){W.stuck=0;P.x=-(h+sw*.55);}}else W.stuck=0;}
function walkHit(o){const k=o.kind;AU.thud(.6);GAME.shake=.15;
  if(k==='hole'){P.fall=1.6;o.hitCd=99;addTime(40);JR.comfort-=12;JR.stumbles++;toastMsg('খোলা ম্যানহোল! পা ঢুকে গেল  −৪০ সেকেন্ড','bad',2400);sayMe('manhole',PRIO.urgent);logEv('ম্যানহোলে পা');}
  else if(k==='veh'){P.fall=1.1;addTime(25);JR.comfort-=10;JR.stumbles++;sayV(o.v,'hit');toastMsg('রাস্তায় নেমো না! গাড়ির ধাক্কা','bad');}
  else if(k==='mat'){P.frozen=.5;JR.comfort-=4;say(pickLine('hawker'),'হকার',{x:o.wx,z:o.wz,y:2.2},PRIO.event,'shout');}
  else if(k==='dog'){P.frozen=.6;JR.comfort-=5;AU.bark();toastMsg('ঘেউ! কুকুর রাগ করেছে','bad');}
  else if(k==='wpuddle'){FX.splash(PW.x,PW.y+.2,PW.z,8,3);AU.splash(.6);JR.comfort-=3;toastMsg('জুতা ভিজে গেল!','info',1200);o.hitCd=99;}
  else{P.fall=.7;JR.comfort-=6;JR.stumbles++;say(pickLine('pedBump'),o.name||'পথচারী',{x:o.wx,z:o.wz,y:2.3},PRIO.event,'shout');}}
function walkObGeo(kind){return kind==='mat'?T.mat:kind==='hole'?T.hole:kind==='dog'?T.dog:kind==='parked'?T.parkedBike:kind==='wpuddle'?null:kind==='phone'?T.phoneGuy:pick(T.people,CR);}
function updateWalkObs(dt){const n=ROUTE.root,L=JR.leg;
  if(WALKOB.next<P.d+12)WALKOB.next=P.d+12;
  while(WALKOB.next<P.d+70&&WALKOB.next<L.d1-4){const d=WALKOB.next;WALKOB.next+=rr(9,15);const leg=legAt(n,d);if(leg.type==='cross'||leg.type==='jn')continue;
    const h=halfAt(n,d),sw=swAt(n,d),kind=wpick({ped:4,phone:2,mat:2,hole:1.1,parked:1.4,dog:.7,wpuddle:GAME.weather==='rain'?3:1});
    const x=-(h+rr(.5,sw-.5)),o={kind,d,x,w:kind==='mat'?1.3:kind==='parked'?.7:kind==='hole'?.8:kind==='wpuddle'?1.4:.6,len:kind==='mat'?1.5:kind==='parked'?2:kind==='hole'?.8:kind==='wpuddle'?1.8:.5,
      vd:kind==='ped'?-rr(.8,1.3):kind==='phone'?rr(.3,.6):0,hitCd:0,name:kind==='phone'?'ফোনে ব্যস্ত পথচারী':'পথচারী'};
    if(kind==='wpuddle'||kind==='mat')o.surf=kind;
    const g=walkObGeo(kind);if(g){o.m=new THREE.Mesh(g,MATS.col);scene.add(o.m);}else{o.m=new THREE.Mesh(T.plane,MATS.puddle);o.m.scale.set(o.w,1,o.len);scene.add(o.m);}
    if(kind==='ped'||kind==='phone')o.wander=rr(0,6);
    WALKOB.list.push(o);}
  if(WALKOB.coin==null||WALKOB.coin<P.d){WALKOB.coin=P.d+rr(40,70);const d=WALKOB.coin;if(d<L.d1-6){const h=halfAt(n,d),sw=swAt(n,d);spawnPickup(R()<.5?'taka':R()<.6?'tea':'charge',n,d,-(h+rr(.6,sw-.6)),true);}}
  for(const o of WALKOB.list){o.d+=o.vd*dt;if(o.wander!=null){o.wander+=dt;o.x+=Math.sin(o.wander*.9)*.25*dt;const h=halfAt(n,o.d),sw=swAt(n,o.d);o.x=clamp(o.x,-(h+sw)+.3,-h-.2);}
    const f=n.path.pos(o.d,o.x,_f2);o.wx=f.x;o.wz=f.z;o.m.position.set(f.x,f.y+(o.kind==='wpuddle'?.235:o.kind==='hole'?.225:.22),f.z);o.m.rotation.y=f.a+(o.vd<0?0:Math.PI)+(o.kind==='mat'?Math.PI/2:0);
    if(o.kind==='ped'||o.kind==='phone')o.m.position.y+=Math.abs(Math.sin(GAME.t*7+o.d))*.04;
    if(o.d<P.d-12||o.d>P.d+90){scene.remove(o.m);o.dead=true;}}
  WALKOB.list=WALKOB.list.filter(o=>!o.dead);}
function clearWalkObs(){for(const o of WALKOB.list)scene.remove(o.m);WALKOB.list=[];WALKOB.next=0;WALKOB.coin=null;}
/* at the bus stop: the bus comes, slows down… jump on! */
function waitForBus(){const L=JR.leg;if(L.done)return;L.done=true;JR.hold=99;P.v=0;toastMsg('বাস স্টপে পৌঁছে গেলে! বাস আসছে…','info',1800);
  const busL=JR.legs[JR.li+1],dd=busL.type==='dd',n=ROUTE.root,lay=laneLayout(n,busL.d0,_lay),x=lay.our[lay.our.length-1];const bus=spawnVehicle(dd?'dd':'bus',n,busL.d0-70,x,1,8,{vDes:9,script:(v)=>{const dist=busL.d0+3-v.d;
      if(dd){return{target:dist>1?Math.min(9,Math.sqrt(2*1.8*dist)):0,tx:x};}
      return{target:dist>8?Math.min(9,dist*.4+2.5):2.4,tx:x};}});
  JR.boarding={bus,t:0};const t0=GAME.t;
  const watch=()=>{if(GAME.state!=='play')return;const dist=busL.d0+3-bus.d;
    if(GAME.t-t0>7&&dist>25){bus.d=busL.d0-22;bus.v=6;}
    if(dist<(dd?3:12)){if(dd){toastMsg('বিআরটিসি থেমেছে, উঠে পড়ো!','good');removeVeh(bus);nextLeg();}else catchBus(bus);return;}later(0.12,watch);};later(0.4,watch);
  say(pickLine('stopWait'),'তুমি',{obj:P.model.group,y:2.4},PRIO.event,'me');}
function catchBus(bus){say('উঠেন উঠেন! বাস থামবে না, লাফ দেন!','হেলপার',{obj:bus.mesh,y:3.6},PRIO.urgent,'shout');
  showTiming({title:'চলন্ত বাসে ওঠো!',text:'দরজা সামনে এলে চাপো (সবুজ ঘর)',secs:3,zone:.26,fn:q=>{
    if(q>=.5){if(q>.85){JR.perfect++;GAME.style+=70;popMsg('নিখুঁত লাফ! +৭০');}removeVeh(bus);GAME.veh=GAME.veh.filter(v=>!v.dead);nextLeg();}
    else{toastMsg('মিস! বাস চলে গেল… পরের বাসের অপেক্ষা','bad',2200);AU.horn('bus',.8,0);bus.script=()=>({target:12});bus.vDes=12;addTime(90);logEv('বাস মিস');
      later(1.6,()=>{if(GAME.state==='play')waitForBusEasy();});}}});}
function waitForBusEasy(){const L=JR.leg;L.done=true;const busL=JR.legs[JR.li+1],n=ROUTE.root,lay=laneLayout(n,busL.d0,_lay),x=lay.our[lay.our.length-1];
  const bus=spawnVehicle('bus',n,busL.d0-60,x,1,8,{vDes:9,script:(v)=>{const dist=busL.d0+3-v.d;return{target:dist>1?Math.min(9,Math.sqrt(2*1.8*dist)):0,tx:x};}});
  const t0=GAME.t;const watch=()=>{if(GAME.state!=='play')return;
    if(GAME.t-t0>7&&busL.d0+3-bus.d>25){bus.d=busL.d0-20;bus.v=5;}
    if(busL.d0+3-bus.d<3){toastMsg('এইবার বাস থামলো! উঠে পড়ো','good');removeVeh(bus);nextLeg();return;}later(0.12,watch);};later(0.4,watch);}

/* ---------- car parking at the office ---------- */
function carParking(dt){const B=ROUTE.bay;if(!B||JR.parked)return;const mid=(B.x0+B.x1)/2;
  if(P.d>B.d0-30&&!JR.flags.parkHint){JR.flags.parkHint=1;toastMsg('বাম দিকে P বে-তে গাড়ি থামাও!','info',2400);}
  const inBay=P.d>B.d0+1.6&&P.d<B.d1-1.6&&Math.abs(P.x-mid)<.95;
  if(inBay&&Math.abs(P.v)<.6){JR.parkT=(JR.parkT||0)+dt;if(JR.parkT>.5){const q=1-Math.min(1,Math.abs(P.x-mid)/.75*.5+Math.abs(P.h)*1.5);JR.parked={q};
      if(q>.75){JR.perfect++;GAME.style+=120;popMsg('নিখুঁত পার্কিং! +১২০');}else popMsg('পার্ক করা হলো');arrive();}}
  else JR.parkT=0;
  if((P.d>B.d1+4||Math.abs(P.d-(B.d0+B.d1)/2)<10)&&Math.abs(P.v)<.4&&!inBay){JR.overT=(JR.overT||0)+dt;if(JR.overT>2.2){JR.parked={q:0};toastMsg('থাক, এখানেই রাখি!','info');arrive();}}else JR.overT=0;}

/* ---------- per-frame journey update ---------- */
function updateJourney(dt){if(!JR.leg)return;if(JR.hold>0&&JR.hold<50)JR.hold-=dt;const t=JR.leg.type;
  if(P.mode==='walk')walkControl(dt);
  else if(P.mode==='ride'){rideControl(dt);updatePlayer(dt);if(t==='cng'&&P.d>JR.leg.d0+(JR.leg.d1-JR.leg.d0)*.42&&!JR.flags.short)cngShortcut();
}
  else if(P.mode==='stand'){busControl(dt);updatePlayer(dt);}
  else if(P.mode==='metro'){metroControl(dt);}
  else{updatePlayer(dt);if(t==='car')carParking(dt);else if(P.d>=ROUTE.root.officeD-3&&GAME.state==='play')arrive();}
  // jam meter: time stuck crawling (game seconds)
  if(P.mode!=='walk'&&P.mode!=='metro'&&Math.abs(P.v)<2&&JR.hold<=0&&!(JR.bus&&JR.bus.dwell>0))JR.jamT+=dt*GAME.ts;}

/* ---------- mini-game overlays ---------- */
function showChoice(o){closeQte();const q={kind:'choice',o,t:0,secs:o.secs||6};JR.qte=q;const el=$('qte');el.className='choice';$('qteT').textContent=o.title;$('qteS').textContent=o.text||'';
  const box=$('qteOpts');box.innerHTML='';o.opts.forEach((op,i)=>{const b=document.createElement('button');b.type='button';b.innerHTML='<kbd>'+(i+1)+'</kbd>'+esc(op.t)+(op.s?'<small>'+esc(op.s)+'</small>':'');
    b.addEventListener('click',()=>pickChoice(i));box.appendChild(b);});
  $('qteMeter').hidden=true;$('qteBig').hidden=true;el.hidden=false;AU.chime();}
function pickChoice(i){const q=JR.qte;if(!q||q.kind!=='choice')return;closeQte();AU.click();q.o.opts[i].fn();}
function showMash(o){closeQte();const q={kind:'mash',o,t:0,secs:o.secs,n:0};JR.qte=q;const el=$('qte');el.className='mash';$('qteT').textContent=o.title;$('qteS').textContent=o.text||'';
  $('qteOpts').innerHTML='';$('qteMeter').hidden=false;$('qteBig').hidden=false;$('qteBig').textContent=TOUCH.on?'চাপো! চাপো!':'Space চাপো!';$('qteFill').style.width='0%';$('qteZone').hidden=true;$('qteMark').hidden=true;el.hidden=false;AU.chime();}
function showTiming(o){closeQte();const q={kind:'timing',o,t:0,secs:o.secs,zc:.5+rr(-.18,.18,CR),zw:o.zone||.24,pos:0,dir:1,speed:1.25};JR.qte=q;const el=$('qte');el.className='timing'+(o.ring?' ring':'');
  $('qteT').textContent=o.title;$('qteS').textContent=o.text||'';$('qteOpts').innerHTML='';$('qteMeter').hidden=false;$('qteBig').hidden=false;$('qteBig').textContent=TOUCH.on?'এখন চাপো':'Space';
  $('qteFill').style.width='0%';const z=$('qteZone');z.hidden=false;z.style.left=((q.zc-q.zw/2)*100).toFixed(1)+'%';z.style.width=(q.zw*100).toFixed(1)+'%';$('qteMark').hidden=false;el.hidden=false;AU.chime();}
function qteAction(){const q=JR.qte;if(!q)return false;
  if(q.kind==='mash'){q.n++;AU.tick();$('qteFill').style.width=Math.min(100,q.n/q.o.taps*100).toFixed(0)+'%';const b=$('qteBig');b.classList.remove('pop');void b.offsetWidth;b.classList.add('pop');
    if(q.n>=q.o.taps){closeQte();AU.pickup('tea');q.o.fn(true);}return true;}
  if(q.kind==='timing'){const off=Math.abs(q.pos-q.zc),inZ=off<=q.zw/2,qual=inZ?1-off/(q.zw/2)*.5:Math.max(0,.45-(off-q.zw/2)*2);closeQte();q.o.fn(qual);return true;}
  return false;}
function updateQte(dt){const q=JR.qte;if(!q)return;q.t+=dt;const left=clamp(1-q.t/q.secs,0,1);$('qteBar').style.transform='scaleX('+left.toFixed(3)+')';
  if(q.kind==='timing'){q.pos+=q.dir*q.speed*dt;if(q.pos>1){q.pos=1;q.dir=-1;}if(q.pos<0){q.pos=0;q.dir=1;}$('qteMark').style.left=(q.pos*100).toFixed(1)+'%';}
  if(q.t>=q.secs){closeQte();if(q.kind==='choice')q.o.opts[0].fn();else if(q.kind==='mash')q.o.fn(false);else q.o.fn(0);}}
function closeQte(){JR.qte=null;$('qte').hidden=true;}
function fadeCut(fn){const f=$('fade');f.classList.add('on');JR.clockHold=Math.max(JR.clockHold,.7);later(0.38,()=>{try{fn();}finally{setTimeout(()=>f.classList.remove('on'),120);}});}
function setAction(kind){const b=$('actB');if(kind===JR.act)return;JR.act=kind;
  if(!kind){b.hidden=true;return;}b.hidden=false;b.dataset.k=kind;
  b.innerHTML=kind==='knock'?'<b>ওস্তাদ, নামবো!</b><small>'+(TOUCH.on?'চাপো':'E চাপো')+' · জানালায় থাবা</small>':'';}
function doAction(){if(qteAction())return;if(JR.act==='knock')knock();}
