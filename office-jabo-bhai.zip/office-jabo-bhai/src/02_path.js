/* ============================================================
   02 PATH + TRIP ROUTE
   One linear route per morning: a home lane → turn onto the MRT
   Line-6 corridor (real OSM data, sliced between two stations and
   scaled) → turn into the office / campus street.
   Everything moves in path space (d along the road, x lateral;
   x<0 = left, our side — Bangladesh drives on the left).
   ============================================================ */
const MAIN_EVENTS={busStop:4,police:2,cow:1,wedding:1,construction:2,phoneWalker:2,clearRoad:2,bikeSqueeze:2,cngClaim:3,cngWrongWay:2,diversion:2,flood:1};
const LEGS={
  res:{name:'আবাসিক এলাকা',half:5.6,div:0,lanes:1,sw:4.2,vmax:10,density:1.3,
    mix:{rickshaw:38,tesla:12,bike:18,cng:14,car:14,van:4},
    events:{rickshawCut:4,cow:3,wedding:2,construction:2,vendorCart:2,phoneWalker:3,teaCrowd:2,clearRoad:1,bikeSqueeze:2,cricket:3,ducks:2,flood:1,truckUnload:2}},
  market:{name:'বাজারের রাস্তা',half:6.6,div:0,lanes:1,sw:4.2,vmax:8,density:1.9,
    mix:{rickshaw:34,tesla:14,cng:18,bike:18,van:12,car:4},
    events:{rickshawCut:4,police:1,cow:2,wedding:1,construction:1,vendorCart:4,phoneWalker:3,teaCrowd:2,clearRoad:1,bikeSqueeze:2,cngClaim:2,truckUnload:3,flood:1,rickshawStraight:2}},
  main:{name:'মেইন রোড',half:11,div:1,lanes:3,sw:4.6,vmax:16,density:2.9,dress:['main'],
    mix:{bus:28,cng:18,car:22,bike:16,van:8,truck:4,tesla:4},events:MAIN_EVENTS},
  mainRes:{name:'মেইন রোড',half:11,div:1,lanes:3,sw:4.6,vmax:16,density:2.7,kind:'res',dress:['main','res'],
    mix:{bus:26,cng:18,car:20,bike:16,rickshaw:8,tesla:8,van:4},events:MAIN_EVENTS},
  mainMarket:{name:'মেইন রোড',half:11,div:1,lanes:3,sw:4.6,vmax:15,density:3.1,kind:'market',dress:['main','market'],
    mix:{bus:28,cng:20,car:16,bike:16,rickshaw:6,tesla:8,van:6},events:Object.assign({},MAIN_EVENTS,{vendorCart:2})},
  mainOffice:{name:'মেইন রোড',half:11,div:1,lanes:3,sw:4.6,vmax:16,density:2.7,kind:'office',dress:['main'],
    mix:{bus:24,cng:18,car:30,bike:18,van:6,tesla:4},events:MAIN_EVENTS},
  office:{name:'অফিসপাড়া',half:9,div:1,lanes:2,sw:4.6,vmax:13,density:1.6,
    mix:{car:40,cng:20,bus:10,bike:20,rickshaw:10},
    events:{police:1,construction:1,phoneWalker:2,clearRoad:1,cngClaim:2}},
  campus:{name:'ক্যাম্পাস',half:7,div:0,lanes:1,sw:4.6,vmax:10,density:1.2,kind:'campus',
    mix:{rickshaw:50,bike:20,car:15,cng:10,tesla:5},
    events:{rickshawCut:3,phoneWalker:3,teaCrowd:3,cricket:1,vendorCart:2}},
  jn:{name:'',half:6,div:0,lanes:1,sw:4.2,vmax:10,density:1,mix:{car:1},events:{}},
  cross:{name:'',half:11,div:1,lanes:3,sw:4.6,vmax:16,density:2.3,mix:{car:1},events:{}},
};
/* where you live, where you go */
const HOMES={
  uttara:{name:'উত্তরা',st:'Uttara Center',lane:'উত্তরা ১৩ নম্বর সেক্টর'},
  pallabi:{name:'পল্লবী',st:'Pallabi',lane:'পল্লবীর আবাসিক গলি'},
  mirpur10:{name:'মিরপুর ১০',st:'Mirpur 10',lane:'মিরপুর ১০-এর আবাসিক গলি'},
  agargaon:{name:'আগারগাঁও',st:'Agargaon',lane:'তালতলার গলি'}};
const DESTS={
  kawran:{name:'কারওয়ান বাজার',st:'Karwan Bazar',track:'office',leg:'office',lane:'কারওয়ান বাজারের অফিসপাড়া',bld:'সময়মতো গ্রুপ লিমিটেড'},
  motijheel:{name:'মতিঝিল',st:'Motijheel',track:'office',leg:'office',lane:'দিলকুশা বাণিজ্যিক এলাকা',bld:'সময়মতো গ্রুপ লিমিটেড'},
  du:{name:'ঢাকা বিশ্ববিদ্যালয়',st:'Dhaka University',track:'varsity',leg:'campus',lane:'কলাভবনের রাস্তা',bld:'কলা ভবন'}};
function destsFor(track){return Object.keys(DESTS).filter(k=>DESTS[k].track===track);}

/* ---------- Path ---------- */
class Path{
  constructor(pieces){this.pieces=pieces;const l=pieces[pieces.length-1];this.len=l.d0+l.len;this._i=0;}
  piece(d){const P=this.pieces;let i=this._i;if(i>=P.length)i=P.length-1;
    if(d>=P[i].d0&&d<P[i].d0+P[i].len)return P[i];
    let lo=0,hi=P.length-1;while(lo<hi){const m=(lo+hi+1)>>1;if(P[m].d0<=d)lo=m;else hi=m-1;}this._i=lo;return P[lo];}
  frame(d,o){const p=this.piece(d);let s=d-p.d0;o=o||{};
    if(s<0||s>p.len||p.kind==='line'){const sa=Math.sin(p.a0),ca=Math.cos(p.a0);
      if(p.kind==='line'||s<0){o.x=p.x0-sa*s;o.z=p.z0-ca*s;o.a=p.a0;o.k=0;}
      else{const ea=p.a0+p.sg*p.len/p.R;const t=s-p.len;o.x=p.ex-Math.sin(ea)*t;o.z=p.ez-Math.cos(ea)*t;o.a=ea;o.k=0;}
      const ss=clamp(s,0,p.len);o.y=p.y0+(p.y1-p.y0)*smooth(ss/p.len);return o;}
    const a=p.a0+p.sg*s/p.R;o.x=p.cx+Math.cos(a)*p.R*p.sg;o.z=p.cz-Math.sin(a)*p.R*p.sg;o.a=a;o.k=p.sg/p.R;
    o.y=p.y0+(p.y1-p.y0)*smooth(s/p.len);return o;}
  pos(d,x,o){o=this.frame(d,o);o.x+=Math.cos(o.a)*x;o.z-=Math.sin(o.a)*x;return o;}
}
function penLine(ps,pen,len,y1){const p={kind:'line',d0:pen.d,len,x0:pen.x,z0:pen.z,a0:pen.a,y0:pen.y,y1:y1==null?pen.y:y1,sg:0,R:0};ps.push(p);
  pen.x-=Math.sin(pen.a)*len;pen.z-=Math.cos(pen.a)*len;pen.d+=len;pen.y=p.y1;return p;}
function penArc(ps,pen,R,ang,sg){const len=R*ang;
  const cx=pen.x-Math.cos(pen.a)*R*sg,cz=pen.z+Math.sin(pen.a)*R*sg;
  const p={kind:'arc',d0:pen.d,len,x0:pen.x,z0:pen.z,a0:pen.a,y0:pen.y,y1:pen.y,sg,R,cx,cz};
  const ea=pen.a+sg*ang;p.ex=cx+Math.cos(ea)*R*sg;p.ez=cz-Math.sin(ea)*R*sg;ps.push(p);
  pen.x=p.ex;pen.z=p.ez;pen.a=ea;pen.d+=len;return p;}

/* ---------- route builder ---------- */
const ROUTE={nodes:[],root:null,seed:1,rg:null,trip:null,mainStart:0,mainEnd:0};
let NODEID=0;
function newCtx(){return{ps:[],legs:[],juncs:[],stations:[],pen:{x:0,z:0,a:0,y:0,d:0},curve:null};}
function prevHalf(c){for(let i=c.legs.length-1;i>=0;i--){const L=c.legs[i];if(L.type!=='jn'&&L.type!=='cross')return L.half;}return 6;}
function addLeg(c,type,len,o){o=o||{};const cfg=LEGS[type],d0=c.pen.d,rg=ROUTE.rg,rnd=(a,b)=>a+(b-a)*rg();
  if(c.curve){const cv=c.curve;c.curve=null;const ang=Math.min(Math.abs(cv),.9),R=clamp(len*.8/Math.max(ang,.05),40,150);penArc(c.ps,c.pen,R,ang,cv>0?1:-1);}
  if(o.curvy&&len>90){let left=len,sg=rg()<.5?1:-1;
    while(left>0){const st=Math.min(left,rnd(35,80));penLine(c.ps,c.pen,st);left-=st;if(left<=40)continue;
      const R=rnd(o.curvy[0],o.curvy[1]),ang=Math.min(rnd(.18,.42),(left-10)/R);penArc(c.ps,c.pen,R,ang,sg);left-=R*ang;sg=-sg;}}
  else penLine(c.ps,c.pen,len);
  const L=Object.assign({},cfg,{type,d0,d1:c.pen.d,metro:!!o.metro,road:o.road||'',real:o.real||null});c.legs.push(L);return L;}
function addTurn(c,sg,nextType,o){o=o||{};const hIn=prevHalf(c),hOut=LEGS[nextType].half,hj=Math.max(hIn,hOut),R=hj+9;
  const E=Object.assign({},c.pen),d0=c.pen.d;const prev=c.legs[c.legs.length-1];const metro=o.noMetro?false:!!(prev&&prev.metro);penArc(c.ps,c.pen,R,Math.PI/2,sg);
  const L=Object.assign({},LEGS.jn,{type:'jn',half:hj,d0,d1:c.pen.d,sw:Math.min(LEGS[nextType].sw||3,4.2)||3,metro});c.legs.push(L);
  c.juncs.push({kind:'turn',d0,d1:c.pen.d,sg,R,hIn,hOut,hj,E,inType:c.legs[c.legs.length-2].type,outType:nextType,deckIn:!!(prev&&prev.metro)&&!metro,deckOut:!!o.deckOut});return L;}
function addCross(c){const h=prevHalf(c),hc=6.5,sw=4.2,len=2*(hc+sw),d0=c.pen.d;const prev=c.legs[c.legs.length-1];penLine(c.ps,c.pen,len);
  const L=Object.assign({},LEGS.cross,{type:'cross',half:h,d0,d1:c.pen.d,hc,csw:sw,metro:prev&&prev.metro,road:prev&&prev.road,lanes:prev?prev.lanes:3});c.legs.push(L);
  c.juncs.push({kind:'cross',d0,d1:c.pen.d,c:(d0+c.pen.d)/2,hc,h,sw,E:Object.assign({},c.pen,{d:d0})});return L;}
function mkNode(c,label){const n={id:NODEID++,parent:null,children:[],dStart:0,dEnd:c.pen.d,ps:c.ps,legs:c.legs,juncs:c.juncs,stations:c.stations,pen:Object.assign({},c.pen),
    path:new Path(c.ps),label,depth:0,stops:[]};
  ROUTE.nodes.push(n);n.poly=[];const f={};for(let d=0;d<=n.dEnd+.01;d+=6){n.path.frame(d,f);n.poly.push(f.x,f.z);}return n;}

/* ---------- the real corridor (Uttara → Motijheel along MRT-6) ---------- */
const FLAVOR_TYPE={res:'mainRes',market:'mainMarket',office:'mainOffice',main:'main'};
function opType(o){if(o.hw==='tertiary'||o.hw==='tertiary_link')return o.flavor==='market'?'market':'res';return FLAVOR_TYPE[o.flavor]||'main';}
function nextLegType(ops,i){for(let k=i+1;k<ops.length;k++)if(ops[k].op==='leg')return opType(ops[k]);return 'main';}
function corridorOps(){return[...DHAKA.spec.s0,...DHAKA.spec.s1,...DHAKA.spec.s2a];}
function opsTotal(ops){let t=0;for(const o of ops)if(o.op==='leg')t+=o.len;return t;}
function stationXY(en){const s=DHAKA.stations.find(s=>s[1]===en);return s?[s[2],s[3]]:[0,0];}
function specPos(ops,sx,sy){let best=null,acc=0;for(const o of ops){if(o.op!=='leg')continue;const[ax,ay,bx,by]=o.real,dx=bx-ax,dy=by-ay,l2=dx*dx+dy*dy||1;
    const t=clamp(((sx-ax)*dx+(sy-ay)*dy)/l2,0,1),dist=Math.hypot(ax+dx*t-sx,ay+dy*t-sy);if(!best||dist<best.dist)best={dist,at:acc+o.len*t};acc+=o.len;}
  return best?best.at:0;}
function sliceOps(ops,a,b){const out=[];let acc=0;
  for(const o of ops){if(o.op!=='leg'){if(acc>a+2&&acc<b-2)out.push(o);continue;}
    const s=acc,e=acc+o.len;acc=e;const lo=Math.max(a,s),hi=Math.min(b,e);if(hi-lo<1)continue;
    const t0=(lo-s)/o.len,t1=(hi-s)/o.len,[ax,ay,bx,by]=o.real;
    out.push(Object.assign({},o,{len:hi-lo,real:[ax+(bx-ax)*t0,ay+(by-ay)*t0,ax+(bx-ax)*t1,ay+(by-ay)*t1]}));}
  while(out.length&&out[0].op!=='leg')out.shift();while(out.length&&out[out.length-1].op!=='leg')out.pop();return out;}
function opsToLegs(c,ops,k){let i=0;
  while(i<ops.length){const o=ops[i];
    if(o.op==='leg'){const type=opType(o);let len=Math.max(40,o.len*k);
      if(type.startsWith('main')&&len>330){const n=Math.floor(len/300),seg=(len-n*21.4)/(n+1);
        for(let q=0;q<=n;q++){addLeg(c,type,Math.max(60,seg),{metro:o.metro,road:o.name,real:o.real});if(q<n)addCross(c);}}
      else addLeg(c,type,len,{metro:o.metro,road:o.name,real:o.real});}
    else if(o.op==='curve'){c.curve=o.ang;}
    else if(o.op==='turn'){addTurn(c,o.sg,nextLegType(ops,i));}
    i++;}}
function placeStations(c){// project real stations onto legs that carry real coordinates
  for(const [bnm,en,sx,sy] of DHAKA.stations){let best=null;
    for(const L of c.legs){if(!L.real)continue;const[ax,ay,bx,by]=L.real,dx=bx-ax,dy=by-ay,l2=dx*dx+dy*dy;if(l2<1)continue;
      const t=clamp(((sx-ax)*dx+(sy-ay)*dy)/l2,0,1),px=ax+dx*t,py=ay+dy*t,dist=Math.hypot(px-sx,py-sy);
      if(dist<230&&(!best||dist<best.dist))best={dist,L,t};}
    if(best&&!c.stations.some(s=>s.en===en)){const L=best.L,d=L.d0+(L.d1-L.d0)*clamp(best.t,.1,.9);c.stations.push({name:bnm,en,d,metro:L.metro});}}
  c.stations.sort((a,b)=>a.d-b.d);
  // keep stations apart and away from junctions
  for(const s of c.stations){for(const j of c.juncs){const lo=j.kind==='cross'?j.d0-20:j.d0-20,hi=j.d1+20;if(s.d>lo&&s.d<hi)s.d=(s.d-lo<hi-s.d)?lo:hi;}}
  for(let i=1;i<c.stations.length;i++)if(c.stations[i].d-c.stations[i-1].d<45)c.stations[i].d=c.stations[i-1].d+45;}
function buildTrip(seed,hk,dk){NODEID=0;ROUTE.nodes=[];ROUTE.seed=seed;ROUTE.rg=mulberry32(seed^0x5bd1e995);const rg=ROUTE.rg;
  const H=HOMES[hk]||HOMES.mirpur10,D=DESTS[dk]||DESTS.kawran,ops=corridorOps(),tot=opsTotal(ops);
  const pa=specPos(ops,...stationXY(H.st)),pb=specPos(ops,...stationXY(D.st));
  const a=Math.max(0,pa-50),b=Math.min(tot,pb+50),raw=Math.max(200,b-a),target=clamp(raw*.6,1080,1450),k=target/raw;
  const sl=sliceOps(ops,a,b);
  const c=newCtx();
  addLeg(c,'res',rr(185,205,rg),{curvy:[70,120],road:H.lane});
  const first=sl.find(o=>o.op==='leg');addTurn(c,1,opType(first),{deckOut:true});
  const ms=c.pen.d;opsToLegs(c,sl,k);
  const last=c.legs[c.legs.length-1];
  if(pb+50>tot)addLeg(c,last.type==='cross'?'mainOffice':last.type,70,{metro:true,road:last.road,real:last.real?[last.real[2],last.real[3],last.real[2]+(last.real[2]-last.real[0])*.05,last.real[3]+(last.real[3]-last.real[1])*.05]:null});
  const me=c.pen.d;
  addTurn(c,1,D.leg,{noMetro:true});addLeg(c,D.leg,125,{road:D.lane});
  placeStations(c);
  const n=mkNode(c,'root');n.office=true;n.officeD=n.dEnd-50;ROUTE.root=n;
  ROUTE.mainStart=ms;ROUTE.mainEnd=me;ROUTE.trip={home:hk,dest:dk,H,D,len:n.officeD};
  placeStops(n);return n;}
/* bus stops along the corridor (every ~210 m, first right after the home turn, last right before the office turn) */
function placeStops(n){const ms=ROUTE.mainStart,me=ROUTE.mainEnd,out=[];
  const ok=d=>{if(d<ms+28||d>me-26)return false;const l=legAt(n,d);if(!l.type.startsWith('main'))return false;
    for(const j of n.juncs){if(d>j.d0-26&&d<j.d1+26)return false;}return true;};
  const want=[ms+34];for(let d=ms+34+200;d<me-130;d+=200)want.push(d);want.push(me-30);
  for(const w of want){let d=w,k=0;while(!ok(d)&&k<40){k++;d=w+(k%2?1:-1)*Math.ceil(k/2)*4;}
    if(ok(d)&&!out.some(s=>Math.abs(s.d-d)<90))out.push({d});}
  out.sort((a,b)=>a.d-b.d);
  out.forEach((s,i)=>{s.id=i;let best=null;for(const st of n.stations)if(!best||Math.abs(st.d-s.d)<Math.abs(best.d-s.d))best=st;
    s.name=best&&Math.abs(best.d-s.d)<160?best.name:(legAt(n,s.d).road||'বাস স্টপ');});
  n.stops=out;}

/* ---------- queries ---------- */
function legAt(n,d){const L=n.legs;for(let i=L.length-1;i>=0;i--){if(d>=L[i].d0)return L[i];}return L[0];}
function legIdx(n,d){const L=n.legs;for(let i=L.length-1;i>=0;i--)if(d>=L[i].d0)return i;return 0;}
const TAPER=22;
function halfAt(n,d){const L=n.legs,i=legIdx(n,d),l=L[i];if(l.type==='jn'||l.type==='cross')return l.half;
  let h=l.half;const prev=L[i-1],next=L[i+1];
  if(prev&&d<l.d0+TAPER){const B=(prev.type==='jn'||prev.type==='cross')?Math.max(prev.half,l.half):(prev.half+l.half)/2;h=lerp(B,l.half,smooth((d-l.d0)/TAPER));}
  if(next&&d>l.d1-TAPER){const B=(next.type==='jn'||next.type==='cross')?Math.max(next.half,l.half):(next.half+l.half)/2;h=lerp(B,h,smooth((l.d1-d)/TAPER));}
  return h;}
function swAt(n,d){const l=legAt(n,d);return l.sw||3;}
function nearJunc(n,d,pad){for(const j of n.juncs){if(d>j.d0-pad&&d<j.d1+pad)return j;}return null;}
function isDivided(n,d){const l=legAt(n,d);if(!l.div)return false;
  for(const j of n.juncs){if(j.kind==='cross'){if(d>j.c-j.hc-1&&d<j.c+j.hc+1)return false;}else if(d>j.d0-14&&d<j.d1+30)return false;}
  return true;}
function innerOf(l){return l.metro?1.8:1.1;}
function divHalf(l){return l.metro?1.25:.5;}
function laneLayout(n,d,o){o=o||{};const l=legAt(n,d),h=halfAt(n,d);o.half=h;o.leg=l;o.div=isDivided(n,d);o.inner=innerOf(l);
  o.our=o.our||[];o.onc=o.onc||[];o.our.length=0;o.onc.length=0;
  if(!o.div){const lanes=l.half>=9||l.type==='cross'?2:1;if(lanes===1){o.our.push(-h/2);o.onc.push(h/2);}else{o.our.push(-h*.7,-h*.28);o.onc.push(h*.7,h*.28);}}
  else{const inner=o.inner,nl=l.lanes,lw=(h-inner-.5)/nl;for(let i=0;i<nl;i++){const c=inner+(i+.5)*lw;o.our.push(-c);o.onc.push(c);}}
  return o;}
function nearestLane(arr,x){let b=0,bd=1e9;for(let i=0;i<arr.length;i++){const dd=Math.abs(arr[i]-x);if(dd<bd){bd=dd;b=i;}}return b;}
function nodeAt(n){return n;}
function related(){return true;}
function remainingLen(n,d){return Math.max(0,n.officeD-d);}
/* real-map position of a point on the route */
function realPos(n,d){const L=n.legs;let i=legIdx(n,d);const l=L[i];
  if(l.real){const t=clamp((d-l.d0)/Math.max(1,l.d1-l.d0),0,1);return[l.real[0]+(l.real[2]-l.real[0])*t,l.real[1]+(l.real[3]-l.real[1])*t];}
  let a=null,b=null,da=0,db=0;for(let k=i;k>=0;k--)if(L[k].real){a=L[k];da=L[k].d1;break;}for(let k=i;k<L.length;k++)if(L[k].real){b=L[k];db=L[k].d0;break;}
  if(a&&b){const t=clamp((d-da)/Math.max(1,db-da),0,1);return[a.real[2]+(b.real[0]-a.real[2])*t,a.real[3]+(b.real[1]-a.real[3])*t];}
  if(a)return[a.real[2],a.real[3]];if(b)return[b.real[0],b.real[1]];return null;}
function nextStation(n,d){for(const s of n.stations||[])if(s.d>d)return s;return null;}
function nextStop(n,d){for(const s of n.stops||[])if(s.d>d)return s;return null;}
