/* ============================================================
   09 EVENTS, SIGNALS, INCIDENTS, POLICE CHASE, BOSS CALLS
   ============================================================ */
const EV={next:120,active:[],recent:[],ambT:5,calls:{}};
function evSpot(dist){const d=P.d+dist,n=nodeAt(P.node,d);if(d>=n.dEnd-25||d<n.dStart+10)return null;const leg=legAt(n,d);
  if(leg.type==='jn'||leg.type==='cross'||pSkip(n,d)||nearJunc(n,d,22))return null;if(n.office&&d>n.officeD-60)return null;return{n,d,leg,lay:laneLayout(n,d,{})};}
function pLaneX(lay){return lay.our[nearestLane(lay.our,Math.min(P.x,-.5))];}
function laneW(lay){return lay.div?(lay.half-1.6)/lay.our.length:lay.half;}
function evDist(){return clamp(55+P.v*3.2,60,130);}
const EVENTS={
 busStop(){const s=evSpot(evDist()+15);if(!s||!s.lay.div)return false;const li=nearestLane(s.lay.our,P.x),x=s.lay.our[li];
  GAME.veh.forEach(v=>{if(v.dir>0&&related(v.node,s.n)&&Math.abs(v.d-s.d)<14&&Math.abs(v.x-x)<2.5)removeVeh(v);});GAME.veh=GAME.veh.filter(v=>!v.dead);
  spawnVehicle('bus',s.n,s.d,x,1,7,{li,vDes:8.5,script:(v,dt)=>{v.st.t=(v.st.t||0)+dt;const rel=v.d-P.d;if(!v.st.said&&rel<75){v.st.said=1;sayV(v,'helper');AU.horn('bus',.8,0);}
    if(v.st.said&&!v.st.stop&&rel<45){v.st.stop=1;v.st.t0=v.st.t;toastMsg('বাস হঠাৎ থেমে গেল! যাত্রী উঠছে','info');
      const h=halfAt(v.node,v.d);for(let k=0;k<3;k++)spawnCrosser(pick(T.people,CR),v.node,v.d-3.5+k*.5,-(h+1.5+k*.8),1.2,{bounds:v.x-1.6,life:12,noDodge:true});}
    if(v.st.stop&&v.st.t-v.st.t0<6.5)return{target:0,tx:x-.6};if(v.st.stop)v.script=null;return null;}});logEv('বাসের হঠাৎ ব্রেক');return true;},
 rickshawCut(){const s=evSpot(evDist()-5);if(!s)return false;const h=s.lay.half,x0=-h+.9,goal=s.lay.div?s.lay.our[0]:h*.25;
  spawnVehicle('rickshaw',s.n,s.d,x0,1,2.5,{vDes:3.2,script:v=>{if(!v.st.go&&v.d-P.d<40){v.st.go=1;sayV(v,'rickshaw');AU.bell(.9,-.3);}if(v.st.go)return{tx:goal,lat:1.5};return{tx:x0};}});
  logEv('রিকশার হঠাৎ মোড়');return true;},
 rickshawStraight(){const s=evSpot(evDist());if(!s)return false;const x=pLaneX(s.lay);
  spawnVehicle('rickshaw',s.n,s.d,x,1,3,{vDes:3.4,script:v=>{v.st.t=(v.st.t||0)+.016;if(!v.st.s&&v.d-P.d<35){v.st.s=1;say(pickLine('rickshawStraight'),'রিকশাওয়ালা',{obj:v.mesh,y:2.5},PRIO.event);AU.bell(.8,0);}
    return{tx:x+Math.sin(GAME.t*1.3+v.id)*1.6,lat:1.2};}});logEv('রিকশার "সোজা" যাওয়া');return true;},
 police(){const s=evSpot(evDist()+30);if(!s)return false;const px=Math.max(-s.lay.half+.6,pLaneX(s.lay)-1.95);
  const c=spawnCrosser(T.police,s.n,s.d,px,0,{ry:Math.PI,role:'police',name:'ট্রাফিক পুলিশ',stay:true,life:150,w:.6,len:.5,noDodge:true});let st='wait',t=0,said=0,s2=0;
  EV.active.push({update(dt){const rel=c.d-P.d;if(c.dead)return false;
    if(!said&&rel<70){said=1;AU.whistle(.9);sayAt('policeStop',c,'ট্রাফিক পুলিশ','shout',PRIO.urgent);toastMsg('পুলিশ হাত দেখাচ্ছে! থামো','bad');}
    c.m.rotation.z=st==='wait'?Math.sin(GAME.t*6)*.12:0;
    if(st==='wait'){if(rel<17&&rel>-1&&Math.abs(P.v)<2.5){st='check';t=0;P.frozen=3.4;GAME.police++;AU.whistle(.4);sayAt('police',c,'ট্রাফিক পুলিশ','',PRIO.urgent);logEv('পুলিশ চেকিং');}
      else if(rel<-3){st='done';AU.whistle(1);sayAt('policeAngry',c,'ট্রাফিক পুলিশ','shout',PRIO.urgent);addTime(120);GAME.police++;
        toastMsg('পুলিশের সিগন্যাল অমান্য! মামলা  −২ মিনিট','bad');logEv('পুলিশের সিগন্যাল অমান্য');}}
    else if(st==='check'){t+=dt;if(t>1.7&&!s2){s2=1;sayAt('policeOk',c,'ট্রাফিক পুলিশ','',PRIO.urgent);}if(t>3.4){st='done';addTime(60);toastMsg('লাইসেন্স চেক শেষ  −১ মিনিট','info');}}
    return st!=='done';}});return true;},
 cow(){const s=evSpot(evDist()+30);if(!s)return false;const x=rr(-s.lay.half+1.6,s.lay.div?-2.2:s.lay.half*.25);
  const c=spawnCrosser(pick(T.cow,CR),s.n,s.d,x,.3,{kind:'cow',w:1.1,len:2.4,ry:0,wander:true,stay:true,life:120,role:'cow',name:'গরু'});GAME.cows++;let said=0;
  EV.active.push({update(){if(c.dead)return false;const rel=c.d-P.d;if(!said&&rel<60){said=1;AU.moo(.8);sayAt('cow',c,'গরু');
      setTimeout(()=>{if(!c.dead&&GAME.state==='play')sayAt('cowSide',{x:c.wx,z:c.wz,y:2.6},'পাশের লোক');},1600);}return true;}});logEv('রাস্তার মাঝে গরু');return true;},
 wedding(){const s=evSpot(evDist()+45);if(!s)return false;const h=s.lay.half,cs=[];
  for(let i=0;i<9;i++){const geo=i===4?T.groom:pick(T.wedding,CR);const c=spawnCrosser(geo,s.n,s.d+rr(-.7,.7),-(h+1)-i*1.15,2.1,{role:'wedding',name:'বরযাত্রী',life:45});
    if(i<2)c.m.add(new THREE.Mesh(T.drum,MATS.col));cs.push(c);}
  let said=0,bt=0;EV.active.push({update(dt){if(!cs.some(c=>!c.dead))return false;const rel=s.d-P.d;
    if(!said&&rel<85){said=1;sayAt('wedding',cs[4],'বরযাত্রী','shout');toastMsg('বিয়ের মিছিল রাস্তা পার হচ্ছে!','info');}
    bt-=dt;if(bt<=0&&rel<140&&rel>-30){bt=.9;AU.drum(clamp(1-Math.abs(rel)/140,0,1));}return true;}});logEv('বিয়ের মিছিলের জ্যাম');return true;},
 construction(){const s=evSpot(evDist()+40);if(!s)return false;const d0=s.d,d1=d0+26,lay=laneLayout(s.n,d0+13,{});if(d1>s.n.dEnd-10)return false;let x0,x1;
  if(lay.div){const li=nearestLane(lay.our,P.x),lw=laneW(lay);x0=lay.our[li]-lw/2+.15;x1=lay.our[li]+lw/2-.15;}else{x0=-lay.half+.2;x1=-lay.half+2.7;}
  const B=new Builder();for(let x=x0+1;x<x1+.2;x+=2.1){B.tmpl(T.barricade,Math.min(x,x1-1),0,-d0,0);B.tmpl(T.barricade,Math.min(x,x1-1),0,-d1,0);}
  for(let dd=d0+2.5;dd<d1-1;dd+=3)B.tmpl(T.barricade,x1-.1,0,-dd,Math.PI/2);B.cone(1.6,1.4,(x0+x1)/2,.7,-(d0+9),'#7a5a3a',8);
  for(let k=0;k<8;k++)B.box(.5,.25,.25,(x0+x1)/2+rr(-.8,.8),.15+k%3*.25,-(d0+17)+rr(-.6,.6),'#b8452a');
  B.tmpl(T.worker,(x0+x1)/2-.4,0,-(d0+12),Math.PI);B.tmpl(T.worker,(x0+x1)/2+.6,0,-(d0+20),.6);B.sign(SIGN_WORK,2.6,.45,(x0+x1)/2,1.45,-(d0-.12),0);
  const g=B.build(pathMapper(s.n.path,false));const cones=[];
  for(let k=0;k<4;k++){const f=s.n.path.pos(d0-3-k*2.5,x1+.4-k*.25,{});const m=new THREE.Mesh(T.cone,MATS.col);m.position.set(f.x,f.y,f.z);g.add(m);cones.push(m);}
  const ob=addObstacle(s.n,d0,d1,x0,x1,[g],'work',{cones});let said=0;
  EV.active.push({update(){if(ob.dead)return false;const rel=d0-P.d;if(rel<-40)return false;if(!said&&rel<70){said=1;const p=s.n.path.pos(d0+12,(x0+x1)/2,{});sayAt('worker',{x:p.x,z:p.z,y:2.5});toastMsg('রাস্তার কাজ চলছে, লেন বন্ধ!','info');}return true;}});
  logEv('খোঁড়াখুঁড়ি');return true;},
 diversion(){const s=evSpot(evDist()+50);if(!s||!s.lay.div||s.lay.our.length<3)return false;const d0=s.d,d1=d0+40;if(d1>s.n.dEnd-15||pSkip(s.n,d1))return false;
  const lay=s.lay,lw=laneW(lay),x0=-lay.half+.3,x1=lay.our[1]+lw/2-.1;
  const B=new Builder();for(let x=x0+1;x<x1;x+=2.1)B.tmpl(T.barricade,Math.min(x,x1-1),0,-d0,0);for(let dd=d0+3;dd<d1;dd+=3)B.tmpl(T.barricade,x1-.1,0,-dd,Math.PI/2);
  B.sign(SIGN_CLOSED,4,.6,(x0+x1)/2,1.5,-(d0-.12),0);B.tmpl(T.police,x1+.2,0,-(d0-2),Math.PI);
  const g=B.build(pathMapper(s.n.path,false));const cones=[];for(let k=0;k<5;k++){const f=s.n.path.pos(d0-4-k*3,x1-k*.9,{});const m=new THREE.Mesh(T.cone,MATS.col);m.position.set(f.x,f.y,f.z);g.add(m);cones.push(m);}
  const ob=addObstacle(s.n,d0,d1,x0,x1,[g],'work',{cones});let said=0;
  EV.active.push({update(){if(ob.dead)return false;const rel=d0-P.d;if(rel<-50)return false;if(!said&&rel<90){said=1;AU.whistle(.6);const p=s.n.path.pos(d0-2,x1,{});sayAt('divert',{x:p.x,z:p.z,y:2.6},'ট্রাফিক পুলিশ','',PRIO.event);toastMsg('ডাইভারশন! ডানের লেনে যাও','bad');}return true;}});
  logEv('ডাইভারশন');return true;},
 vendorCart(){const s=evSpot(evDist()+10);if(!s)return false;const h=s.lay.half,pa=pLaneX(s.lay)+.6;
  const c=spawnCrosser(T.cart,s.n,s.d,-(h+2),1.25,{ry:-Math.PI/2,kind:'cart',w:2.1,len:1.4,role:'vendor',name:'ভ্যানওয়ালা',pauseAt:pa,pauseT:1.6});
  spawnCrosser(pick(T.people,CR),s.n,s.d,-(h+3.7),1.25,{role:'vendor',name:'ভ্যানওয়ালা',pauseAt:pa-1.7,pauseT:1.6});let said=0;
  EV.active.push({update(){if(c.dead)return false;if(!said&&c.d-P.d<50){said=1;sayAt('vendor',c,'ভ্যানওয়ালা','',PRIO.event);}return true;}});logEv('ভ্যানগাড়ির রাস্তা পার');return true;},
 phoneWalker(){const s=evSpot(evDist());if(!s)return false;const sd=R()<.5?-1:1,x=sd*(s.lay.half+1);
  const c=spawnCrosser(T.phoneGuy,s.n,s.d,x,-sd*1.1,{pauseAt:pLaneX(s.lay)+rr(-.4,.4),pauseT:2.3,role:'ped',name:'ফোনে ব্যস্ত পথচারী'});let said=0;
  EV.active.push({update(){if(c.dead)return false;if(!said&&c.d-P.d<48){said=1;sayAt('ped',c,'ফোনে ব্যস্ত পথচারী','',PRIO.event);}return true;}});return true;},
 teaCrowd(){const s=evSpot(evDist()+15);if(!s||s.lay.div)return false;const cs=[];
  for(let k=0;k<4;k++)cs.push(spawnCrosser(pick(T.people,CR),s.n,s.d+k*1.1,-s.lay.half+.5+(k%2)*.8,0,{ry:Math.PI/2*(k%2?1:-1),stay:true,life:90,role:'tea',name:'চায়ের আড্ডা'}));let said=0;
  EV.active.push({update(){if(cs[0].dead)return false;if(!said&&s.d-P.d<55){said=1;sayAt('tea',cs[1],'চায়ের আড্ডা','',PRIO.event);}return true;}});logEv('চায়ের আড্ডা রাস্তায়');return true;},
 cricket(){const s=evSpot(evDist()+25);if(!s||s.lay.div)return false;const h=s.lay.half,side=R()<.5?-1:1;
  // batsman + stumps on one edge, bowler on the other side of the road further ahead
  const B=new Builder();B.tmpl(T.stumps,side*(h-.4),0,-(s.d+2),0);const g=B.build(pathMapper(s.n.path,false));
  const bat=spawnCrosser(T.kids[0],s.n,s.d+1,side*(h-.6),0,{ry:side>0?Math.PI/2:-Math.PI/2,stay:true,life:60,role:'kids',name:'ছোট ক্রিকেটার'});const bm=new THREE.Mesh(T.bat,MATS.col);bm.position.set(.25,.55,0);bat.m.add(bm);
  spawnCrosser(T.kids[1],s.n,s.d+16,-side*(h-.5),0,{ry:side>0?-Math.PI/2:Math.PI/2,stay:true,life:60,role:'kids',name:'ছোট ক্রিকেটার'});
  spawnCrosser(T.kids[2],s.n,s.d+8,side*(h+.8),0,{stay:true,life:60,role:'kids',name:'ছোট ক্রিকেটার',ry:0});
  const ball=new THREE.Mesh(T.ball,MATS.ball);scene.add(ball);let st='wait',bx=side*(h-1),bd=s.d+2,bvx=0,kid=null,said=0,t=0;
  addObstacle(s.n,s.d+1.5,s.d+2.5,side>0?h-.7:-h+.1,side>0?h-.1:-h+.7,[g],'stumps');
  EV.active.push({cleanup(){scene.remove(ball);},update(dt){t+=dt;const rel=s.d-P.d;if(rel<-40){scene.remove(ball);return false;}
    if(st==='wait'&&rel<45){st='hit';AU.bat();bvx=-side*rr(3.5,5);sayAt('cricket',bat,'গলির ক্রিকেটার','shout',PRIO.event);
      kid=spawnCrosser(T.kids[3],s.n,bd+1.5,side*(h+.5),-side*2.6,{role:'kids',name:'ছোট ক্রিকেটার',life:14});}
    if(st==='hit'){bx+=bvx*dt;bvx*=Math.exp(-dt*.5);if(Math.abs(bx)>h-.3&&Math.sign(bx)!==side)bvx=0;
      if(!said&&Math.abs(P.d-bd)<4&&Math.abs(P.x-bx)<1.2){said=1;AU.thud(.3);bvx=-bvx*1.5+rr(-2,2);sayAt('kidsHit',bat,'ছোট ক্রিকেটার','shout');}}
    const f=s.n.path.pos(bd,bx,_f2);ball.position.set(f.x,f.y+.11,f.z);ball.rotation.x+=bvx*dt*4;return true;}});
  logEv('গলির ক্রিকেট');return true;},
 ducks(){const s=evSpot(evDist()+20);if(!s)return false;const h=s.lay.half,sd=R()<.5?-1:1;const cs=[];
  for(let k=0;k<6;k++)cs.push(spawnCrosser(T.duck,s.n,s.d+rr(-.3,.3),sd*(h+1+k*.7),-sd*.75,{kind:'duck',w:.35,len:.5,role:'ducks',name:'হাঁস',life:40,noShadow:true,noDodge:true}));
  const owner=spawnCrosser(pick(T.people,CR),s.n,s.d,sd*(h+5.8),-sd*.75,{role:'ducks',name:'হাঁসের মালিক',life:40});let said=0,q=0;
  EV.active.push({update(dt){if(owner.dead)return false;const rel=s.d-P.d;q-=dt;if(rel<70&&rel>-5&&q<=0){q=rr(.8,1.6);AU.quack();}
    if(!said&&rel<60){said=1;sayAt('ducks',owner,'হাঁসের মালিক','',PRIO.event);toastMsg('হাঁসের দল রাস্তা পার হচ্ছে!','info');}
    if(rel<-10&&!cs.some(c=>c.hitByCar)){GAME.duckFriend=true;}return true;}});logEv('হাঁসের মিছিল');return true;},
 flood(){const s=evSpot(evDist()+40);if(!s)return false;const len=rr(28,42),d0=s.d,d1=d0+len;if(d1>s.n.dEnd-12||pSkip(s.n,d1))return false;const h=s.lay.half;
  const g=new THREE.Group();const geo=stripGeo(d0,d1,-h-.1,h+.1,.12,3,4);pathMapper(s.n.path,false)(geo);const m=new THREE.Mesh(geo,MATS.flood);m.userData.own=true;g.add(m);
  const B=new Builder();for(let k=0;k<8;k++)B.box(.2,.06,.08,rr(-h+.5,h-.5),.15,-rr(d0+2,d1-2),pick(['#3a8ad0','#e8e8e8','#d04a3a','#2e9b57']));B.build(pathMapper(s.n.path,false),g);
  addObstacle(s.n,d0,d1,-h-.2,h+.2,[g],'flood',{surface:'flood'});let said=0;
  EV.active.push({update(){const rel=d0-P.d;if(rel<-len-20)return false;if(!said&&rel<60){said=1;const p=s.n.path.pos(d0+4,-h-2,{});sayAt('flood',{x:p.x,z:p.z,y:2.4},'পাশের লোক','',PRIO.event);toastMsg('সামনে রাস্তা পানির নিচে! আস্তে চালাও','info');}return true;}});
  logEv('পানিতে ডোবা রাস্তা');return true;},
 mud(){const s=evSpot(evDist()+30);if(!s)return false;const d0=s.d,d1=d0+rr(14,22),h=s.lay.half;if(d1>s.n.dEnd-12)return false;
  const g=new THREE.Group();const geo=stripGeo(d0,d1,-h,h*.4,.025,3,5);pathMapper(s.n.path,false)(geo);const m=new THREE.Mesh(geo,MATS.mud);m.userData.own=true;g.add(m);
  addObstacle(s.n,d0,d1,-h,h*.4,[g],'mud',{surface:'mud'});let said=0;
  EV.active.push({update(){const rel=d0-P.d;if(rel<-40)return false;if(!said&&rel<45){said=1;const p=s.n.path.pos(d0+3,h+1,{});sayAt('mud',{x:p.x,z:p.z,y:2.4},'পাশের লোক','',PRIO.event);}return true;}});
  logEv('কাদায় পিছলানো');return true;},
 truckUnload(){const s=evSpot(evDist()+40);if(!s||s.lay.div)return false;const h=s.lay.half,x=-h+1.35,d=s.d;
  const t=spawnVehicle('truck',s.n,d,x,1,0,{vDes:.0001,script:()=>({target:0,tx:x})});t.stopT=999;
  const ob=addObstacle(s.n,d-3.7,d+3.7,-h,x+1.3,[],'truck');
  for(let k=0;k<2;k++){const c=spawnCrosser(T.porter,s.n,d+1.5-k*3,-(h+1),0,{stay:true,life:70,role:'porter',name:'কুলি',noDodge:true});c.wander=false;c.porterT=k*1.5;}
  let said=0;EV.active.push({update(dt){if(t.dead){ob.dead=true;return false;}const rel=d-P.d;if(!said&&rel<60){said=1;sayV(t,'');setTimeout(()=>{if(GAME.state==='play')sayAt('porter',{x:t.wx,z:t.wz,y:2.6},'কুলি');},1800);}
    for(const c of GAME.cross)if(c.porterT!=null){c.porterT+=dt;c.x=-(h-.2)-Math.abs(Math.sin(c.porterT*.6))*2.6;c.moving=true;c.ry=Math.cos(c.porterT*.6)>0?Math.PI/2:-Math.PI/2;}
    return rel>-40;}});logEv('ট্রাক থেকে মাল নামানো');return true;},
 busBreakdown(){const s=evSpot(evDist()+40);if(!s)return false;const x=s.lay.our[s.lay.our.length-1];
  const b=spawnVehicle('bus',s.n,s.d,x,1,0,{vDes:.0001,script:v=>{v.st.t=(v.st.t||0)+.016;if(!v.st.s&&v.d-P.d<60){v.st.s=1;sayV(v,'');say(pickLine('busBreak'),'বাস হেলপার',{obj:v.mesh,y:3.8},PRIO.event);}
    if(v.mesh.children[0])v.mesh.rotation.z=Math.sin(GAME.t*20)*.004;return{target:0,tx:x};}});b.stopT=999;logEv('ফ্লাইওভারে বাস বিকল');return true;},
 cngClaim(){const s=evSpot(48);if(!s)return false;const px=pLaneX(s.lay);let x=px+2.3;if(x>(s.lay.div?-1.8:s.lay.half-1))x=px-2.3;
  spawnVehicle('cng',s.n,s.d,x,1,6,{vDes:8,script:v=>{if(!v.st.s&&v.d-P.d<32){v.st.s=1;sayV(v,'');hornAt(v);}if(v.st.s)return{tx:pLaneX(laneLayout(v.node,v.d,{})),lat:1.1};return null;}});
  logEv('সিএনজির "সোজা" যাওয়া');return true;},
 cngWrongWay(){const s=evSpot(evDist()+60);if(!s||!s.lay.div)return false;const x=s.lay.our[s.lay.our.length-1]+.4;
  const v=spawnVehicle('cng',s.n,s.d,x,-1,7,{vDes:8});v.side='our';v.script=(v)=>{if(!v.st.s&&P.d>v.d-60){v.st.s=1;hornAt(v);say(pickLine('cngWrong'),'সিএনজি ড্রাইভার',{obj:v.mesh,y:2.4},PRIO.event);toastMsg('উল্টো দিক থেকে সিএনজি!','bad');}return{tx:x};};
  logEv('উল্টো পথের সিএনজি');return true;},
 clearRoad(){GAME.veh.forEach(v=>{if(v.dir>0&&v.d>P.d+12&&v.d<P.d+270&&!v.script&&v.type!=='police')removeVeh(v);});GAME.veh=GAME.veh.filter(v=>!v.dead);GAME.clearUntil=P.d+260;P.boost=1;
  toastMsg('রাস্তা ফাঁকা! বুস্ট নাও','good');sayMe('clear');return true;},
 bikeSqueeze(){if(P.v<5)return false;const lay=laneLayout(P.node,P.d,{}),off=(P.x+1.6<(lay.div?-1.6:lay.half-1))?1.55:-1.55;if(P.d-30<P.node.dStart)return false;
  spawnVehicle('bike',P.node,P.d-30,P.x+off,1,P.v+7,{vDes:Math.min(24,P.v+8),script:v=>{if(!v.st.s&&v.d>P.d-12){v.st.s=1;sayV(v,'');hornAt(v);}if(v.d>P.d+25){v.script=null;return null;}return{target:Math.max(P.v+5,10),tx:P.x+off,lat:3};}});return true;},
};
/* ---------- signals at crossings ---------- */
function updateSignals(dt){for(const sig of WORLD.signals.values()){if(!related(sig.node,P.node))continue;const rel=sig.stop-P.d;
    if(!sig.decided&&rel<120&&rel>50){sig.decided=true;sig.willRed=R()<.65;}
    if(sig.willRed&&sig.phase==null&&rel<95){sig.phase='amber';sig.t=0;sig.state='amber';setLamps(sig);}
    if(sig.phase==='amber'){sig.t+=dt;if(sig.t>1.5){sig.phase='red';sig.t=0;sig.state='red';setLamps(sig);if(rel>-5)toastMsg('সিগন্যাল লাল! থামো','bad');}}
    else if(sig.phase==='red'){sig.t+=dt;if(!sig.spawned&&sig.t>1.2){sig.spawned=true;crossTraffic(sig);}
      if(sig.prevP!=null&&sig.prevP<sig.stop&&P.d>=sig.stop&&P.mode==='drive'){GAME.redRuns++;addTime(90);AU.whistle(1);const p=sig.node.path.pos(sig.d,0,{});sayAt('signal',{x:p.x,z:p.z,y:2.8},'ট্রাফিক পুলিশ','shout',PRIO.urgent);
        toastMsg('লাল সিগন্যাল পার! মামলা  −১.৫ মিনিট','bad');logEv('লাল সিগন্যাল অমান্য');}
      if(sig.t>8.5){sig.phase='done';sig.state='green';setLamps(sig);if(rel>-20)toastMsg('সবুজ! যাও যাও!','good');}}
    sig.prevP=P.d;}}
function crossTraffic(sig){const c=sig.cross,F=c.F0,ca=Math.cos(F.a),sa=Math.sin(F.a);
  for(let k=0;k<6;k++){const dir=k%2?1:-1,u=c.cu+dir*c.hc*.45,x=-dir*(c.h+30+k*7);const wx=F.x-sa*u+ca*x,wz=F.z-ca*u-sa*x;
    const dirA=dir>0?-F.a:-F.a+Math.PI;spawnFree(pick(['car','cng','bike','bus','car','rickshaw']),wx,F.y||0,wz,dirA,rr(7,10,CR));}}
/* ---------- driver ---------- */
const NO_STAND={police:1,bikeSqueeze:1,cngClaim:1,clearRoad:1};
function updateEvents(dt){const mode=P.mode;
  if(mode!=='walk'&&mode!=='metro'&&P.d>EV.next&&GAME.state==='play'){const s=evSpot(90),leg=s?s.leg:legAt(P.node,P.d);const w=Object.assign({},leg.events);
    if(GAME.weather==='rain'){if(w.flood)w.flood*=4;if(w.mud)w.mud*=2;if(w.cricket)w.cricket*=.2;if(w.ducks)w.ducks*=1.5;}
    else if(w.flood)w.flood*=.3;
    if(mode==='stand')for(const k in NO_STAND)delete w[k];
    if(P.cfg.ride)delete w.bikeSqueeze;
    EV.recent.forEach(k=>{if(w[k])w[k]*=.12;});const keys=Object.keys(w);
    if(!keys.length){EV.next=P.d+40;}
    else{const k=wpick(w),ok=EVENTS[k]&&EVENTS[k]();if(ok!==false&&ok!==undefined){EV.recent.push(k);if(EV.recent.length>3)EV.recent.shift();EV.next=P.d+rr(110,190);}else EV.next=P.d+15;}}
  if(mode==='walk'||mode==='metro')EV.next=Math.max(EV.next,P.d+60);
  updateSignals(dt);
  EV.active=EV.active.filter(a=>a.update(dt)!==false);
  EV.ambT-=dt;if(EV.ambT<=0){EV.ambT=rr(3.5,6);const cand=[];for(const s of WORLD.speakers){const rel=s.d-P.d;if(rel>12&&rel<70&&s.role!=='boss')cand.push(s);}
    if(cand.length&&mode!=='metro')ambientSay(pick(cand,CR));}
  bossCalls();}
function bossCalls(){const C=GAME.clock,D=GAME.deadline,tr=TRACKS[GAME.track];
  const calls=GAME.track==='varsity'?[[D-14*60,'রোল কল '+fmtClock(D)+'-এ! স্যার আজকে সবার নাম ডাকবে!'],[D-6*60,'দোস্ত কই তুই? স্যার ক্লাসে ঢুকে গেছে!'],[D,'স্যার রোল কল শুরু করছে… তোর রোল আসতেছে!'],[D+8*60,'প্রক্সি দিতে পারলাম না দোস্ত, স্যার চিনে ফেলছে!']]
    :[[D-14*60,'কোথায় আপনি? মিটিং কিন্তু '+fmtClock(D)+'-এ!'],[D-6*60,'রাস্তায় জ্যাম? রাস্তায় তো সবসময়ই জ্যাম!'],[D,fmtClock(D)+' বাজে! আপনার গাড়ি কি অন্য টাইম জোনে চলে?'],[D+8*60,'থাক, আজকে আর আসার দরকার নাই… মজা করলাম, তাড়াতাড়ি আসেন!']];
  calls.forEach((c,i)=>{if(C>=c[0]&&!EV.calls[i]&&GAME.state==='play'&&GAME.t>3){EV.calls[i]=1;AU.ring();say(c[1],tr.whoCall,null,PRIO.urgent,'phone',3.6);
      setTimeout(()=>{if(GAME.state==='play')sayMe(GAME.track==='varsity'?'meVarsity':'me',PRIO.event);},3800);}});}
function playerHorn(){AU.horn('player',1,0);GAME.lastHorn=GAME.t;let best=null,bd=32;
  for(const v of GAME.veh){if(!related(v.node,P.node))continue;const rel=v.d-P.d;if(rel>2&&rel<bd&&Math.abs(v.x-P.x)<3){bd=rel;best=v;}}
  if(best&&R()<.45&&(!GAME.honkReplyT||GAME.t>GAME.honkReplyT)){GAME.honkReplyT=GAME.t+4;sayV(best,'honk');}}
