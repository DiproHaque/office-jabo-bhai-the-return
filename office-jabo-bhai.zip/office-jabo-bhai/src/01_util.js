'use strict';
/* ============================================================
   অফিস যাবো, ভাই! — V4 (সকালের যুদ্ধ)
   01 UTIL / CONFIG
   ============================================================ */
const VERSION='4.0';
const BN='০১২৩৪৫৬৭৮৯';
const bn=s=>String(s).replace(/[0-9]/g,d=>BN[+d]);
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const smooth=t=>{t=clamp(t,0,1);return t*t*(3-2*t);};
const TAU=Math.PI*2;
function wrapA(a){while(a>Math.PI)a-=TAU;while(a<-Math.PI)a+=TAU;return a;}
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function hashStr(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
/* gameplay RNG is seeded per run (daily challenge = same for everyone); cosmetic uses Math.random */
let RUNRNG=Math.random;
const R=()=>RUNRNG();
const CR=Math.random;
const pick=(arr,r=R)=>arr[Math.floor(r()*arr.length)];
const rr=(a,b,r=R)=>a+(b-a)*r();
const ri=(a,b,r=R)=>Math.floor(a+(b+1-a)*r());
function wpick(obj,r=R){let t=0;for(const k in obj)t+=obj[k];let x=r()*t;for(const k in obj){x-=obj[k];if(x<=0)return k;}return Object.keys(obj)[0];}
function fmtClock(sec){const m=Math.floor(sec/60),h=Math.floor(m/60),mm=m%60;const h12=((h+11)%12)+1;return bn(h12)+':'+bn(String(mm).padStart(2,'0'));}
function fmtMS(sec){sec=Math.max(0,Math.round(sec));return bn(Math.floor(sec/60))+':'+bn(String(sec%60).padStart(2,'0'));}
function fmtMin(sec){sec=Math.max(0,Math.round(sec));const m=Math.floor(sec/60),s=sec%60;return m?(bn(m)+' মিনিট'+(s?' '+bn(s)+' সেকেন্ড':'')):(bn(s)+' সেকেন্ড');}
function fmtMinOnly(sec){return bn(Math.max(0,Math.round(sec/60)))+' মিনিট';}
function store(k,v){try{if(v===undefined){const s=localStorage.getItem(k);return s?JSON.parse(s):null;}localStorage.setItem(k,JSON.stringify(v));}catch(e){return null;}}
function todayKey(){const d=new Date();return d.getFullYear()*10000+(d.getMonth()+1)*100+d.getDate();}
function dayKeyOffset(off){const d=new Date();d.setDate(d.getDate()+off);return d.getFullYear()*10000+(d.getMonth()+1)*100+d.getDate();}
const MONTHS=['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
function todayBn(){const d=new Date();return bn(d.getDate())+' '+MONTHS[d.getMonth()]+' '+bn(d.getFullYear());}
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const CFG={
  chunkLen:40,
  sw:4.2,                 // default sidewalk width
  wallet:300,             // pocket money at the start of the morning
};
/* the two morning stories */
const TRACKS={
  office:{key:'office',name:'অফিস',title:'অফিস যাবো, ভাই!',start:(9*60+12)*60,deadline:10*3600,who:'বস',whoCall:'📞 বস ফোনে',place:'অফিস',
    late:'লেট', arriveVerb:'অফিসে'},
  varsity:{key:'varsity',name:'ভার্সিটি',title:'ভার্সিটি যাবো, ভাই!',start:(7*60+42)*60,deadline:(8*60+30)*60,who:'স্যার',whoCall:'💬 ক্লাসের গ্রুপে',place:'ক্লাস',
    late:'লেট', arriveVerb:'ক্লাসে'}};
/* graphics tiers */
const TIERS={
  low:{name:'লো',pr:.7,aa:false,fogFar:150,ahead:4,behind:1,traffic:.65,walkers:5,particles:140,rain:220,detail:0,props:0,wet:false},
  med:{name:'মিডিয়াম',pr:1,aa:false,fogFar:220,ahead:5,behind:1,traffic:.85,walkers:9,particles:280,rain:520,detail:1,props:1,wet:false},
  high:{name:'হাই',pr:1.5,aa:true,fogFar:300,ahead:7,behind:2,traffic:1,walkers:14,particles:460,rain:1000,detail:2,props:1,wet:true}};
const SETTINGS=Object.assign({quality:'auto',vol:75,music:55,mute:false,autoGas:false,swap:false,track:'office',plan:'bus',home:'mirpur10',dest:'kawran',name:''},store('ojb4-settings')||{});
function saveSettings(){store('ojb4-settings',SETTINGS);}
function isMobileUA(){const ua=navigator.userAgent||'';return /Android|iPhone|iPad|iPod|Mobile/i.test(ua)||(navigator.maxTouchPoints>1&&/Mac/.test(ua));}
function autoTier(){
  const cores=navigator.hardwareConcurrency||4,mem=navigator.deviceMemory||4;
  if(isMobileUA()){if(cores<=4||mem<=3)return'low';return'med';}
  if(cores<=2||mem<=2)return'low';return(cores>=8&&mem>=8)?'high':'med';}
let TIER=TIERS.med,TIERKEY='med';
function applyTierKey(){TIERKEY=SETTINGS.quality==='auto'?autoTier():SETTINGS.quality;TIER=Object.assign({},TIERS[TIERKEY]);}
