// Leaderboard mock: fake Supabase via route interception; checks submit payload, dedupe, rank line, name dialog.
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const AP=fs.readFileSync(path.join(__dirname,'v4.js'),'utf8').split('const AP=`')[1].split('`;')[0].replace('${process.env.HUMAN?1:0}','0');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const p=await b.newPage({viewport:{width:1280,height:720}});const logs=[];p.on('pageerror',e=>logs.push('PAGEERROR '+e.message));
  const DB=[{name:'রাফি',score:1500,plan:'metro',arrive:35400,stars:3,pid:'aaa',day:0,track:'office'},{name:'রাফি',score:900,plan:'bus',arrive:35700,stars:1,pid:'aaa',day:0,track:'office'},{name:'<b>x</b>',score:700,plan:'cng',arrive:0,stars:0,pid:'bbb',day:0,track:'office'}];
  await p.route('https://fake.supabase.co/**',async r=>{const q=r.request();if(q.method()==='POST'){const e=JSON.parse(q.postData());console.log('POST',JSON.stringify(e),'apikey',q.headers()['apikey']);DB.push(e);return r.fulfill({status:201,body:''});}
    const u=new URL(q.url());const day=+u.searchParams.get('day').slice(3),track=u.searchParams.get('track').slice(3);const rows=DB.map(x=>Object.assign({},x,{day:x.day||day})).filter(x=>x.day===day&&x.track===track).sort((a,b)=>b.score-a.score);
    console.log('GET',u.search.slice(0,90));return r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(rows)});});
  await p.addInitScript(()=>{localStorage.setItem('ojb4-howSeen','1');});
  let html=fs.readFileSync(path.resolve(__dirname,'../dist/index.html'),'utf8').replace("const BOARD_CFG={url:'',key:''}","const BOARD_CFG={url:'https://fake.supabase.co',key:'anon-test'}");
  const tmp='/tmp/claude-0/-home-claude/724b7833-088d-5224-ad50-1f43377fde34/scratchpad/board.html';fs.writeFileSync(tmp,html);
  await p.goto('file://'+tmp);await p.waitForSelector('#ldGo:not([hidden])',{timeout:90000});await p.evaluate(AP);await p.click('#ldGo',{force:true});await p.waitForTimeout(500);
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#trackSeg button')][0];b.click();});
  await p.click('#goDaily',{force:true});await p.waitForTimeout(300);await p.evaluate(()=>{document.querySelector('#planGrid [data-plan="metro"]').click();$('planGo').click();});
  await p.waitForFunction(()=>GAME.state==='play'&&JR.leg,null,{timeout:60000});
  for(let i=0;i<80;i++){const r=await p.evaluate(()=>{const e=simRun(600,1/30);return{e,st:GAME.state};});if(r.e.length){console.log(r.e[0]);break;}if(r.st!=='play'&&r.st!=='arrive')break;}
  await p.waitForSelector('#nameDlg:not([hidden])',{timeout:15000});console.log('name dialog shown');await p.fill('#nameIn','নাইটউইং');
  await p.evaluate(()=>{[...document.querySelectorAll('#nameDlg button')][0].click();});await p.waitForTimeout(2500);
  console.log('rank:',await p.evaluate(()=>$('rankLine').textContent));await p.screenshot({path:'/home/claude/v4/shots/board-result.png'});
  await p.evaluate(()=>{toMenu();});await p.waitForTimeout(500);await p.evaluate(()=>openBoard('office'));await p.waitForTimeout(800);
  console.log('rows:',await p.evaluate(()=>[...document.querySelectorAll('#boardList .br')].map(e=>e.textContent).join(' | ')));
  await p.screenshot({path:'/home/claude/v4/shots/board-list.png'});console.log(logs.join('\n'));await b.close();})();
