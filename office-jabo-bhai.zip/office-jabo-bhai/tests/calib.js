// Calibration: run each plan with the autopilot (HUMAN=1 → no boost, gentler) and report clock-running seconds vs par.
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const AP=fs.readFileSync(path.join(__dirname,'v4.js'),'utf8').split('const AP=`')[1].split('`;')[0].replace('${process.env.HUMAN?1:0}',process.env.HUMAN?'1':'0');
const plans=(process.env.PLANS||'bus,metro,bike,car,dd,cng,cycle').split(',');
const trips=(process.env.TRIPS||'mirpur10:kawran,uttara:motijheel,agargaon:du').split(',').map(t=>t.split(':'));
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const p=await b.newPage({viewport:{width:960,height:540}});const logs=[];p.on('pageerror',e=>logs.push('PAGEERROR: '+e.message+'\n'+e.stack));
  await p.addInitScript(()=>{localStorage.setItem('ojb4-howSeen','1');});
  await p.goto('file://'+path.resolve(__dirname,'../dist/index.html'));await p.waitForSelector('#ldGo:not([hidden])',{timeout:90000});await p.evaluate(AP);await p.click('#ldGo',{force:true});
  const rows=[];
  for(const [home,dest] of trips)for(const plan of plans){const track=dest==='du'?'varsity':'office';
    await p.evaluate(o=>{for(const id of['result','title','planner'])$(id).hidden=true;requestRun(o);},{plan,home,dest,track,seed:+(process.env.SEED||777),daily:false});
    await p.waitForFunction(()=>GAME.state==='play'&&JR.leg,null,{timeout:60000});
    let err=null;for(let i=0;i<60;i++){const r=await p.evaluate(()=>{const e=simRun(600,1/30);return{e,st:GAME.state};});if(r.e.length){err=r.e[0];break;}if(r.st!=='play'&&r.st!=='arrive')break;await p.waitForTimeout(20);}
    const r=await p.evaluate(()=>({st:GAME.state,run:((GAME.clock-GAME.startClock)/GAME.ts).toFixed(0),par:GAME.par.toFixed(0),arr:fmtClock(GAME.clock),late:Math.round((GAME.clock-GAME.deadline)/60),hits:GAME.hits,stum:JR.stumbles,len:ROUTE.root.officeD.toFixed(0),pen:Math.round(GAME.penalty||0),log:[...new Set(GAME.log)].filter(s=>!/শুরু/.test(s)).slice(0,6).join('|')}));
    rows.push([home+'>'+dest,plan,r.run,r.par,r.arr,r.late,r.hits,r.stum,r.pen,err?'ERR':'',r.log].join('\t'));console.log(rows[rows.length-1]);if(err)console.log(err);
    await p.waitForTimeout(300);}
  console.log(logs.slice(0,10).join('\n'));await b.close();})();
