// Visual tour: run plans with the autopilot and capture screenshots at leg starts, mid-legs and mini-games.
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const AP=fs.readFileSync(path.join(__dirname,'v4.js'),'utf8').split('const AP=`')[1].split('`;')[0].replace('${process.env.HUMAN?1:0}','1');
const OUT=process.env.OUT||'/home/claude/v4/shots/tour';fs.mkdirSync(OUT,{recursive:true});
const plans=(process.env.PLANS||'bus,metro,bike,car,dd,cng,cycle').split(',');
const [W,H]=(process.env.VP||'1280x720').split('x').map(Number);const mobile=!!process.env.MOBILE;
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const ctx=await b.newContext({viewport:{width:W,height:H},hasTouch:mobile,isMobile:mobile});const p=await ctx.newPage();const logs=[];p.on('pageerror',e=>logs.push('PAGEERROR: '+e.message+'\n'+e.stack));
  p.on('console',m=>{if(m.type()==='error')logs.push('console: '+m.text());});
  await p.addInitScript(()=>{localStorage.setItem('ojb4-howSeen','1');});
  await p.goto('file://'+path.resolve(__dirname,'../dist/index.html'));await p.waitForSelector('#ldGo:not([hidden])',{timeout:90000});await p.evaluate(AP);await p.click('#ldGo',{force:true});
  if(mobile)await p.evaluate(()=>enableTouch());
  for(const plan of plans){const home=process.env.HOME_||'mirpur10',dest=process.env.DEST||'kawran',track=dest==='du'?'varsity':'office';
    await p.evaluate(o=>{for(const id of['result','title','planner'])$(id).hidden=true;requestRun(o);},{plan,home,dest,track,seed:+(process.env.SEED||4242),daily:false,weather:process.env.WEATHER||undefined});
    await p.waitForFunction(()=>GAME.state==='play'&&JR.leg,null,{timeout:60000});await p.waitForTimeout(500);
    let k=0;const shot=async tag=>{await p.waitForTimeout(140);await p.screenshot({path:path.join(OUT,plan+'-'+String(++k).padStart(2,'0')+'-'+tag+'.png')});};
    await shot('morning');
    let lastLi=-1,lastQ=null,steps=0,midShot={};
    for(let i=0;i<400;i++){const r=await p.evaluate(()=>{const e=simRun(45,1/30);const L=JR.leg;return{e,st:GAME.state,li:JR.li,q:JR.qte?JR.qte.kind+':'+JR.qte.o.title:null,mode:P.mode,t:L?L.type:'',frac:L?(P.d-L.d0)/Math.max(1,L.d1-L.d0):0};});
      steps+=45;if(process.env.VERB&&i%20===0)console.log(plan,i,JSON.stringify(r));if(r.e.length){console.log("ERR",plan,r.e[0]);break;}
      if(r.li!==lastLi){lastLi=r.li;await shot('leg'+r.li+'-'+r.t);}
      if(r.q&&r.q!==lastQ){lastQ=r.q;await shot('qte');}if(!r.q)lastQ=null;
      for(const f of[.35,.7])if(r.frac>f&&!midShot[r.li+':'+f]){midShot[r.li+':'+f]=1;await shot('leg'+r.li+'-mid'+f);}
      if(r.st==='arrive'){await shot('arrive');}
      if(r.st!=='play'&&r.st!=='arrive')break;}
    await p.waitForTimeout(5600);await shot('result');console.log(plan,'done',k,'shots');}
  console.log(logs.slice(0,20).join('\n'));await b.close();})();
