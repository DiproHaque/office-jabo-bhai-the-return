const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});const p=await b.newPage({viewport:{width:1280,height:720}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file://'+path.resolve(__dirname,'../dist/index.html'));await p.waitForTimeout(2000);await p.click('#startB');await p.waitForFunction(()=>GAME.state==='play');
const AP=require('fs').readFileSync(__dirname+'/run.js','utf8').split('const AUTOPILOT=`')[1].split('`;')[0];await p.evaluate(AP);
const r=await p.evaluate(process.argv[2]||'1');console.log(JSON.stringify(r,null,1));
if(process.argv[3]){await p.waitForTimeout(300);await p.screenshot({path:process.argv[3]});}
await b.close();})();
