const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
for(const [w,h,m] of [[1280,720,false],[844,390,true]]){const ctx=await b.newContext({viewport:{width:w,height:h},hasTouch:m,isMobile:m});const p=await ctx.newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file://'+path.resolve(__dirname,'../dist/index.html'));await p.waitForTimeout(2000);
await p.click('#setB');await p.waitForTimeout(300);await p.screenshot({path:`/home/claude/v2/shots/menu-settings-${w}.png`});
await p.click('#qSeg [data-v="low"]');await p.click('#gasSeg [data-v="auto"]');await p.click('#setDone');
await p.click('#carSeg [data-v="bike"]');await p.click('#modeSeg [data-v="random"]');
console.log(await p.evaluate(()=>JSON.stringify(SETTINGS)));
await p.click('#startB');await p.waitForTimeout(500);if(await p.isVisible('#rotOk'))await p.click('#rotOk');
await p.waitForFunction(()=>GAME.state==='play');console.log('tier',TIERKEY=await p.evaluate(()=>TIERKEY),'car',await p.evaluate(()=>P.kind),'autogas',await p.evaluate(()=>SETTINGS.autoGas));
await p.waitForTimeout(2500);console.log('v with autogas',await p.evaluate(()=>P.v.toFixed(1)));
await p.click('#pauseB');await p.waitForTimeout(300);await p.screenshot({path:`/home/claude/v2/shots/menu-pause-${w}.png`});
await p.click('#menuB');await p.waitForTimeout(300);console.log('state',await p.evaluate(()=>GAME.state));await ctx.close();}
await b.close();})();
