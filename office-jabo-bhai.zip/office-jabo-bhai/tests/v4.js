// Headless verification for অফিস যাবো, ভাই! V4
// usage: node tests/v4.js <scenario> [env: PLAN, HOME, DEST, TRACK, VP, MOBILE, OUT, EVERY, HUMAN, SEED]
const {chromium}=require('playwright');
const path=require('path'),fs=require('fs');
const OUT=process.env.OUT||'/home/claude/v4/shots';fs.mkdirSync(OUT,{recursive:true});
const FILE='file://'+path.resolve(__dirname,'../dist/index.html');
const scenario=process.argv[2]||'boot';
const AP=`
window.AP={human:${process.env.HUMAN?1:0},qteT:0,log:[],perf:{}};
window.apDrive=function(){const lay=laneLayout(P.node,P.d,{}),h=lay.half;
  let lo=-h+P.w/2+.3,hi=(lay.div?-(divHalf(lay.leg)+P.w/2+.15):Math.min(h-P.w/2-.3,-.6));
  let best=P.x,bestF=-1e9;
  for(let x=lo;x<=hi;x+=.5){let free=90;
    for(const v of GAME.veh){const rel=v.d-P.d;if(rel>-2&&Math.abs(v.x-x)<(v.w+P.w)/2+.35){const f=rel-(v.len+P.l)/2+(v.dir>0?v.v*2.5:-v.v*2.5);if(f<free)free=f;}}
    for(const c of GAME.cross){const rel=c.d-P.d;if(rel>-1&&Math.abs(c.x-x)<(c.w+P.w)/2+.5)free=Math.min(free,rel-3);}
    for(const o of GAME.obst){if(o.surface)continue;if(o.d1>P.d&&x+P.w/2>o.x0-.3&&x-P.w/2<o.x1+.3)free=Math.min(free,o.d0-P.d-3);}
    free-=Math.abs(x-P.x)*1.2;if(free>bestF){bestF=free;best=x;}}
  if(JR.leg&&JR.leg.type==='car'&&ROUTE.bay&&P.d>ROUTE.bay.d0-40){const B=ROUTE.bay;best=(B.x0+B.x1)/2;const mid=(B.d0+B.d1)/2,rem=mid-P.d;
    const want=Math.atan2(-(best-P.x),Math.max(4,P.v+3));KEYS.left=P.h<want-.03?1:0;KEYS.right=P.h>want+.03?1:0;const vd=Math.max(0,Math.min(8,rem*.5));KEYS.up=P.v<vd-.3?1:0;KEYS.down=P.v>vd+.3||rem<0?1:0;if(rem<0&&P.v<.3){KEYS.down=0;KEYS.up=0;}return;}
  const want=Math.atan2(-(best-P.x),9);KEYS.left=P.h<want-.04?1:0;KEYS.right=P.h>want+.04?1:0;
  KEYS.up=1;KEYS.down=0;KEYS.boost=AP.human?0:(bestF>60?1:0);if(AP.human&&P.v>(AP.vmax||15))KEYS.up=0;
  for(const s of WORLD.signals.values()){const rel=s.stop-P.d;if(s.state!=='green'&&rel>0&&rel<P.v*1.6+6){KEYS.up=0;KEYS.down=1;}}
  for(const c of GAME.cross){if(c.role==='police'&&c.stay&&!c.apDone){const rel=c.d-P.d;if(rel>0&&rel<40){if(rel<16&&P.v<1)c.apDone=true;KEYS.up=rel>16?1:0;KEYS.down=P.v>(rel-10)*.6?1:0;}}}
  const lim=Math.max(4,bestF*.75);if(P.v>lim){KEYS.up=0;KEYS.down=1;}
  if(P.stuckT>2.5)resetCar();};
window.apWalk=function(){const n=ROUTE.root,h=halfAt(n,P.d),sw=swAt(n,P.d);let best=P.x,bf=-1e9;
  for(let x=-(h+sw)+.4;x<=-h-.2;x+=.3){let free=40;for(const o of WALKOB.list){const rel=o.d-P.d;if(rel>-.5&&Math.abs(o.x-x)<o.w/2+.45)free=Math.min(free,rel);}free-=Math.abs(x-P.x)*.6;if(free>bf){bf=free;best=x;}}
  KEYS.left=best<P.x-.15?1:0;KEYS.right=best>P.x+.15?1:0;KEYS.up=AP.human?0:1;KEYS.boost=AP.human?0:(JR.walk&&JR.walk.stam>.35?1:0);KEYS.down=0;};
window.apBalance=function(){const u=JR.bal*1.5+JR.balV*.9;KEYS.left=u>.12?0:0;KEYS.right=0;if(u>.1)KEYS.left=1;else if(u<-.1)KEYS.right=1;
  if(AP.human){if(Math.random()<.3){KEYS.left=0;KEYS.right=0;}}};
window.apQte=function(dt){const q=JR.qte;if(!q)return;AP.qteT+=dt;
  if(q.kind==='choice'){if(q.t>.6){const i=AP.choice!=null?Math.min(AP.choice,q.o.opts.length-1):0;pickChoice(i);AP.log.push('choice:'+q.o.title.slice(0,24)+'->'+i);}}
  else if(q.kind==='mash'){if(AP.qteT>(AP.human?.3:.17)){AP.qteT=0;qteAction();}}
  else if(q.kind==='timing'){if(Math.abs(q.pos-q.zc)<q.zw*(AP.human?.45:.2)&&q.t>.3){qteAction();AP.log.push('timing ok');}}};
window.apStep=function(dt){for(const k in KEYS)KEYS[k]=0;apQte(dt);if(!JR.leg)return;const m=P.mode;
  if(m==='drive')apDrive();else if(m==='walk')apWalk();else if(m==='stand'||m==='metro'){apBalance();if(m==='stand'&&JR.bus&&!JR.bus.knocked&&!JR.bus.missed){const td=JR.leg.target.d-P.d;if(td<110&&td>45)doAction();}}
  else if(m==='ride'){KEYS.up=AP.human?0:(P.boost>.3?1:0);}};
window.simRun=function(n,dt){const errs=[];for(let i=0;i<n;i++){if(GAME.state!=='play'&&GAME.state!=='arrive')break;try{apStep(dt);gameStep(dt);}catch(e){errs.push(String(e.stack||e));break;}}return errs;};
`;
(async()=>{
  const vp=process.env.VP||'1280x720';const[w,h]=vp.split('x').map(Number);const mobile=!!process.env.MOBILE;
  const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
  const ctx=await b.newContext({viewport:{width:w,height:h},deviceScaleFactor:1,hasTouch:mobile,isMobile:mobile});
  const p=await ctx.newPage();const logs=[];
  p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')logs.push(m.type()+': '+m.text());});
  p.on('pageerror',e=>logs.push('PAGEERROR: '+e.message+'\n'+(e.stack||'')));
  await p.addInitScript(s=>{try{localStorage.setItem('ojb4-settings',JSON.stringify(s));if(s.__profile)localStorage.setItem('ojb4-profile',JSON.stringify(s.__profile));localStorage.setItem('ojb4-howSeen','1');}catch(e){}},
    Object.assign({},JSON.parse(process.env.SET||'{}'),process.env.UNLOCK?{__profile:{xp:3000}}:{}));
  const t0=Date.now();await p.goto(FILE);
  const shot=async n=>{await p.screenshot({path:path.join(OUT,n+'.png')});console.log('shot',n);};
  if(scenario==='boot'){await p.waitForTimeout(400);await shot('boot-loader');}
  await p.waitForSelector('#ldGo:not([hidden])',{timeout:90000});console.log('ready in',Date.now()-t0,'ms');
  await p.evaluate(AP);
  if(scenario==='boot'){await shot('boot-ready');await p.click('#ldGo',{force:true});await p.waitForTimeout(1500);await shot('title');
    await p.click('#goDaily');await p.waitForTimeout(400);await shot('planner');console.log(logs.join('\n'));await b.close();return;}
  await p.click('#ldGo',{force:true});await p.waitForTimeout(300);
  if(scenario==='run'){const plan=process.env.PLAN||'bus';
    await p.evaluate(o=>{requestRun(o);},{plan,home:process.env.HOME_||'mirpur10',dest:process.env.DEST||'kawran',track:process.env.TRACK||'office',seed:+(process.env.SEED||12345),daily:false});
    await p.waitForFunction(()=>GAME.state==='play'&&JR.leg,null,{timeout:60000});await p.waitForTimeout(500);await shot('run-'+plan+'-00');
    const every=+(process.env.EVERY||300);let k=0,steps=0;const maxSteps=+(process.env.MAX||16000);
    while(steps<maxSteps){const r=await p.evaluate(n=>{const e=simRun(n,1/30);return{e,st:GAME.state,leg:JR.li,mode:P.mode,d:P.d.toFixed(0),clock:fmtClock(GAME.clock),v:P.v.toFixed(1),qte:JR.qte&&JR.qte.kind,hold:JR.hold.toFixed(1)};},every);
      steps+=every;console.log(steps,JSON.stringify(r));if(r.e.length){console.log('ERR',r.e.join('\n'));break;}
      await p.waitForTimeout(60);if(process.env.SHOTS)await shot('run-'+plan+'-'+String(++k).padStart(2,'0'));
      if(r.st!=='play'&&r.st!=='arrive')break;}
    await p.waitForTimeout(5200);await shot('run-'+plan+'-result');
    const res=await p.evaluate(()=>({state:GAME.state,clock:fmtClock(GAME.clock),deadline:fmtClock(GAME.deadline),score:RES&&RES.S.total,stars:RES&&RES.S.stars,rows:RES&&RES.S.rows,comfort:JR.comfort.toFixed(0),hits:GAME.hits,stumbles:JR.stumbles,jam:Math.round(JR.jamT),par:GAME.par&&GAME.par.toFixed(0),ts:GAME.ts.toFixed(1),log:[...new Set(GAME.log)].slice(0,30),ap:AP.log.slice(0,20)}));
    console.log('RESULT',JSON.stringify(res,null,1));}
  console.log('LOGS:\n'+logs.slice(0,40).join('\n'));await b.close();})();
