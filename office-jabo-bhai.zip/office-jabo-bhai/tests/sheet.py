import sys,glob,os
from PIL import Image,ImageDraw
files=sorted(glob.glob(sys.argv[1]));out=sys.argv[2];per=int(sys.argv[3]) if len(sys.argv)>3 else 4
cols=2;tw,th=640,360
for s in range(0,len(files),per):
    chunk=files[s:s+per];rows=(len(chunk)+cols-1)//cols
    sheet=Image.new('RGB',(tw*cols,th*rows),'black');d=ImageDraw.Draw(sheet)
    for i,f in enumerate(chunk):
        im=Image.open(f).convert('RGB');im.thumbnail((tw,th));x=(i%cols)*tw;y=(i//cols)*th;sheet.paste(im,(x,y));d.rectangle([x,y,x+300,y+16],fill='black');d.text((x+3,y+2),os.path.basename(f),fill='yellow')
    sheet.save(out+'-%02d.png'%(s//per))
print('ok')
