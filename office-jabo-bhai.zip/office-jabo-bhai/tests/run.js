// Headless verification for অফিস যাবো, ভাই! V2
// usage: node tests/run.js <scenario> [options]
const {chromium}=require('playwright');
const path=require('path'),fs=require('fs');
const OUT=process.env.OUT||'/home/claude/v2/shots';fs.mkdirSync(OUT,{recursive:true});
const FILE='file://'+path.resolve(__dirname,'../dist/index.html');
const scenario=process.argv[2]||'smoke';
const AUTOPILOT=`
window.AP={fork:[], log:[]};
window.apKeys=function(){
  const lay=laneLayout(P.node,P.d,{}),h=lay.half;
  let lo=-h+P.w/2+.3,hi=(lay.div?-(divHalf(lay.leg)+P.w/2+.15):Math.min(h-P.w/2-.3,-.6));
  // choose fork direction
  let forceRight=null;
  if(P.node.fork){const dist=P.node.fork.d0-P.d;if(dist<60){const pref=AP.fork[P.node.depth];forceRight=pref==='right';}}
  let best=P.x,bestF=-1e9;
  for(let x=lo;x<=hi;x+=.5){let free=90;
    for(const v of GAME.veh){if(!related(v.node,P.node))continue;const rel=v.d-P.d;if(rel>-2&&Math.abs(v.x-x)<(v.w+P.w)/2+.35){const f=rel-(v.len+P.l)/2+(v.dir>0?v.v*2.5:-v.v*2.5);if(f<free)free=f;}}
    for(const c of GAME.cross){if(!related(c.node,P.node))continue;const rel=c.d-P.d;if(rel>-1&&Math.abs(c.x-x)<(c.w+P.w)/2+.5)free=Math.min(free,rel-3);}
    for(const o of GAME.obst){if(o.surface||!related(o.node,P.node))continue;if(o.d1>P.d&&x+P.w/2>o.x0-.3&&x-P.w/2<o.x1+.3)free=Math.min(free,o.d0-P.d-3);}
    free-=Math.abs(x-P.x)*1.2;if(free>bestF){bestF=free;best=x;}}
  if(forceRight===true){best=Math.min(hi,1.2);} if(forceRight===false){best=Math.max(lo,-h*.5);}
  // heading controller
  const want=Math.atan2(-(best-P.x),9);
  KEYS.left=P.h<want-.04?1:0;KEYS.right=P.h>want+.04?1:0;
  if(forceRight===true&&P.node.fork&&P.node.fork.d0-P.d<3){KEYS.right=1;KEYS.left=0;}
  KEYS.up=1;KEYS.down=0;KEYS.boost=AP.human?0:(bestF>60?1:0);if(AP.human&&P.v>(AP.vmax||15)){KEYS.up=0;}
  // signals
  for(const s of WORLD.signals.values()){if(!related(s.node,P.node))continue;const rel=s.stop-P.d;if(s.state!=='green'&&rel>0&&rel<P.v*1.6+6){KEYS.up=0;KEYS.down=1;}}
  // police check
  for(const c of GAME.cross){if(c.role==='police'&&c.stay&&!c.apDone&&related(c.node,P.node)){const rel=c.d-P.d;if(rel>0&&rel<40){if(rel<16&&P.v<1)c.apDone=true;KEYS.up=rel>16?1:0;KEYS.down=P.v>(rel-10)*.6?1:0;}}}
  const lim=Math.max(4,bestF*.75);if(P.v>lim){KEYS.up=0;KEYS.down=1;}
  if(P.stuckT>2.5){resetCar();}
  if(GAME.incident&&GAME.incident.shown)chooseIncident(AP.incident||'sorry');
};
window.simSteps=function(n,dt){let errs=[];for(let i=0;i<n;i++){if(GAME.state!=='play'&&GAME.state!=='arrive')break;
  try{apKeys();
  if(GAME.warpT>0){GAME.warpT-=dt;if(GAME.warpT<=0)GAME.warp=1;}else GAME.warp=Math.min(1,GAME.warp+dt*3);const d2=dt*GAME.warp;
  GAME.t+=d2;if(GAME.state==='play'&&!GAME.incident)GAME.clock+=d2*CFG.timeScale*(GAME.teaT>0?.4:1);
  updatePlayer(d2);trafficSpawner(d2);updateVehicles(d2);updateCrossers(d2);updateWalkers(d2);updateObstacles();updateDebris(d2);updateEvents(d2);growEndless(P.node,P.d);updatePickups(d2);updateTrains(d2);updateDholai(d2);updateChunks(P.node,P.d,0,true);
  if(GAME.state==='play'){if(!GAME.endless&&!P.node.children.length&&P.d>=P.node.officeD-3)arrive();else if(!GAME.endless&&GAME.clock>=GAME.deadline+25*60)finish(true);}else{GAME.arriveT+=dt;if(GAME.arriveT>2.8)finish(false);}
  updateCamera(dt);updateGround();FX.update(d2);RAIN.update(dt);updateSub();hudT=0;updateHUD(dt);}catch(e){errs.push(e.stack);break;}}
  return errs;};
`;
(async()=>{
  const vp=process.env.VP||'1280x720';const[w,h]=vp.split('x').map(Number);const mobile=!!process.env.MOBILE;
  const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
  const ctx=await b.newContext({viewport:{width:w,height:h},deviceScaleFactor:1,hasTouch:mobile,isMobile:mobile});
  const p=await ctx.newPage();const logs=[];
  p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')logs.push(m.type()+': '+m.text());});
  p.on('pageerror',e=>logs.push('PAGEERROR: '+e.message+'\n'+(e.stack||'')));
  await p.addInitScript(s=>{try{localStorage.setItem('ojb2-settings',JSON.stringify(s));}catch(e){}},JSON.parse(process.env.SET||'{}'));
  await p.goto(FILE);await p.waitForTimeout(2500);
  const shot=async n=>{await p.screenshot({path:path.join(OUT,n+'.png')});console.log('shot',n);};
  await p.evaluate(AUTOPILOT);
  if(scenario==='smoke'||scenario==='title'){await shot('title');}
  if(scenario==='title'){console.log(logs.join('\n'));await b.close();return;}
  if(scenario==='tour'){
    await p.click('#startB');await p.waitForFunction(()=>GAME.state==='play',null,{timeout:60000});
    const forks=(process.env.FORKS||'left,left').split(',');
    const pois=await p.evaluate(f=>{const out=[];let n=ROUTE.root;let depth=0;
      while(n){for(const j of n.juncs){if(j.d0<n.dStart-1)continue;out.push({nid:n.id,d:j.d0-25,tag:j.kind+'-pre'},{nid:n.id,d:(j.d0+j.d1)/2,tag:j.kind+'-mid'},{nid:n.id,d:j.d1+12,tag:j.kind+'-post'});}
        for(const L of n.legs){if(L.d0<n.dStart-1||L.marker)continue;if(L.type==='rampUp'||L.type==='flyover'||L.type==='alley'||L.type==='market'||L.type==='office')out.push({nid:n.id,d:L.d0+(L.type==='rampUp'?60:40),tag:'leg-'+L.type});}
        if(n.fork){out.push({nid:n.id,d:n.fork.d0-40,tag:'fork-pre'},{nid:n.id,d:n.fork.d0-8,tag:'fork-near'});}
        if(n.office)out.push({nid:n.id,d:n.officeD-30,tag:'office'});
        n=n.children.length?n.children[f[depth++]==='right'?1:0]:null;}
      return out;},forks);
    let k=0;for(const q of pois){await p.evaluate(q=>{const n=ROUTE.nodes.find(x=>x.id===q.nid);P.node=n;P.d=q.d;const lay=laneLayout(n,q.d,{});P.x=lay.our[lay.our.length-1]*.5+lay.our[0]*.5;P.h=0;P.v=0;
        playerWorld(PW);updateChunks(P.node,P.d,0,true);CAM.yaw=PW.a;updateCamera(0,true);hudT=0;updateHUD(.1);},q);
      await p.waitForTimeout(250);await shot('tour-'+String(++k).padStart(2,'0')+'-'+q.tag);}
    console.log('LOGS:\n'+logs.slice(0,30).join('\n'));await b.close();return;}
  if(scenario==='mobile'){
    await shot('m-title');
    await p.click('#startB');await p.waitForTimeout(600);
    if(await p.isVisible('#rotate')){await shot('m-rotate');await p.click('#rotOk');}
    await p.waitForFunction(()=>GAME.state==='play',null,{timeout:60000});await p.waitForTimeout(800);
    const boxes=await p.evaluate(()=>[...document.querySelectorAll('#touch .tb')].map(b=>{const r=b.getBoundingClientRect();return{k:b.dataset.k,x:Math.round(r.left),y:Math.round(r.top),r:Math.round(r.right),b:Math.round(r.bottom),vis:r.right<=innerWidth&&r.bottom<=innerHeight&&r.left>=0&&r.top>=0};}));
    console.log('BUTTONS',JSON.stringify(boxes),'touchOn',await p.evaluate(()=>TOUCH.on));
    const gas=boxes.find(b=>b.k==='up');await p.mouse.move((gas.x+gas.r)/2,(gas.y+gas.b)/2);await p.mouse.down();await p.waitForTimeout(3500);
    console.log('after gas',await p.evaluate(()=>({up:KEYS.up,v:P.v.toFixed(1),d:P.d.toFixed(1)})));await shot('m-driving');
    const lf=boxes.find(b=>b.k==='left');await p.mouse.up();
    await p.evaluate(()=>{for(let i=0;i<300;i++){}});
    console.log('after release',await p.evaluate(()=>({up:KEYS.up})));
    // multi-touch: gas + left via CDP touch events
    const cdp=await ctx.newCDPSession(p);
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:(gas.x+gas.r)/2,y:(gas.y+gas.b)/2,id:1},{x:(lf.x+lf.r)/2,y:(lf.y+lf.b)/2,id:2}]});
    await p.waitForTimeout(1200);console.log('multitouch',await p.evaluate(()=>({up:KEYS.up,left:KEYS.left,v:P.v.toFixed(1),h:P.h.toFixed(2)})));await shot('m-steer');
    await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await p.waitForTimeout(300);
    console.log('after end',await p.evaluate(()=>({up:KEYS.up,left:KEYS.left})));
    await p.evaluate(()=>{simSteps(400,1/30);});await p.waitForTimeout(300);await shot('m-later');
    await p.evaluate(()=>{P.node=ROUTE.root;P.d=ROUTE.root.fork.d0-60;P.x=-3;P.h=0;P.v=8;playerWorld(PW);updateChunks(P.node,P.d,0,true);CAM.yaw=PW.a;updateCamera(0,true);hudT=0;updateHUD(.1);say('আরেকটু হইলে তো ইতিহাস হইয়া যাইতাম! আরেকটা লম্বা লাইন দেখার জন্য।','পথচারী',null,3,'shout',5);toastMsg('সামনে রাস্তা পানির নিচে! আস্তে চালাও','info');});
    await p.waitForTimeout(400);await shot('m-fork');
    await p.evaluate(()=>{startIncident(GAME.veh[0]||null,null);});await p.waitForTimeout(1500);await shot('m-incident');await p.evaluate(()=>chooseIncident('sorry'));
    await p.evaluate(()=>{finish(false);});await p.waitForTimeout(500);await shot('m-result');
    console.log('LOGS:\n'+logs.slice(0,30).join('\n'));await b.close();return;}
  if(scenario==='events'){
    await p.click('#startB');await p.waitForFunction(()=>GAME.state==='play',null,{timeout:60000});
    const list=(process.env.EVS||'cricket,ducks,flood,truckUnload,wedding,construction,diversion,mud,busStop,cow,police,rickshawStraight,cngWrongWay').split(',');
    let k=0;
    for(const ev of list){const r=await p.evaluate(ev=>{
        // find a leg that has this event, teleport there
        const want=ev;let tgt=null;for(const n of ROUTE.nodes)for(const L of n.legs){if(L.marker||L.d0<n.dStart-1)continue;if(L.events&&L.events[want]&&L.d1-L.d0>150){tgt={n,d:L.d0+40};break;}}if(!tgt)return 'no leg';
        for(const v of GAME.veh)scene.remove(v.mesh);GAME.veh=[];for(const c of GAME.cross)scene.remove(c.m);GAME.cross=[];for(const o of GAME.obst)o.meshes.forEach(m=>scene.remove(m));GAME.obst=[];EV.active=[];
        P.node=tgt.n;P.d=tgt.d;const lay=laneLayout(P.node,P.d,{});P.x=lay.our[lay.our.length-1];P.h=0;P.v=8;playerWorld(PW);updateChunks(P.node,P.d,0,true);
        const d0=P.d;const ok=EVENTS[ev]();EV.next=1e9;KEYS.up=0;
        let tgtD=null;for(const c of GAME.cross)tgtD=tgtD==null?c.d:Math.min(tgtD,c.d);for(const o of GAME.obst)tgtD=tgtD==null?o.d0:Math.min(tgtD,o.d0);for(const v of GAME.veh)if(v.script)tgtD=tgtD==null?v.d:Math.min(tgtD,v.d);
        if(tgtD!=null){P.d=Math.max(d0,tgtD-(ev==='flood'||ev==='mud'?14:22));}playerWorld(PW);updateChunks(P.node,P.d,0,true);
        for(let i=0;i<50;i++){updatePlayer(1/30);updateVehicles(1/30);updateCrossers(1/30);updateObstacles();updateEvents(1/30);P.v=Math.min(P.v,3);}
        CAM.yaw=PW.a;updateCamera(0,true);hudT=0;updateHUD(.1);updateSub();return ok;},ev);
      console.log(ev,r);await p.waitForTimeout(300);await shot('ev-'+String(++k).padStart(2,'0')+'-'+ev);}
    // rain look
    await p.evaluate(()=>{GAME.weather='rain';applyWeather();for(let i=0;i<30;i++)RAIN.update(1/30);});await p.waitForTimeout(300);await shot('ev-rain');
    // signal red with cross traffic
    await p.evaluate(()=>{GAME.weather='clear';applyWeather();let sig=null;let tgt=null;for(const n of ROUTE.nodes)for(const j of n.juncs)if(j.kind==='cross'&&!tgt)tgt={n,j};
      P.node=tgt.n;P.d=tgt.j.d0-30;P.x=-4;P.h=0;P.v=0;playerWorld(PW);updateChunks(P.node,P.d,0,true);sig=[...WORLD.signals.values()].find(s=>s.j===tgt.j);
      sig.decided=true;sig.willRed=true;sig.phase='red';sig.state='red';sig.t=0;setLamps(sig);crossTraffic(sig);for(let i=0;i<90;i++){updateVehicles(1/30);}CAM.yaw=PW.a;updateCamera(0,true);hudT=0;updateHUD(.1);});
    await p.waitForTimeout(300);await shot('ev-signal');
    // chase + damage
    await p.evaluate(()=>{P.damage=75;damagePlayer(10,'front',1);damagePlayer(10,'side',1);startChase();for(let i=0;i<60;i++){updateVehicles(1/30);updateEvents(1/30);poseModel(1/30);FX.update(1/30);}CAM.yaw=PW.a;updateCamera(0,true);hudT=0;updateHUD(.1);});
    await p.waitForTimeout(300);await shot('ev-chase');
    console.log('LOGS:\n'+logs.slice(0,30).join('\n'));await b.close();return;}
  // start
  await p.click('#startB');await p.waitForTimeout(400);
  if(await p.isVisible('#rotate')){await shot('rotate');await p.click('#rotOk');}
  await p.waitForFunction(()=>GAME.state==='play',null,{timeout:60000});await p.waitForTimeout(1500);await shot(scenario+'-start');
  const forks=(process.env.FORKS||'left,left').split(',');await p.evaluate(([f,h])=>{AP.fork=f;AP.incident=window.__inc||'sorry';AP.human=!!h;AP.vmax=+h||15;},[forks,process.env.HUMAN||'']);
  if(process.env.INC)await p.evaluate(i=>{AP.incident=i;},process.env.INC);
  const steps=+(process.env.STEPS||6000),every=+(process.env.EVERY||900);let k=0;
  for(let s=0;s<steps;s+=every){const errs=await p.evaluate(([n])=>simSteps(n,1/30),[every]);if(errs.length){console.log('SIMERR',errs.join('\n'));break;}
    const st=await p.evaluate(()=>({state:GAME.state,d:Math.round(P.d),node:P.node.id,route:P.node.route||'root',clock:fmtClock(GAME.clock),v:P.v.toFixed(1),veh:GAME.veh.length,cross:GAME.cross.length,
      chunks:WORLD.chunks.size,hits:GAME.hits,near:GAME.near,dmg:Math.round(P.damage),ev:EV.recent.join(','),tris:renderer.info.render.triangles,calls:renderer.info.render.calls,geo:renderer.info.memory.geometries}));
    console.log(JSON.stringify(st));
    await p.waitForTimeout(120);await shot(scenario+'-'+String(++k).padStart(2,'0'));
    if(st.state==='result')break;}
  if(await p.isVisible('#result')){await shot(scenario+'-result');}
  console.log('LOGS:\n'+logs.slice(0,30).join('\n'));
  await b.close();})();
