// UI flow: portrait rotate prompt, title→planner→start via buttons, pause/map/settings/how/board, varsity daily.
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const AP=fs.readFileSync(path.join(__dirname,'v4.js'),'utf8').split('const AP=`')[1].split('`;')[0].replace('${process.env.HUMAN?1:0}','1');
const OUT='/home/claude/v4/shots/flow';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const ctx=await b.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:1});const p=await ctx.newPage();const logs=[];
  p.on('pageerror',e=>logs.push('PAGEERROR: '+e.message+'\n'+e.stack));p.on('console',m=>{if(m.type()==='error')logs.push('console: '+m.text());});
  await p.goto('file://'+path.resolve(__dirname,'../dist/index.html'));await p.waitForSelector('#ldGo:not([hidden])',{timeout:90000});
  const shot=async n=>{await p.waitForTimeout(250);await p.screenshot({path:path.join(OUT,n+'.png')});console.log('shot',n);};
  await shot('p-loader');await p.evaluate(AP);await p.tap('#ldGo',{force:true});await p.waitForTimeout(1500);await shot('p-title');
  await p.setViewportSize({width:844,height:390});await p.waitForTimeout(600);await shot('l-title');
  // how-to first time?
  const howVis=await p.evaluate(()=>!$('how').hidden);console.log('how auto',howVis);if(howVis){await shot('l-how');await p.evaluate(()=>{const b=document.querySelector('#how button');b&&b.click();});}
  // varsity segment
  await p.evaluate(()=>{const b=document.querySelector('#trackSeg [data-v="varsity"]')||[...document.querySelectorAll('#trackSeg button')][1];b.click();});await p.waitForTimeout(300);await shot('l-title-varsity');
  await p.tap('#goDaily',{force:true});await p.waitForTimeout(400);await shot('l-planner-varsity');
  const plans=await p.evaluate(()=>[...document.querySelectorAll('#planGrid .plan')].map(e=>e.dataset.plan+(e.classList.contains('locked')?'(L)':'')));console.log('plans',plans.join(','));
  await p.evaluate(()=>{const e=[...document.querySelectorAll('#planGrid .plan')].find(e=>e.dataset.plan==='bus');e.click();});
  const startBtn=await p.evaluate(()=>{document.getElementById('planGo').click();return 'planGo';});console.log('start',startBtn);
  await p.waitForFunction(()=>GAME.state==='play'&&JR.leg,null,{timeout:60000});await shot('l-varsity-morning');
  for(let i=0;i<40;i++){await p.evaluate(()=>simRun(30,1/30));}
  await shot('l-varsity-mid');
  await p.evaluate(()=>pauseGame&&pauseGame());await p.waitForTimeout(300);await shot('l-pause');
  const pbtn=await p.evaluate(()=>[...document.querySelectorAll('#pause button')].map(b=>b.id+':'+b.textContent.trim()));console.log(pbtn.join(' | '));
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#pause button')].find(b=>/ম্যাপ|মানচিত্র/.test(b.textContent));b&&b.click();});await p.waitForTimeout(500);await shot('l-map');
  await p.evaluate(()=>{const b=document.querySelector('#mapScr button');b&&b.click();});await p.waitForTimeout(300);
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#pause button')].find(b=>/চালিয়ে|ফিরে/.test(b.textContent));b&&b.click();});await p.waitForTimeout(300);
  let st;for(let i=0;i<500;i++){const r=await p.evaluate(()=>{const e=simRun(60,1/30);return{e,st:GAME.state};});if(r.e.length){console.log('ERR',r.e[0]);break;}st=r.st;if(st!=='play'&&st!=='arrive')break;}
  console.log('end state',st);await p.waitForTimeout(6000);await shot('l-varsity-result');
  const rb=await p.evaluate(()=>[...document.querySelectorAll('#result button')].filter(b=>!b.hidden).map(b=>b.id+':'+b.textContent.trim()));console.log(rb.join(' | '));
  const nameDlg=await p.evaluate(()=>!$('nameDlg').hidden);console.log('nameDlg',nameDlg);if(nameDlg){await shot('l-name');await p.fill('#nameDlg input','নাইটউইং');await p.evaluate(()=>{const b=[...document.querySelectorAll('#nameDlg button')][0];b.click();});await p.waitForTimeout(400);}
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#result button')].find(b=>/মেনু/.test(b.textContent));b&&b.click();});await p.waitForTimeout(800);await shot('l-title-after');
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#title button')].find(b=>/লিডারবোর্ড/.test(b.textContent));b.click();});await p.waitForTimeout(800);await shot('l-board');
  await p.evaluate(()=>{const t=[...document.querySelectorAll('#board [data-tab],#board .tab')];const m=t.find(e=>/আমার/.test(e.textContent));m&&m.click();});await p.waitForTimeout(300);await shot('l-board-mine');
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#board button')].find(b=>/পেছনে|বন্ধ|ফিরে/.test(b.textContent));b&&b.click();});
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#title button')].find(b=>/সেটিংস/.test(b.textContent));b.click();});await p.waitForTimeout(400);await shot('l-settings');
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#settings button')].find(b=>/পেছনে|ঠিক|বন্ধ|ফিরে/.test(b.textContent));b&&b.click();});
  await p.evaluate(()=>{const b=[...document.querySelectorAll('#title button')].find(b=>/কীভাবে/.test(b.textContent));b.click();});await p.waitForTimeout(400);await shot('l-how2');
  console.log(logs.join('\n'));await b.close();})();
