const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});const p=await b.newPage({viewport:{width:1280,height:720}});
p.on('pageerror',e=>console.log('ERR',e.message,e.stack));
await p.goto('file://'+path.resolve(__dirname,'../dist/index.html'));await p.waitForTimeout(2000);await p.click('#startB');await p.waitForFunction(()=>GAME.state==='play');
const AP=require('fs').readFileSync(__dirname+'/run.js','utf8').split('const AUTOPILOT=`')[1].split('`;')[0];await p.evaluate(AP);
const step=async(n)=>p.evaluate(n=>{for(let i=0;i<n;i++){const dt=1/30;GAME.t+=dt;updatePlayer(dt);updateVehicles(dt);updateCrossers(dt);updateObstacles();updateEvents(dt);updatePickups(dt);updateTrains(dt);updateDholai(dt);updateChunks(P.node,P.d,0,true);updateCamera(dt);FX.update(dt);updateSub();hudT=0;updateHUD(dt);}},n);
// villain
await p.evaluate(()=>{for(const v of GAME.veh)scene.remove(v.mesh);GAME.veh=[];P.d=200;P.v=0;EV.next=1e9;EVENTS.villain();const vl=GAME.cross.find(c=>c.role==='villain');P.d=vl.d-60;P.v=8;KEYS.up=1;});
await step(55);await p.screenshot({path:'/home/claude/v2/shots/sc-villain.png'});
await p.evaluate(()=>{KEYS.up=0;playerHorn();});await step(80);await p.screenshot({path:'/home/claude/v2/shots/sc-villain2.png'});
// dholai
await p.evaluate(()=>{KEYS.up=0;P.v=0;GAME.incidentCd=0;const c=spawnCrosser(T.people[0],P.node,P.d+3,P.x,0,{});startIncident(null,c);});await step(40);
await p.screenshot({path:'/home/claude/v2/shots/sc-incident.png'});
await p.evaluate(()=>{startDholai('test');});await step(55);await p.screenshot({path:'/home/claude/v2/shots/sc-dholai.png'});
await step(80);await p.screenshot({path:'/home/claude/v2/shots/sc-dholai2.png'});await step(120);
console.log(await p.evaluate(()=>({dhol:!!DHOL.on,clock:fmtClock(GAME.clock),wallet:GAME.wallet,frozen:P.frozen})));
// pickups up close + map
await p.evaluate(()=>{['charge','tea','doa','papers','vip','clock','taka'].forEach((k,i)=>spawnPickup(k,P.node,P.d+14+i*4,-3+((i%2)*-2)));});await step(2);await p.screenshot({path:'/home/claude/v2/shots/sc-pickups.png'});
await p.evaluate(()=>{pauseGame();openMap();});await p.waitForTimeout(500);await p.screenshot({path:'/home/claude/v2/shots/sc-map.png'});
await b.close();})();
