// Mobile checks: title, planner, touch layouts for every mode, portrait prompt, result.
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const AP=fs.readFileSync(path.join(__dirname,'v4.js'),'utf8').split('const AP=`')[1].split('`;')[0].replace('${process.env.HUMAN?1:0}','1');
const OUT='/home/claude/v4/shots/m';const [W,H]=(process.env.VP||'844x390').split('x').map(Number);
(async()=>{const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const ctx=await b.newContext({viewport:{width:W,height:H},hasTouch:true,isMobile:true,deviceScaleFactor:2});const p=await ctx.newPage();const logs=[];
  p.on('pageerror',e=>logs.push('PAGEERROR: '+e.message+'\n'+e.stack));
  await p.addInitScript(()=>{localStorage.setItem('ojb4-howSeen','1');localStorage.setItem('ojb4-profile',JSON.stringify({xp:3000}));});
  await p.goto('file://'+path.resolve(__dirname,'../dist/index.html'));await p.waitForSelector('#ldGo:not([hidden])',{timeout:90000});
  const shot=async n=>{await p.waitForTimeout(150);await p.screenshot({path:path.join(OUT,W+'x'+H+'-'+n+'.png')});};
  await shot('loader');await p.evaluate(AP);await p.tap('#ldGo',{force:true});await p.waitForTimeout(1200);await shot('title');
  await p.tap('#goDaily');await p.waitForTimeout(300);await shot('planner');
  for(const plan of['bus','metro','cng']){await p.evaluate(o=>{for(const id of['result','title','planner'])$(id).hidden=true;ROT.dismissed=true;requestRun(o);},{plan,home:'mirpur10',dest:'kawran',track:'office',seed:99,daily:false});
    await p.waitForFunction(()=>GAME.state==='play'&&JR.leg,null,{timeout:60000});await shot(plan+'-morning');
    const seen={};for(let i=0;i<200;i++){const r=await p.evaluate(()=>{const e=simRun(40,1/30);return{e,st:GAME.state,mode:P.mode,t:JR.leg&&JR.leg.type,q:!!JR.qte,act:!$('actB').hidden};});
      if(r.e.length){console.log('ERR',r.e[0]);break;}const key=r.t+(r.q?'-qte':'')+(r.act?'-act':'');if(!seen[key]){seen[key]=1;await shot(plan+'-'+key);
        const tb=await p.evaluate(()=>[...document.querySelectorAll('#touch .tb')].filter(b=>!b.hidden).map(b=>{const q=b.getBoundingClientRect();return b.dataset.k+':'+b.textContent+'@'+Math.round(q.left)+','+Math.round(q.top)+(q.right>innerWidth||q.bottom>innerHeight?'!OUT':'');}));console.log(plan,key,tb.join(' '));}
      if(r.st!=='play')break;}
    await p.waitForTimeout(5500);await shot(plan+'-result');}
  console.log(logs.join('\n'));await b.close();})();
